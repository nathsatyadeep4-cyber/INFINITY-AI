package com.example.data.repository

import com.example.BuildConfig
import com.example.data.local.MemoryItemEntity
import com.example.data.model.AiEngine
import com.example.data.model.AiGenerationResult
import com.example.data.model.ImageGenerationResult
import com.example.data.model.OwnerConfig
import com.example.data.model.SmartModeType
import com.example.data.model.WebSearchResult
import com.example.data.remote.OpenAiApiService
import com.example.data.remote.GeminiApiService
import com.example.data.remote.WebSearchService

interface AiRepository {
    suspend fun generateResponse(
        prompt: String,
        mode: SmartModeType,
        config: OwnerConfig,
        history: List<Pair<String, String>> = emptyList(),
        memories: List<MemoryItemEntity> = emptyList(),
        useWebSearch: Boolean = false,
        documentContext: String? = null,
        imageBase64DataUrl: String? = null,
        locationHint: String? = null
    ): Result<AiGenerationResult>

    suspend fun generateImage(
        prompt: String,
        aspectRatio: String,
        stylePreset: String,
        config: OwnerConfig
    ): Result<ImageGenerationResult>

    suspend fun testOpenAiKey(apiKey: String): Result<String>
    suspend fun testGeminiKey(apiKey: String, model: String): Result<String>

    suspend fun synthesizeNeuralSpeech(
        text: String,
        config: OwnerConfig,
        hindiIndianAccent: Boolean
    ): Result<ByteArray>

    fun resolveEffectiveOpenAiKey(config: OwnerConfig): String
}

class InfinityAiRepository(
    private val openAiApi: OpenAiApiService,
    private val webSearchService: WebSearchService,
    private val geminiApi: GeminiApiService = GeminiApiService()
) : AiRepository {

    override fun resolveEffectiveOpenAiKey(config: OwnerConfig): String {
        val ownerKey = config.openAiApiKey.trim()
        if (ownerKey.isNotBlank()) return ownerKey
        val buildConfigKey = runCatching { BuildConfig.OPENAI_API_KEY }.getOrDefault("").trim()
        return if (buildConfigKey.isNotBlank() && buildConfigKey != "MY_OPENAI_API_KEY") buildConfigKey else ""
    }

    override suspend fun generateResponse(
        prompt: String,
        mode: SmartModeType,
        config: OwnerConfig,
        history: List<Pair<String, String>>,
        memories: List<MemoryItemEntity>,
        useWebSearch: Boolean,
        documentContext: String?,
        imageBase64DataUrl: String?,
        locationHint: String?
    ): Result<AiGenerationResult> {
        val openAiKey = resolveEffectiveOpenAiKey(config)

        val webResults: List<WebSearchResult> = if (useWebSearch && config.webSearchEnabled) {
            runCatching { webSearchService.search(prompt) }.getOrDefault(emptyList())
        } else {
            emptyList()
        }

        val fullSystemPrompt = buildSystemPrompt(
            config = config,
            mode = mode,
            memories = if (config.memoryEnabled) memories else emptyList(),
            webResults = webResults,
            documentContext = documentContext,
            locationHint = locationHint
        )

        val shouldUseOpenAi = when (config.activeEngine) {
            AiEngine.OPENAI -> true
            AiEngine.SMART_AUTO -> openAiKey.isNotBlank()
            AiEngine.GEMINI -> false
        }

        if (shouldUseOpenAi) {
            if (openAiKey.isBlank()) {
                return Result.failure(
                    IllegalStateException(
                        "OpenAI Engine is selected, but no OpenAI API key is configured. Add one in Owner Mode -> API Key Management or switch to Smart AI Mode."
                    )
                )
            }
            val openAiModel = if (imageBase64DataUrl != null && config.selectedOpenAiModel == "o3-mini") {
                "gpt-4o-mini"
            } else {
                config.selectedOpenAiModel
            }
            val completion = openAiApi.chatCompletion(
                apiKey = openAiKey,
                model = openAiModel,
                systemPrompt = fullSystemPrompt,
                conversationHistory = history,
                userPrompt = prompt,
                imageBase64DataUrl = imageBase64DataUrl,
                temperature = config.temperature
            )
            return completion.map { reply ->
                AiGenerationResult(
                    text = reply,
                    engineLabel = "OpenAI • $openAiModel",
                    isSampleNotice = false,
                    webSources = webResults
                )
            }
        }

        val geminiKey = config.geminiApiKey.trim()
        if (geminiKey.isBlank()) {
            return Result.failure(IllegalStateException("Gemini API key is missing. Add it in Owner Mode -> API Key Management."))
        }
        val geminiModel = config.selectedGeminiModel.ifBlank { "gemini-3.8-flash" }
        return geminiApi.generate(
            apiKey = geminiKey,
            model = geminiModel,
            systemPrompt = fullSystemPrompt,
            history = history,
            userPrompt = buildString {
                append(prompt)
                if (!documentContext.isNullOrBlank()) append("\n\nAttached document context:\n${documentContext.take(8000)}")
            },
            imageDataUrl = imageBase64DataUrl,
            temperature = config.temperature
        ).map { reply ->
            AiGenerationResult(
                text = reply,
                engineLabel = "Google Gemini • $geminiModel",
                isSampleNotice = false,
                webSources = webResults
            )
        }
    }

    override suspend fun generateImage(
        prompt: String,
        aspectRatio: String,
        stylePreset: String,
        config: OwnerConfig
    ): Result<ImageGenerationResult> {
        if (!config.imageGenEnabled) {
            return Result.failure(IllegalStateException("AI Image Generation is currently disabled in Owner Mode Feature Controls."))
        }

        val openAiKey = resolveEffectiveOpenAiKey(config)
        val shouldUseOpenAi = (config.activeEngine == AiEngine.OPENAI || config.activeEngine == AiEngine.SMART_AUTO) && openAiKey.isNotBlank()

        if (shouldUseOpenAi) {
            val size = when (aspectRatio) {
                "16:9" -> "1792x1024"
                "9:16" -> "1024x1792"
                else -> "1024x1024"
            }
            val styledPrompt = "$prompt. Style: $stylePreset"
            return openAiApi.generateImage(
                apiKey = openAiKey,
                model = config.selectedOpenAiImageModel,
                prompt = styledPrompt,
                size = size
            ).map { url ->
                ImageGenerationResult(
                    imageUrl = url,
                    caption = "Generated with OpenAI ${config.selectedOpenAiImageModel} ($aspectRatio • $stylePreset)",
                    engineLabel = "OpenAI • ${config.selectedOpenAiImageModel}",
                    isSampleNotice = false
                )
            }
        }

        if (config.activeEngine == AiEngine.OPENAI && openAiKey.isBlank()) {
            return Result.failure(IllegalStateException("OpenAI API key is required for DALL-E 3. Configure it in Owner Mode -> API Key Management."))
        }

        return Result.success(
            ImageGenerationResult(
                imageUrl = null,
                caption = "[Sample Gemini Image Output — Firebase Required]\n\nPrompt: \"$prompt\"\nStyle: $stylePreset • Aspect Ratio: $aspectRatio\nModel: gemini-nano-banana-2.1\n\nEnable Firebase AI Logic (or enter an OpenAI key in Owner Mode for DALL-E 3) to synthesize live images.",
                engineLabel = "Gemini Nano Banana 2.1 • Sample Mode",
                isSampleNotice = true
            )
        )
    }

    override suspend fun testOpenAiKey(apiKey: String): Result<String> {
        val trimmed = apiKey.trim()
        if (trimmed.isBlank()) {
            return Result.failure(IllegalArgumentException("Please enter an OpenAI API key first."))
        }
        return openAiApi.chatCompletion(
            apiKey = trimmed,
            model = "gpt-4o-mini",
            systemPrompt = "Reply with a single short confirmation phrase.",
            conversationHistory = emptyList(),
            userPrompt = "Confirm INFINITY AI connection is active.",
            temperature = 0.2f
        ).map { "Connected! OpenAI responded: $it" }
    }


    override suspend fun testGeminiKey(apiKey: String, model: String): Result<String> {
        return geminiApi.generate(
            apiKey = apiKey.trim(),
            model = model.ifBlank { "gemini-3.8-flash" },
            systemPrompt = "Reply briefly and clearly.",
            history = emptyList(),
            userPrompt = "Reply exactly: INFINITY AI Gemini connection is active.",
            temperature = 0.1f
        ).map { "Connected! Gemini responded: $it" }
    }

    override suspend fun synthesizeNeuralSpeech(
        text: String,
        config: OwnerConfig,
        hindiIndianAccent: Boolean
    ): Result<ByteArray> {
        val openAiKey = resolveEffectiveOpenAiKey(config)
        if (openAiKey.isBlank()) {
            return Result.failure(IllegalStateException("OpenAI key not configured for Neural TTS."))
        }
        return openAiApi.synthesizeSpeech(
            apiKey = openAiKey,
            text = text,
            voice = config.neuralVoicePreset.id,
            speed = config.voiceSpeechRate,
            hindiIndianAccent = hindiIndianAccent
        )
    }

    private fun buildSystemPrompt(
        config: OwnerConfig,
        mode: SmartModeType,
        memories: List<MemoryItemEntity>,
        webResults: List<WebSearchResult>,
        documentContext: String?,
        locationHint: String?
    ): String {
        return buildString {
            appendLine(config.systemInstructions)
            appendLine("Active Mode: ${mode.title} — ${mode.systemHint}")
            appendLine("Personality Tone (${config.personalityTone.displayName}): ${config.personalityTone.promptInstruction}")
            if (memories.isNotEmpty()) {
                appendLine("\nRemembered User Context (Memory System):")
                memories.forEach { appendLine("- [${it.category}] ${it.content}") }
            }
            if (!locationHint.isNullOrBlank()) {
                appendLine("\nApproximate Device Location Context: $locationHint")
            }
            if (!documentContext.isNullOrBlank()) {
                appendLine("\nAttached Document Content:\n${documentContext.take(8000)}")
            }
            if (webResults.isNotEmpty()) {
                appendLine("\nLive Web Search Results:")
                webResults.forEachIndexed { idx, res ->
                    appendLine("${idx + 1}. ${res.title} (${res.source}): ${res.snippet} [${res.url}]")
                }
            }
        }
    }

    private fun buildLabeledGeminiSampleResponse(
        prompt: String,
        mode: SmartModeType,
        config: OwnerConfig,
        memories: List<MemoryItemEntity>,
        webResults: List<WebSearchResult>,
        documentContext: String?,
        hasImage: Boolean
    ): String {
        val webSummary = if (webResults.isNotEmpty()) {
            buildString {
                appendLine("\n\n**Live Web Search Findings (${webResults.size} sources):**")
                webResults.take(3).forEach { r ->
                    appendLine("• **${r.title}** (${r.source}): ${r.snippet}")
                }
            }
        } else ""

        val memoryNote = if (config.memoryEnabled && memories.isNotEmpty()) {
            "\n• Active Memory Vault items applied: ${memories.size}"
        } else ""

        val docNote = if (!documentContext.isNullOrBlank()) {
            "\n• Attached document excerpt (${documentContext.length} chars) parsed successfully."
        } else ""

        val visionNote = if (hasImage) {
            "\n• Attached image received for visual understanding."
        } else ""

        val modeSample = when (mode) {
            SmartModeType.CODING -> """
                |```kotlin
                |// Sample ${mode.title} output for: "$prompt"
                |suspend fun infinityTask(input: String): Result<String> = runCatching {
                |    "Processed cleanly with INFINITY AI: ${'$'}input"
                |}
                |```
                |This sample demonstrates structured code formatting with copy support.
            """.trimMargin()

            SmartModeType.TRANSLATION -> """
                |Translation preview for: "$prompt"
                |• Detected tone: ${config.personalityTone.displayName}
                |• Use the Speak button below to hear native Text-to-Speech playback.
            """.trimMargin()

            SmartModeType.EDUCATION -> """
                |Study Breakdown for: "$prompt"
                |1. Core Concept: Break the topic into foundational principles.
                |2. Worked Example: Apply the concept to a concrete scenario.
                |3. Quick Check: Summarize in one sentence to boost mastery.
            """.trimMargin()

            SmartModeType.WRITING -> """
                |Draft Outline for: "$prompt"
                |• Hook: Open with a vivid, clear thesis statement.
                |• Body: Support with concrete evidence and transitions.
                |• Conclusion: End with a memorable call to action.
            """.trimMargin()

            else -> """
                |Prompt received: "$prompt"
                |Active Personality: ${config.personalityTone.displayName} • Target Model: ${config.selectedGeminiModel}
            """.trimMargin()
        }

        return buildString {
            appendLine("[Sample Gemini Response — Firebase Required]")
            appendLine()
            appendLine(modeSample)
            if (memoryNote.isNotBlank() || docNote.isNotBlank() || visionNote.isNotBlank()) {
                appendLine()
                append("Context Status:$memoryNote$docNote$visionNote")
            }
            if (webSummary.isNotBlank()) {
                append(webSummary)
            }
            appendLine()
            appendLine()
            append("Note: Live Gemini responses require enabling Firebase AI Logic, or add an OpenAI API key in Owner Mode for live OpenAI inference.")
        }
    }
}
