package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.model.AiEngine
import com.example.data.model.NeuralVoicePreset
import com.example.data.model.OwnerConfig
import com.example.data.model.PersonalityTone
import com.example.data.model.VoiceLanguage
import com.example.ui.theme.AppThemeMode

@Composable
fun OwnerModeScreen(
    config: OwnerConfig,
    ownerUnlocked: Boolean,
    apiTestStatus: String?,
    onUnlockOwner: (String) -> Boolean,
    onLockOwner: () -> Unit,
    onUpdateConfig: ((OwnerConfig) -> OwnerConfig) -> Unit,
    onTestOpenAiKey: (String?) -> Unit,
    onTestGeminiKey: (String?) -> Unit,
    onPreviewEnglishVoice: () -> Unit,
    onPreviewHindiVoice: () -> Unit,
    onClearAllChats: () -> Unit,
    onClearAllMemories: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    // Optional local Owner PIN lock (NOT a login or user account system)
    if (config.ownerPinEnabled && !ownerUnlocked) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = "Owner PIN Lock",
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(52.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text("Owner Mode Protected", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Enter your local Owner PIN to modify AI models, API keys, and system controls.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = pinInput,
                onValueChange = {
                    pinInput = it
                    pinError = false
                },
                label = { Text("Owner PIN (default: 1234)") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                isError = pinError,
                modifier = Modifier.fillMaxWidth().testTag("owner_pin_input")
            )
            if (pinError) {
                Text(
                    "Incorrect PIN",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = {
                    if (!onUnlockOwner(pinInput)) pinError = true
                    else pinInput = ""
                },
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("owner_unlock_button")
            ) {
                Text("Unlock Owner Dashboard")
            }
        }
        return
    }

    var keyDraft by remember(config.openAiApiKey) { mutableStateOf(config.openAiApiKey) }
    var geminiKeyDraft by remember(config.geminiApiKey) { mutableStateOf(config.geminiApiKey) }
    var showGeminiKey by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var systemPromptDraft by remember(config.systemInstructions) { mutableStateOf(config.systemInstructions) }
    var newPinDraft by remember(config.ownerPin) { mutableStateOf(config.ownerPin) }

    var permissionVersion by remember { mutableStateOf(0) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        permissionVersion++
    }

    val geminiModels = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite")
    val openAiModels = listOf("gpt-4o-mini", "gpt-4o", "o3-mini")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("owner_lazy_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Owner Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AdminPanelSettings,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(30.dp)
                    )
                    Column {
                        Text("OWNER MODE", style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "Models, API Keys, System Prompt & Feature Controls",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (config.ownerPinEnabled) {
                    IconButton(onClick = onLockOwner) {
                        Icon(Icons.Filled.LockOpen, contentDescription = "Lock Owner Mode", tint = MaterialTheme.colorScheme.tertiary)
                    }
                }
            }
        }

        // 1. AI Model Management
        item {
            OwnerSectionCard(title = "AI Engine & Model Management", icon = Icons.Filled.Tune) {
                Text("Active Engine", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(AiEngine.entries) { engine ->
                        FilterChip(
                            selected = config.activeEngine == engine,
                            onClick = { onUpdateConfig { it.copy(activeEngine = engine) } },
                            label = { Text(engine.label) }
                        )
                    }
                }
                Text("OpenAI Model", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(openAiModels) { model ->
                        FilterChip(
                            selected = config.selectedOpenAiModel == model,
                            onClick = { onUpdateConfig { it.copy(selectedOpenAiModel = model) } },
                            label = { Text(model) }
                        )
                    }
                }
                Text("Gemini Target Model (Direct API)", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(geminiModels) { model ->
                        FilterChip(
                            selected = config.selectedGeminiModel == model,
                            onClick = { onUpdateConfig { it.copy(selectedGeminiModel = model) } },
                            label = { Text(model) }
                        )
                    }
                }
            }
        }

        // 2. API Key Management
        item {
            OwnerSectionCard(title = "API Key Management", icon = Icons.Filled.Key) {
                Text(
                    "API keys are stored locally on this device. Use separate keys for OpenAI and Google Gemini.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = keyDraft,
                    onValueChange = { keyDraft = it },
                    label = { Text("OpenAI API Key (sk-...)") },
                    singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(
                                imageVector = if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = "Toggle key visibility"
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("owner_openai_key_input"),
                    shape = RoundedCornerShape(14.dp)
                )
                OutlinedTextField(
                    value = geminiKeyDraft,
                    onValueChange = { geminiKeyDraft = it },
                    label = { Text("Google Gemini API Key") },
                    singleLine = true,
                    visualTransformation = if (showGeminiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showGeminiKey = !showGeminiKey }) {
                            Icon(imageVector = if (showGeminiKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = "Toggle Gemini key visibility")
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("owner_gemini_key_input"),
                    shape = RoundedCornerShape(14.dp)
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onUpdateConfig { it.copy(geminiApiKey = geminiKeyDraft.trim()) } }, modifier = Modifier.weight(1f)) { Text("Save Gemini Key") }
                    OutlinedButton(onClick = { onTestGeminiKey(geminiKeyDraft) }, modifier = Modifier.weight(1f)) { Text("Test Gemini") }
                    TextButton(onClick = { geminiKeyDraft = ""; onUpdateConfig { it.copy(geminiApiKey = "") } }) { Text("Clear") }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onUpdateConfig { it.copy(openAiApiKey = keyDraft.trim()) } },
                        modifier = Modifier.weight(1f).testTag("owner_save_key_button")
                    ) {
                        Text("Save Key")
                    }
                    OutlinedButton(
                        onClick = { onTestOpenAiKey(keyDraft) },
                        modifier = Modifier.weight(1f).testTag("owner_test_key_button")
                    ) {
                        Text("Test API")
                    }
                    TextButton(
                        onClick = {
                            keyDraft = ""
                            onUpdateConfig { it.copy(openAiApiKey = "") }
                        }
                    ) {
                        Text("Clear")
                    }
                }
                apiTestStatus?.let { status ->
                    Text(
                        text = status,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // 3. System Instructions & Personality
        item {
            OwnerSectionCard(title = "System Instructions & Personality", icon = Icons.Filled.AdminPanelSettings) {
                OutlinedTextField(
                    value = systemPromptDraft,
                    onValueChange = { systemPromptDraft = it },
                    label = { Text("Global System Instructions") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )
                Button(
                    onClick = { onUpdateConfig { it.copy(systemInstructions = systemPromptDraft.trim()) } },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Apply System Instructions")
                }

                Text("AI Personality Tone", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(PersonalityTone.entries) { tone ->
                        FilterChip(
                            selected = config.personalityTone == tone,
                            onClick = { onUpdateConfig { it.copy(personalityTone = tone) } },
                            label = { Text(tone.displayName) }
                        )
                    }
                }

                Text(
                    "Creativity (Temperature): ${String.format("%.2f", config.temperature)}",
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = config.temperature,
                    onValueChange = { v -> onUpdateConfig { it.copy(temperature = v) } },
                    valueRange = 0.1f..1.0f
                )
            }
        }

        // 4. Feature Controls
        item {
            OwnerSectionCard(title = "Feature Controls", icon = Icons.Filled.Tune) {
                FeatureToggleRow("Memory System Injection", config.memoryEnabled) { checked ->
                    onUpdateConfig { it.copy(memoryEnabled = checked) }
                }
                FeatureToggleRow("Live Web Search Grounding", config.webSearchEnabled) { checked ->
                    onUpdateConfig { it.copy(webSearchEnabled = checked) }
                }
                FeatureToggleRow("AI Image Generation Studio", config.imageGenEnabled) { checked ->
                    onUpdateConfig { it.copy(imageGenEnabled = checked) }
                }
                FeatureToggleRow("AI Coding Assistant", config.codingAssistantEnabled) { checked ->
                    onUpdateConfig { it.copy(codingAssistantEnabled = checked) }
                }
                FeatureToggleRow("Education System & Tracker", config.educationEnabled) { checked ->
                    onUpdateConfig { it.copy(educationEnabled = checked) }
                }
                FeatureToggleRow("PDF & Document Analysis", config.pdfAnalysisEnabled) { checked ->
                    onUpdateConfig { it.copy(pdfAnalysisEnabled = checked) }
                }
                FeatureToggleRow("Voice AI (STT & TTS)", config.voiceEnabled) { checked ->
                    onUpdateConfig { it.copy(voiceEnabled = checked) }
                }
                FeatureToggleRow("Auto-Speak AI Responses", config.voiceAutoSpeak) { checked ->
                    onUpdateConfig { it.copy(voiceAutoSpeak = checked) }
                }
                FeatureToggleRow("Location Context Hint", config.locationContextEnabled) { checked ->
                    onUpdateConfig { it.copy(locationContextEnabled = checked) }
                }
            }
        }

        // 5. Application Settings, Security PIN & Permissions
        item {
            OwnerSectionCard(title = "App Settings, PIN & Permissions", icon = Icons.Filled.Security) {
                Text("Theme Appearance", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = config.themeMode == mode,
                            onClick = { onUpdateConfig { it.copy(themeMode = mode) } },
                            label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }

                Text(
                    "Voice Language & Accent",
                    style = MaterialTheme.typography.labelLarge
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(VoiceLanguage.entries) { lang ->
                        FilterChip(
                            selected = config.voiceLanguage == lang,
                            onClick = { onUpdateConfig { it.copy(voiceLanguage = lang) } },
                            label = { Text(lang.label) }
                        )
                    }
                }

                FeatureToggleRow("Prefer Neural HD Voice (when OpenAI key set)", config.preferNeuralVoice) { checked ->
                    onUpdateConfig { it.copy(preferNeuralVoice = checked) }
                }
                if (config.preferNeuralVoice) {
                    Text("Neural Voice Persona", style = MaterialTheme.typography.labelLarge)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(NeuralVoicePreset.entries) { preset ->
                            FilterChip(
                                selected = config.neuralVoicePreset == preset,
                                onClick = { onUpdateConfig { it.copy(neuralVoicePreset = preset) } },
                                label = { Text(preset.displayName) }
                            )
                        }
                    }
                }

                Text(
                    "Voice Speed: ${String.format("%.2fx", config.voiceSpeechRate)}",
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = config.voiceSpeechRate,
                    onValueChange = { r -> onUpdateConfig { it.copy(voiceSpeechRate = r) } },
                    valueRange = 0.6f..1.8f,
                    modifier = Modifier.testTag("owner_voice_speed_slider")
                )

                Text(
                    "Voice Volume: ${(config.voiceVolume * 100).toInt()}%",
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = config.voiceVolume,
                    onValueChange = { v -> onUpdateConfig { it.copy(voiceVolume = v) } },
                    valueRange = 0.1f..1.0f,
                    modifier = Modifier.testTag("owner_voice_volume_slider")
                )

                Text(
                    "Natural Pitch Tuning: ${String.format("%.2f", config.voicePitch)}",
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = config.voicePitch,
                    onValueChange = { p -> onUpdateConfig { it.copy(voicePitch = p) } },
                    valueRange = 0.85f..1.15f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onPreviewEnglishVoice,
                        modifier = Modifier.weight(1f).testTag("preview_english_voice_button")
                    ) {
                        Text("Test English")
                    }
                    OutlinedButton(
                        onClick = onPreviewHindiVoice,
                        modifier = Modifier.weight(1f).testTag("preview_hindi_voice_button")
                    ) {
                        Text("Test Hindi")
                    }
                }

                FeatureToggleRow("Protect Owner Mode with Local PIN", config.ownerPinEnabled) { checked ->
                    onUpdateConfig { it.copy(ownerPinEnabled = checked) }
                }
                if (config.ownerPinEnabled) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newPinDraft,
                            onValueChange = { newPinDraft = it.take(8) },
                            label = { Text("Owner PIN") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(onClick = {
                            if (newPinDraft.length >= 4) {
                                onUpdateConfig { it.copy(ownerPin = newPinDraft) }
                            }
                        }) {
                            Text("Set PIN")
                        }
                    }
                }

                // Runtime Permissions Status
                val permsCheck = remember(permissionVersion) {
                    listOf(
                        "Camera" to Manifest.permission.CAMERA,
                        "Microphone" to Manifest.permission.RECORD_AUDIO,
                        "Coarse Location" to Manifest.permission.ACCESS_COARSE_LOCATION
                    ) + if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        listOf("Notifications" to Manifest.permission.POST_NOTIFICATIONS)
                    } else emptyList()
                }
                Text("Android Runtime Permissions", style = MaterialTheme.typography.labelLarge)
                permsCheck.forEach { (label, perm) ->
                    val granted = ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$label: ${if (granted) "Granted" else "Not Granted"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (!granted) {
                            TextButton(onClick = { permissionLauncher.launch(arrayOf(perm)) }) {
                                Text("Grant")
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onClearAllChats,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Clear Chats")
                    }
                    OutlinedButton(
                        onClick = onClearAllMemories,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Clear Memory")
                    }
                }
            }
        }
    }
}

@Composable
private fun OwnerSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(20.dp))
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            content()
        }
    }
}

@Composable
private fun FeatureToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
