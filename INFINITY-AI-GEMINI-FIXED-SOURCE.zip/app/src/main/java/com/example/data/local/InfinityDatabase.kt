package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatSessionEntity::class,
        ChatMessageEntity::class,
        MemoryItemEntity::class,
        StudyTopicEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class InfinityDatabase : RoomDatabase() {
    abstract fun infinityDao(): InfinityDao

    companion object {
        @Volatile
        private var INSTANCE: InfinityDatabase? = null

        fun getInstance(context: Context): InfinityDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    InfinityDatabase::class.java,
                    "infinity_ai.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
