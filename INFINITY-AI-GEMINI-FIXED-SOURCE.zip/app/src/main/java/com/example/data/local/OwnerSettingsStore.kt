package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AiEngine
import com.example.data.model.NeuralVoicePreset
import com.example.data.model.OwnerConfig
import com.example.data.model.PersonalityTone
import com.example.data.model.VoiceLanguage
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.ownerDataStore: DataStore<Preferences> by preferencesDataStore(name = "infinity_owner_settings")

class OwnerSettingsStore(private val context: Context) {

    private object Keys {
        val ACTIVE_ENGINE = stringPreferencesKey("active_engine")
        val GEMINI_MODEL = stringPreferencesKey("gemini_model")
        val OPENAI_MODEL = stringPreferencesKey("openai_model")
        val OPENAI_IMAGE_MODEL = stringPreferencesKey("openai_image_model")
        val OPENAI_API_KEY = stringPreferencesKey("openai_api_key")
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        val SYSTEM_INSTRUCTIONS = stringPreferencesKey("system_instructions")
        val PERSONALITY_TONE = stringPreferencesKey("personality_tone")
        val TEMPERATURE = floatPreferencesKey("temperature")
        val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        val WEB_SEARCH_ENABLED = booleanPreferencesKey("web_search_enabled")
        val IMAGE_GEN_ENABLED = booleanPreferencesKey("image_gen_enabled")
        val CODING_ENABLED = booleanPreferencesKey("coding_enabled")
        val EDUCATION_ENABLED = booleanPreferencesKey("education_enabled")
        val PDF_ENABLED = booleanPreferencesKey("pdf_enabled")
        val VOICE_ENABLED = booleanPreferencesKey("voice_enabled")
        val VOICE_AUTO_SPEAK = booleanPreferencesKey("voice_auto_speak")
        val VOICE_SPEECH_RATE = floatPreferencesKey("voice_speech_rate")
        val VOICE_VOLUME = floatPreferencesKey("voice_volume")
        val VOICE_PITCH = floatPreferencesKey("voice_pitch")
        val VOICE_LANGUAGE = stringPreferencesKey("voice_language")
        val PREFER_NEURAL_VOICE = booleanPreferencesKey("prefer_neural_voice")
        val NEURAL_VOICE_PRESET = stringPreferencesKey("neural_voice_preset")
        val LOCATION_CONTEXT_ENABLED = booleanPreferencesKey("location_context_enabled")
        val OWNER_PIN_ENABLED = booleanPreferencesKey("owner_pin_enabled")
        val OWNER_PIN = stringPreferencesKey("owner_pin")
        val THEME_MODE = stringPreferencesKey("theme_mode")
    }

    private fun readConfig(prefs: Preferences): OwnerConfig = OwnerConfig(
        activeEngine = prefs[Keys.ACTIVE_ENGINE]?.let { runCatching { AiEngine.valueOf(it) }.getOrNull() }
            ?: AiEngine.SMART_AUTO,
        selectedGeminiModel = prefs[Keys.GEMINI_MODEL]?.takeIf { it in setOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash") } ?: "gemini-2.5-flash",
        selectedOpenAiModel = prefs[Keys.OPENAI_MODEL] ?: "gpt-4o-mini",
        selectedOpenAiImageModel = prefs[Keys.OPENAI_IMAGE_MODEL] ?: "dall-e-3",
        openAiApiKey = prefs[Keys.OPENAI_API_KEY] ?: "",
        geminiApiKey = prefs[Keys.GEMINI_API_KEY] ?: "",
        systemInstructions = prefs[Keys.SYSTEM_INSTRUCTIONS]
            ?: "You are INFINITY AI, a versatile, accurate, privacy-respecting multi-modal AI assistant.",
        personalityTone = prefs[Keys.PERSONALITY_TONE]?.let { runCatching { PersonalityTone.valueOf(it) }.getOrNull() }
            ?: PersonalityTone.BALANCED,
        temperature = prefs[Keys.TEMPERATURE] ?: 0.7f,
        memoryEnabled = prefs[Keys.MEMORY_ENABLED] ?: true,
        webSearchEnabled = prefs[Keys.WEB_SEARCH_ENABLED] ?: true,
        imageGenEnabled = prefs[Keys.IMAGE_GEN_ENABLED] ?: true,
        codingAssistantEnabled = prefs[Keys.CODING_ENABLED] ?: true,
        educationEnabled = prefs[Keys.EDUCATION_ENABLED] ?: true,
        pdfAnalysisEnabled = prefs[Keys.PDF_ENABLED] ?: true,
        voiceEnabled = prefs[Keys.VOICE_ENABLED] ?: true,
        voiceAutoSpeak = prefs[Keys.VOICE_AUTO_SPEAK] ?: false,
        voiceSpeechRate = prefs[Keys.VOICE_SPEECH_RATE] ?: 1.0f,
        voiceVolume = prefs[Keys.VOICE_VOLUME] ?: 0.9f,
        voicePitch = prefs[Keys.VOICE_PITCH] ?: 1.0f,
        voiceLanguage = prefs[Keys.VOICE_LANGUAGE]?.let { runCatching { VoiceLanguage.valueOf(it) }.getOrNull() }
            ?: VoiceLanguage.AUTO_DETECT,
        preferNeuralVoice = prefs[Keys.PREFER_NEURAL_VOICE] ?: true,
        neuralVoicePreset = prefs[Keys.NEURAL_VOICE_PRESET]?.let { runCatching { NeuralVoicePreset.valueOf(it) }.getOrNull() }
            ?: NeuralVoicePreset.NOVA,
        locationContextEnabled = prefs[Keys.LOCATION_CONTEXT_ENABLED] ?: false,
        ownerPinEnabled = prefs[Keys.OWNER_PIN_ENABLED] ?: false,
        ownerPin = prefs[Keys.OWNER_PIN] ?: "1234",
        themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { AppThemeMode.valueOf(it) }.getOrNull() }
            ?: AppThemeMode.DARK
    )

    val configFlow: Flow<OwnerConfig> = context.ownerDataStore.data.map(::readConfig)

    suspend fun updateConfig(transform: (OwnerConfig) -> OwnerConfig) {
        context.ownerDataStore.edit { prefs ->
            val updated = transform(readConfig(prefs))
            prefs[Keys.ACTIVE_ENGINE] = updated.activeEngine.name
            prefs[Keys.GEMINI_MODEL] = updated.selectedGeminiModel
            prefs[Keys.OPENAI_MODEL] = updated.selectedOpenAiModel
            prefs[Keys.OPENAI_IMAGE_MODEL] = updated.selectedOpenAiImageModel
            prefs[Keys.OPENAI_API_KEY] = updated.openAiApiKey
            prefs[Keys.GEMINI_API_KEY] = updated.geminiApiKey
            prefs[Keys.SYSTEM_INSTRUCTIONS] = updated.systemInstructions
            prefs[Keys.PERSONALITY_TONE] = updated.personalityTone.name
            prefs[Keys.TEMPERATURE] = updated.temperature
            prefs[Keys.MEMORY_ENABLED] = updated.memoryEnabled
            prefs[Keys.WEB_SEARCH_ENABLED] = updated.webSearchEnabled
            prefs[Keys.IMAGE_GEN_ENABLED] = updated.imageGenEnabled
            prefs[Keys.CODING_ENABLED] = updated.codingAssistantEnabled
            prefs[Keys.EDUCATION_ENABLED] = updated.educationEnabled
            prefs[Keys.PDF_ENABLED] = updated.pdfAnalysisEnabled
            prefs[Keys.VOICE_ENABLED] = updated.voiceEnabled
            prefs[Keys.VOICE_AUTO_SPEAK] = updated.voiceAutoSpeak
            prefs[Keys.VOICE_SPEECH_RATE] = updated.voiceSpeechRate
            prefs[Keys.VOICE_VOLUME] = updated.voiceVolume
            prefs[Keys.VOICE_PITCH] = updated.voicePitch
            prefs[Keys.VOICE_LANGUAGE] = updated.voiceLanguage.name
            prefs[Keys.PREFER_NEURAL_VOICE] = updated.preferNeuralVoice
            prefs[Keys.NEURAL_VOICE_PRESET] = updated.neuralVoicePreset.name
            prefs[Keys.LOCATION_CONTEXT_ENABLED] = updated.locationContextEnabled
            prefs[Keys.OWNER_PIN_ENABLED] = updated.ownerPinEnabled
            prefs[Keys.OWNER_PIN] = updated.ownerPin
            prefs[Keys.THEME_MODE] = updated.themeMode.name
        }
    }
}
