package com.example.data.model

import com.example.ui.theme.AppThemeMode

enum class AiEngine(val label: String, val badge: String) {
    SMART_AUTO("Smart AI Mode", "SMART"),
    GEMINI("Google Gemini", "GEMINI"),
    OPENAI("OpenAI Engine", "OPENAI")
}

enum class SmartModeType(val title: String, val subtitle: String, val systemHint: String) {
    CHAT("AI Chat", "General reasoning & conversation", "Provide helpful, accurate, structured answers."),
    CODING("Coding Assistant", "Code, debug, refactor & architecture", "Act as a senior software engineer. Output clean, well-commented code blocks."),
    WRITING("Writing Studio", "Essays, emails, copy & editing", "Craft polished, engaging prose tailored to the requested format and tone."),
    TRANSLATION("Translator Pro", "Multi-language translation & nuance", "Translate accurately while preserving idioms, tone, and pronunciation notes."),
    EDUCATION("Education Tutor", "Step-by-step teaching & quizzes", "Teach clearly using analogies, step-by-step breakdowns, and quick comprehension checks."),
    VISION("Image Understanding", "Analyze camera photos & visuals", "Describe and analyze visual details, text, objects, and context accurately."),
    DOCUMENT("PDF & Document Lab", "Summarize & Q&A over documents", "Analyze the provided document content and answer with grounded citations."),
    WEB_SEARCH("Web Search AI", "Live web research & synthesis", "Synthesize the live web search findings clearly with source attribution.")
}

enum class PersonalityTone(val displayName: String, val promptInstruction: String) {
    BALANCED("Balanced", "Be clear, helpful, and well-structured."),
    CONCISE("Concise", "Be direct, crisp, and avoid unnecessary filler."),
    CREATIVE("Creative", "Be imaginative, expressive, and explore novel ideas."),
    PROFESSOR("Professor", "Explain concepts thoroughly with examples and pedagogy."),
    ENGINEER("Principal Engineer", "Prioritize precision, edge cases, and production-ready code.")
}

enum class VoiceLanguage(val label: String, val languageTag: String) {
    AUTO_DETECT("Auto (Hindi & English)", "auto"),
    ENGLISH_US("English (Natural)", "en-US"),
    ENGLISH_IN("English (India)", "en-IN"),
    HINDI_IN("Hindi (Indian Accent)", "hi-IN")
}

enum class NeuralVoicePreset(val id: String, val displayName: String, val description: String) {
    NOVA("nova", "Nova", "Warm, clear & natural assistant"),
    CORAL("coral", "Coral", "Expressive, smooth & engaging"),
    SAGE("sage", "Sage", "Calm, confident & articulate"),
    ALLOY("alloy", "Alloy", "Balanced, crisp & neutral"),
    ONYX("onyx", "Onyx", "Deep, steady & authoritative")
}

data class OwnerConfig(
    val activeEngine: AiEngine = AiEngine.SMART_AUTO,
    val selectedGeminiModel: String = "gemini-2.5-flash",
    val selectedOpenAiModel: String = "gpt-4o-mini",
    val selectedOpenAiImageModel: String = "dall-e-3",
    val openAiApiKey: String = "",
    val geminiApiKey: String = "",
    val systemInstructions: String = "You are INFINITY AI, a versatile, accurate, privacy-respecting multi-modal AI assistant.",
    val personalityTone: PersonalityTone = PersonalityTone.BALANCED,
    val temperature: Float = 0.7f,
    val memoryEnabled: Boolean = true,
    val webSearchEnabled: Boolean = true,
    val imageGenEnabled: Boolean = true,
    val codingAssistantEnabled: Boolean = true,
    val educationEnabled: Boolean = true,
    val pdfAnalysisEnabled: Boolean = true,
    val voiceEnabled: Boolean = true,
    val voiceAutoSpeak: Boolean = false,
    val voiceSpeechRate: Float = 1.0f,
    val voiceVolume: Float = 0.9f,
    val voicePitch: Float = 1.0f,
    val voiceLanguage: VoiceLanguage = VoiceLanguage.AUTO_DETECT,
    val preferNeuralVoice: Boolean = true,
    val neuralVoicePreset: NeuralVoicePreset = NeuralVoicePreset.NOVA,
    val locationContextEnabled: Boolean = false,
    val ownerPinEnabled: Boolean = false,
    val ownerPin: String = "1234",
    val themeMode: AppThemeMode = AppThemeMode.DARK
)

data class WebSearchResult(
    val title: String,
    val snippet: String,
    val url: String,
    val source: String
)

data class AiGenerationResult(
    val text: String,
    val engineLabel: String,
    val isSampleNotice: Boolean = false,
    val webSources: List<WebSearchResult> = emptyList()
)

data class ImageGenerationResult(
    val imageUrl: String? = null,
    val caption: String,
    val engineLabel: String,
    val isSampleNotice: Boolean = false
)
