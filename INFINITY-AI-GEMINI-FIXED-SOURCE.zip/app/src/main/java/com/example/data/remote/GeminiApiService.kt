package com.example.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Direct Gemini Developer API client. The key is supplied at runtime and is never compiled into the APK. */
class GeminiApiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generate(
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<Pair<String, String>>,
        userPrompt: String,
        imageDataUrl: String? = null,
        temperature: Float = 0.7f
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(apiKey.isNotBlank()) { "Enter your Gemini API key in Owner Mode -> API Key Management." }
            val contents = JSONArray()
            history.takeLast(12).forEach { (role, text) ->
                contents.put(JSONObject().apply {
                    put("role", if (role == "assistant") "model" else "user")
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                })
            }
            val userParts = JSONArray().apply {
                put(JSONObject().put("text", userPrompt))
                if (!imageDataUrl.isNullOrBlank()) {
                    val comma = imageDataUrl.indexOf(',')
                    if (comma > 0) {
                        val header = imageDataUrl.substring(0, comma)
                        val mime = Regex("data:([^;]+)").find(header)?.groupValues?.getOrNull(1) ?: "image/jpeg"
                        val data = imageDataUrl.substring(comma + 1)
                        put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", data)))
                    }
                }
            }
            contents.put(JSONObject().put("role", "user").put("parts", userParts))

            val payload = JSONObject().apply {
                put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                put("contents", contents)
                put("generationConfig", JSONObject().put("temperature", temperature.toDouble()).put("maxOutputTokens", 4096))
            }
            val safeModel = URLEncoder.encode(model, "UTF-8")
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent")
                .addHeader("x-goog-api-key", apiKey.trim())
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching { JSONObject(body).getJSONObject("error").optString("message") }.getOrNull()
                    throw IllegalStateException("Gemini API error (${response.code}): ${detail ?: body.take(400)}")
                }
                val json = JSONObject(body)
                val candidates = json.optJSONArray("candidates") ?: throw IllegalStateException("Gemini returned no candidates. Check model access and API key.")
                val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    ?: throw IllegalStateException("Gemini returned an empty response.")
                buildString {
                    for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
                }.trim().ifBlank { throw IllegalStateException("Gemini returned an empty text response.") }
            }
        }
    }
}
