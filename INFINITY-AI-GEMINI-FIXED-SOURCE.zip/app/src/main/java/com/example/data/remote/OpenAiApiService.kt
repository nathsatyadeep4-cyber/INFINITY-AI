package com.example.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class OpenAiApiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun chatCompletion(
        apiKey: String,
        model: String,
        systemPrompt: String,
        conversationHistory: List<Pair<String, String>>,
        userPrompt: String,
        imageBase64DataUrl: String? = null,
        temperature: Float = 0.7f
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val messagesArray = JSONArray()
            messagesArray.put(JSONObject().apply {
                put("role", "system")
                put("content", systemPrompt)
            })

            conversationHistory.takeLast(12).forEach { (role, text) ->
                messagesArray.put(JSONObject().apply {
                    put("role", if (role == "assistant") "assistant" else "user")
                    put("content", text)
                })
            }

            if (imageBase64DataUrl != null) {
                val contentParts = JSONArray().apply {
                    put(JSONObject().apply {
                        put("type", "text")
                        put("text", userPrompt)
                    })
                    put(JSONObject().apply {
                        put("type", "image_url")
                        put("image_url", JSONObject().apply {
                            put("url", imageBase64DataUrl)
                        })
                    })
                }
                messagesArray.put(JSONObject().apply {
                    put("role", "user")
                    put("content", contentParts)
                })
            } else {
                messagesArray.put(JSONObject().apply {
                    put("role", "user")
                    put("content", userPrompt)
                })
            }

            val payload = JSONObject().apply {
                put("model", model)
                put("messages", messagesArray)
                if (!model.startsWith("o")) {
                    put("temperature", temperature.toDouble())
                }
            }

            val request = Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = extractOpenAiError(bodyString, response.code)
                    throw IllegalStateException(errorMsg)
                }
                val json = JSONObject(bodyString)
                val choices = json.getJSONArray("choices")
                if (choices.length() == 0) {
                    throw IllegalStateException("OpenAI returned no completion choices.")
                }
                choices.getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim()
            }
        }
    }

    suspend fun generateImage(
        apiKey: String,
        model: String,
        prompt: String,
        size: String = "1024x1024"
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().apply {
                put("model", model)
                put("prompt", prompt)
                put("n", 1)
                put("size", size)
            }

            val request = Request.Builder()
                .url("https://api.openai.com/v1/images/generations")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errorMsg = extractOpenAiError(bodyString, response.code)
                    throw IllegalStateException(errorMsg)
                }
                val json = JSONObject(bodyString)
                val data = json.getJSONArray("data")
                if (data.length() == 0) {
                    throw IllegalStateException("OpenAI image generation returned empty data.")
                }
                data.getJSONObject(0).getString("url")
            }
        }
    }

    suspend fun synthesizeSpeech(
        apiKey: String,
        text: String,
        voice: String = "nova",
        speed: Float = 1.0f,
        hindiIndianAccent: Boolean = false
    ): Result<ByteArray> = withContext(Dispatchers.IO) {
        runCatching {
            val instruction = if (hindiIndianAccent) {
                "Speak clearly in a warm, natural, confident Indian accent with smooth Hindi pronunciation and natural pauses."
            } else {
                "Speak clearly in a warm, natural, confident professional assistant tone with smooth phrasing and natural pauses."
            }

            val payload = JSONObject().apply {
                put("model", "gpt-4o-mini-tts")
                put("input", text.take(3600))
                put("voice", voice)
                put("instructions", instruction)
                put("speed", speed.coerceIn(0.5f, 2.0f).toDouble())
                put("response_format", "mp3")
            }

            val request = Request.Builder()
                .url("https://api.openai.com/v1/audio/speech")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val bodyString = response.body?.string().orEmpty()
                    throw IllegalStateException(extractOpenAiError(bodyString, response.code))
                }
                response.body?.bytes() ?: throw IllegalStateException("Empty audio stream returned.")
            }
        }
    }

    private fun extractOpenAiError(body: String, code: Int): String {
        return try {
            val errObj = JSONObject(body).optJSONObject("error")
            val message = errObj?.optString("message").orEmpty()
            if (message.isNotBlank()) "OpenAI Error ($code): $message" else "OpenAI HTTP $code error."
        } catch (_: Exception) {
            "OpenAI HTTP $code error."
        }
    }
}
