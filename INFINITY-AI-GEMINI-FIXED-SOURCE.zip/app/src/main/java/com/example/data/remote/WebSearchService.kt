package com.example.data.remote

import com.example.data.model.WebSearchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class WebSearchService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String): List<WebSearchResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<WebSearchResult>()
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")

        // 1. DuckDuckGo Instant Answer API
        runCatching {
            val ddgReq = Request.Builder()
                .url("https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1")
                .header("User-Agent", "InfinityAI-Android/1.0")
                .build()
            client.newCall(ddgReq).execute().use { resp ->
                if (resp.isSuccessful) {
                    val json = JSONObject(resp.body?.string().orEmpty())
                    val abstractText = json.optString("AbstractText").trim()
                    val abstractUrl = json.optString("AbstractURL").trim()
                    val heading = json.optString("Heading").trim()
                    if (abstractText.isNotBlank()) {
                        results.add(
                            WebSearchResult(
                                title = heading.ifBlank { query },
                                snippet = abstractText,
                                url = abstractUrl.ifBlank { "https://duckduckgo.com/?q=$encoded" },
                                source = json.optString("AbstractSource").ifBlank { "DuckDuckGo" }
                            )
                        )
                    }
                    val related = json.optJSONArray("RelatedTopics")
                    if (related != null) {
                        for (i in 0 until minOf(related.length(), 4)) {
                            val item = related.optJSONObject(i) ?: continue
                            val text = item.optString("Text").trim()
                            val firstUrl = item.optString("FirstURL").trim()
                            if (text.isNotBlank() && firstUrl.isNotBlank()) {
                                results.add(
                                    WebSearchResult(
                                        title = text.substringBefore(" - ").take(64),
                                        snippet = text,
                                        url = firstUrl,
                                        source = "DuckDuckGo"
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Wikipedia Search API for encyclopedic grounding
        runCatching {
            val wikiReq = Request.Builder()
                .url("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$encoded&utf8=&format=json&srlimit=4")
                .header("User-Agent", "InfinityAI-Android/1.0")
                .build()
            client.newCall(wikiReq).execute().use { resp ->
                if (resp.isSuccessful) {
                    val json = JSONObject(resp.body?.string().orEmpty())
                    val searchArr = json.optJSONObject("query")?.optJSONArray("search")
                    if (searchArr != null) {
                        for (i in 0 until searchArr.length()) {
                            val obj = searchArr.optJSONObject(i) ?: continue
                            val title = obj.optString("title").trim()
                            val rawSnippet = obj.optString("snippet")
                                .replace(Regex("<[^>]*>"), "")
                                .replace("&quot;", "\"")
                                .replace("&amp;", "&")
                                .trim()
                            if (title.isNotBlank() && rawSnippet.isNotBlank()) {
                                val slug = URLEncoder.encode(title.replace(" ", "_"), "UTF-8")
                                results.add(
                                    WebSearchResult(
                                        title = title,
                                        snippet = rawSnippet,
                                        url = "https://en.wikipedia.org/wiki/$slug",
                                        source = "Wikipedia"
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        results.distinctBy { it.url }.take(6)
    }
}
