package com.example.data.repository

import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.local.InfinityDao
import com.example.data.local.MemoryItemEntity
import com.example.data.local.StudyTopicEntity
import com.example.data.model.AiGenerationResult
import com.example.data.model.OwnerConfig
import com.example.data.model.SmartModeType
import kotlinx.coroutines.flow.Flow

class ChatRepository(
    private val dao: InfinityDao,
    private val aiRepository: AiRepository
) {
    val sessions: Flow<List<ChatSessionEntity>> = dao.observeSessions()
    val memories: Flow<List<MemoryItemEntity>> = dao.observeMemories()
    val studyTopics: Flow<List<StudyTopicEntity>> = dao.observeStudyTopics()

    fun observeMessages(sessionId: Long): Flow<List<ChatMessageEntity>> =
        dao.observeMessages(sessionId)

    suspend fun createSession(
        title: String,
        mode: SmartModeType,
        engineLabel: String
    ): Long {
        return dao.insertSession(
            ChatSessionEntity(
                title = title.take(48).ifBlank { "New Conversation" },
                mode = mode.name,
                engine = engineLabel
            )
        )
    }

    suspend fun togglePinSession(session: ChatSessionEntity) {
        dao.updateSession(session.copy(isPinned = !session.isPinned))
    }

    suspend fun deleteSession(sessionId: Long) {
        dao.deleteSession(sessionId)
    }

    suspend fun clearAllChats() {
        dao.clearAllSessions()
    }

    suspend fun sendMessage(
        sessionId: Long,
        prompt: String,
        mode: SmartModeType,
        config: OwnerConfig,
        useWebSearch: Boolean,
        attachmentLabel: String? = null,
        attachmentUri: String? = null,
        documentContext: String? = null,
        imageBase64DataUrl: String? = null,
        locationHint: String? = null
    ): Result<AiGenerationResult> {
        val existing = dao.getMessagesOnce(sessionId)
        val historyPairs = existing.map { it.role to it.content }

        dao.insertMessage(
            ChatMessageEntity(
                sessionId = sessionId,
                role = "user",
                content = prompt,
                attachmentLabel = attachmentLabel,
                attachmentUri = attachmentUri
            )
        )

        val memories = if (config.memoryEnabled) dao.getTopMemories() else emptyList()
        val result = aiRepository.generateResponse(
            prompt = prompt,
            mode = mode,
            config = config,
            history = historyPairs,
            memories = memories,
            useWebSearch = useWebSearch,
            documentContext = documentContext,
            imageBase64DataUrl = imageBase64DataUrl,
            locationHint = locationHint
        )

        result.onSuccess { aiReply ->
            val sourcesSummary = if (aiReply.webSources.isNotEmpty()) {
                aiReply.webSources.joinToString("\n") { "${it.title} — ${it.url}" }
            } else null

            dao.insertMessage(
                ChatMessageEntity(
                    sessionId = sessionId,
                    role = "assistant",
                    content = aiReply.text,
                    engineUsed = aiReply.engineLabel,
                    isSampleNotice = aiReply.isSampleNotice,
                    sourcesSummary = sourcesSummary
                )
            )

            val session = dao.getSessionById(sessionId)
            if (session != null) {
                val updatedTitle = if (existing.isEmpty()) {
                    prompt.trim().take(42).ifBlank { mode.title }
                } else session.title
                dao.updateSession(
                    session.copy(
                        title = updatedTitle,
                        mode = mode.name,
                        engine = aiReply.engineLabel,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }

        return result
    }

    suspend fun addMemory(category: String, content: String, importance: Int = 2) {
        if (content.isNotBlank()) {
            dao.insertMemory(
                MemoryItemEntity(
                    category = category,
                    content = content.trim(),
                    importance = importance
                )
            )
        }
    }

    suspend fun deleteMemory(id: Long) = dao.deleteMemory(id)

    suspend fun clearAllMemories() = dao.clearAllMemories()

    suspend fun saveStudyTopic(subject: String, topic: String, masteryPercent: Int, notes: String) {
        dao.insertStudyTopic(
            StudyTopicEntity(
                subject = subject.trim().ifBlank { "General" },
                topic = topic.trim(),
                masteryPercent = masteryPercent.coerceIn(0, 100),
                notes = notes.trim()
            )
        )
    }

    suspend fun updateStudyMastery(topic: StudyTopicEntity, delta: Int) {
        dao.updateStudyTopic(
            topic.copy(
                masteryPercent = (topic.masteryPercent + delta).coerceIn(0, 100),
                lastStudiedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteStudyTopic(id: Long) = dao.deleteStudyTopic(id)
}
