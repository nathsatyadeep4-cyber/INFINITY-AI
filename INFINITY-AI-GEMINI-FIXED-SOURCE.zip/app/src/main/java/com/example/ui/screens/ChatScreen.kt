package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.local.ChatMessageEntity
import com.example.data.model.AiEngine
import com.example.data.model.OwnerConfig
import com.example.data.model.SmartModeType
import com.example.ui.ChatUiState
import com.example.ui.components.EnginePill
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import com.example.data.model.VoiceLanguage
import com.example.ui.components.FirebaseSampleNoticeBanner
import com.example.ui.components.FormattedAiContent
import com.example.ui.theme.InfinityAiTheme
import com.example.util.MediaAndDocHelper
import com.example.util.VoiceUiState

@Composable
fun ChatScreen(
    config: OwnerConfig,
    hasOpenAiKey: Boolean,
    chatUiState: ChatUiState,
    messages: List<ChatMessageEntity>,
    voiceState: VoiceUiState,
    onSelectMode: (SmartModeType) -> Unit,
    onToggleWebSearch: () -> Unit,
    onNewChat: () -> Unit,
    onAttachImage: (Uri?) -> Unit,
    onAttachDocument: (Uri) -> Unit,
    onClearAttachments: () -> Unit,
    onSendMessage: (String) -> Unit,
    onClearError: () -> Unit,
    onStartVoiceInput: ((String) -> Unit) -> Unit,
    onStopVoiceInput: () -> Unit,
    onSpeakText: (String) -> Unit,
    onStopSpeaking: () -> Unit,
    onUpdateConfig: ((OwnerConfig) -> OwnerConfig) -> Unit,
    onOpenOwnerMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()
    val density = LocalDensity.current
    val isImeVisible = WindowInsets.ime.getBottom(density) > 0
    var messageValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(""))
    }
    var permissionMessage by remember { mutableStateOf<String?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var showVoiceControls by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onAttachImage(uri)
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onAttachDocument(uri)
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && pendingCameraUri != null) {
            onAttachImage(pendingCameraUri)
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            permissionMessage = null
            val uri = MediaAndDocHelper.createCameraImageUri(context)
            pendingCameraUri = uri
            cameraLauncher.launch(uri)
        } else {
            permissionMessage = "Camera permission denied. You can still pick a photo from the gallery."
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            permissionMessage = null
            onStartVoiceInput { transcript ->
                val current = messageValue.text
                val combined = if (current.isBlank()) transcript else "$current $transcript"
                messageValue = TextFieldValue(
                    text = combined,
                    selection = TextRange(combined.length)
                )
            }
        } else {
            permissionMessage = "Microphone permission denied. Please type your message."
        }
    }

    val hasNoticeBanner = when (config.activeEngine) {
        AiEngine.GEMINI -> config.geminiApiKey.isBlank()
        AiEngine.OPENAI -> !hasOpenAiKey
        AiEngine.SMART_AUTO -> !hasOpenAiKey && config.geminiApiKey.isBlank()
    }

    LaunchedEffect(messages.size, isImeVisible, hasNoticeBanner) {
        if (messages.isNotEmpty()) {
            val targetIndex = messages.lastIndex + if (hasNoticeBanner) 1 else 0
            listState.animateScrollToItem(targetIndex)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = chatUiState.selectedMode.title,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = chatUiState.selectedMode.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (voiceState.isSpeaking) {
                    IconButton(onClick = onStopSpeaking) {
                        Icon(
                            imageVector = Icons.Filled.Stop,
                            contentDescription = "Stop speaking",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
                if (config.voiceEnabled) {
                    IconButton(
                        onClick = { showVoiceControls = !showVoiceControls },
                        modifier = Modifier.testTag("chat_voice_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.RecordVoiceOver,
                            contentDescription = "Voice Speed, Volume & Language Settings",
                            tint = if (showVoiceControls) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(
                    onClick = onNewChat,
                    modifier = Modifier.testTag("chat_new_session_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.AddComment,
                        contentDescription = "New Chat",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        AnimatedVisibility(visible = showVoiceControls && config.voiceEnabled) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Voice Quality • ${voiceState.activeVoiceEngine}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        FilterChip(
                            selected = config.voiceAutoSpeak,
                            onClick = { onUpdateConfig { it.copy(voiceAutoSpeak = !it.voiceAutoSpeak) } },
                            label = { Text("Auto-Speak") }
                        )
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(VoiceLanguage.entries) { lang ->
                            FilterChip(
                                selected = config.voiceLanguage == lang,
                                onClick = { onUpdateConfig { it.copy(voiceLanguage = lang) } },
                                label = { Text(lang.label) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Speed ${String.format("%.2fx", config.voiceSpeechRate)}",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Slider(
                                value = config.voiceSpeechRate,
                                onValueChange = { r -> onUpdateConfig { it.copy(voiceSpeechRate = r) } },
                                valueRange = 0.6f..1.8f
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Volume ${(config.voiceVolume * 100).toInt()}%",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Slider(
                                value = config.voiceVolume,
                                onValueChange = { v -> onUpdateConfig { it.copy(voiceVolume = v) } },
                                valueRange = 0.1f..1.0f
                            )
                        }
                    }
                }
            }
        }

        // Mode & Feature chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (config.webSearchEnabled) {
                item {
                    FilterChip(
                        selected = chatUiState.useWebSearch,
                        onClick = onToggleWebSearch,
                        label = { Text("Web Search") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Public,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }
            }
            items(SmartModeType.entries) { mode ->
                FilterChip(
                    selected = chatUiState.selectedMode == mode,
                    onClick = { onSelectMode(mode) },
                    label = { Text(mode.title) }
                )
            }
        }

        permissionMessage?.let { msg ->
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { permissionMessage = null }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        chatUiState.errorMessage?.let { err ->
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = err,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onClearError, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // Messages list
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("chat_messages_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (hasNoticeBanner) {
                item(key = "sample_notice") {
                    FirebaseSampleNoticeBanner(onOpenOwnerMode = onOpenOwnerMode)
                }
            }

            if (messages.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Ready in ${chatUiState.selectedMode.title}",
                            style = MaterialTheme.typography.headlineSmall
                        )
                        Text(
                            text = "Attach photos, capture with Camera, load PDFs, toggle Web Search, or speak with Voice AI.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val starterPrompts = listOf(
                            "Explain quantum computing simply",
                            "Write a Kotlin Compose animation card",
                            "Summarize top space news today"
                        )
                        starterPrompts.forEach { prompt ->
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { onSendMessage(prompt) }
                                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                            ) {
                                Text(
                                    text = prompt,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                items(messages, key = { it.id }) { msg ->
                    val isUser = msg.role == "user"
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                    ) {
                        Surface(
                            color = if (isUser) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(
                                topStart = 18.dp,
                                topEnd = 18.dp,
                                bottomStart = if (isUser) 18.dp else 4.dp,
                                bottomEnd = if (isUser) 4.dp else 18.dp
                            ),
                            modifier = Modifier
                                .widthIn(max = 520.dp)
                                .border(
                                    1.dp,
                                    if (isUser) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                                    else MaterialTheme.colorScheme.outline,
                                    RoundedCornerShape(18.dp)
                                )
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (!isUser && msg.engineUsed.isNotBlank()) {
                                    EnginePill(
                                        label = msg.engineUsed,
                                        isSampleNotice = msg.isSampleNotice
                                    )
                                }

                                msg.attachmentUri?.let { uriStr ->
                                    AsyncImage(
                                        model = Uri.parse(uriStr),
                                        contentDescription = "Attached photo",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(160.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                    )
                                }

                                msg.attachmentLabel?.let { label ->
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                if (isUser) {
                                    Text(
                                        text = msg.content,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                } else {
                                    FormattedAiContent(text = msg.content)
                                }

                                if (!isUser) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = { onSpeakText(msg.content) },
                                            modifier = Modifier.size(34.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                                contentDescription = "Read aloud",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        IconButton(
                                            onClick = { clipboard.setText(AnnotatedString(msg.content)) },
                                            modifier = Modifier.size(34.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.ContentCopy,
                                                contentDescription = "Copy response",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(17.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (chatUiState.isSending) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text(
                            text = "INFINITY AI is thinking...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        // Pending attachment preview
        if (chatUiState.pendingImageUri != null || chatUiState.pendingDocument != null) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        chatUiState.pendingImageUri?.let { uri ->
                            AsyncImage(
                                model = uri,
                                contentDescription = "Selected image",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        }
                        Column {
                            Text(
                                text = chatUiState.pendingDocument?.displayName ?: "Image ready for Vision AI",
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            chatUiState.pendingDocument?.let { doc ->
                                Text(
                                    text = "${doc.pageCount} page(s) • ${doc.mimeType}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    IconButton(onClick = onClearAttachments) {
                        Icon(Icons.Filled.Close, contentDescription = "Remove attachment")
                    }
                }
            }
        }

        // Composer Bar (isolated composable to prevent parent recompositions from resetting IME state)
        ChatComposerBar(
            value = messageValue,
            onValueChange = { messageValue = it },
            isSending = chatUiState.isSending,
            hasAttachment = chatUiState.pendingImageUri != null || chatUiState.pendingDocument != null,
            pdfAnalysisEnabled = config.pdfAnalysisEnabled,
            voiceEnabled = config.voiceEnabled,
            voiceState = voiceState,
            onPickPhoto = {
                photoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onOpenCamera = {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
                if (granted) {
                    val uri = MediaAndDocHelper.createCameraImageUri(context)
                    pendingCameraUri = uri
                    cameraLauncher.launch(uri)
                } else {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                }
            },
            onPickDocument = {
                documentPickerLauncher.launch(arrayOf("application/pdf", "text/*"))
            },
            onToggleVoice = {
                if (voiceState.isListening) {
                    onStopVoiceInput()
                } else {
                    val granted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    if (granted) {
                        onStartVoiceInput { transcript ->
                            val current = messageValue.text
                            val combined = if (current.isBlank()) transcript else "$current $transcript"
                            messageValue = TextFieldValue(
                                text = combined,
                                selection = TextRange(combined.length)
                            )
                        }
                    } else {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            },
            onSend = {
                val toSend = messageValue.text
                if (toSend.isNotBlank() || chatUiState.pendingImageUri != null || chatUiState.pendingDocument != null) {
                    messageValue = TextFieldValue("")
                    onSendMessage(toSend)
                }
            }
        )
    }
}

@Composable
private fun ChatComposerBar(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    isSending: Boolean,
    hasAttachment: Boolean,
    pdfAnalysisEnabled: Boolean,
    voiceEnabled: Boolean,
    voiceState: VoiceUiState,
    onPickPhoto: () -> Unit,
    onOpenCamera: () -> Unit,
    onPickDocument: () -> Unit,
    onToggleVoice: () -> Unit,
    onSend: () -> Unit
) {
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current
    val canSend = !isSending && (value.text.isNotBlank() || hasAttachment)

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            if (voiceState.isListening) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Text(
                        text = if (voiceState.partialTranscript.isNotBlank()) {
                            "Listening: ${voiceState.partialTranscript}"
                        } else {
                            "Listening for Hindi or English speech..."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onPickPhoto,
                    modifier = Modifier.testTag("chat_pick_photo_button")
                ) {
                    Icon(Icons.Filled.Image, contentDescription = "Pick Photo", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(
                    onClick = onOpenCamera,
                    modifier = Modifier.testTag("chat_camera_button")
                ) {
                    Icon(Icons.Filled.CameraAlt, contentDescription = "Take Photo", tint = MaterialTheme.colorScheme.primary)
                }
                if (pdfAnalysisEnabled) {
                    IconButton(
                        onClick = onPickDocument,
                        modifier = Modifier.testTag("chat_pick_doc_button")
                    ) {
                        Icon(Icons.Filled.AttachFile, contentDescription = "Attach PDF or Document", tint = MaterialTheme.colorScheme.primary)
                    }
                }
                if (voiceEnabled) {
                    IconButton(
                        onClick = onToggleVoice,
                        modifier = Modifier.testTag("chat_voice_button")
                    ) {
                        Icon(
                            imageVector = if (voiceState.isListening) Icons.Filled.GraphicEq else Icons.Filled.Mic,
                            contentDescription = "Voice Speech-to-Text",
                            tint = if (voiceState.isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    placeholder = {
                        Text(
                            text = "Message INFINITY AI...",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    singleLine = false,
                    minLines = 1,
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        autoCorrectEnabled = true,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Send
                    ),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (canSend) {
                                onSend()
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.30f),
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester)
                        .onFocusChanged { focusState ->
                            if (focusState.isFocused) {
                                keyboardController?.show()
                            }
                        }
                        .testTag("chat_message_input"),
                    shape = RoundedCornerShape(16.dp)
                )
                IconButton(
                    onClick = onSend,
                    enabled = canSend,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (canSend) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .testTag("chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = if (canSend) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun ChatComposerBarPreview() {
    InfinityAiTheme {
        var previewValue by remember { mutableStateOf(TextFieldValue("Explain Kotlin coroutines cleanly")) }
        ChatComposerBar(
            value = previewValue,
            onValueChange = { previewValue = it },
            isSending = false,
            hasAttachment = false,
            pdfAnalysisEnabled = true,
            voiceEnabled = true,
            voiceState = VoiceUiState(),
            onPickPhoto = {},
            onOpenCamera = {},
            onPickDocument = {},
            onToggleVoice = {},
            onSend = {}
        )
    }
}

