package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.local.ChatSessionEntity
import com.example.data.model.AiEngine
import com.example.data.model.OwnerConfig
import com.example.data.model.SmartModeType
import com.example.ui.components.FirebaseSampleNoticeBanner
import com.example.ui.components.InfinityTopBar
import com.example.util.VoiceUiState

data class QuickCapability(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accentColor: Color,
    val testTag: String,
    val onClick: () -> Unit
)

@Composable
fun HomeScreen(
    config: OwnerConfig,
    hasOpenAiKey: Boolean,
    recentSessions: List<ChatSessionEntity>,
    voiceState: VoiceUiState,
    onQuickPromptSubmit: (String) -> Unit,
    onStartVoiceInput: ((String) -> Unit) -> Unit,
    onStopVoiceInput: () -> Unit,
    onOpenChatMode: (SmartModeType) -> Unit,
    onOpenToolTab: (Int) -> Unit,
    onOpenMemory: () -> Unit,
    onOpenOwnerMode: () -> Unit,
    onSelectSession: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var quickPrompt by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(""))
    }
    var micDeniedNote by remember { mutableStateOf(false) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            micDeniedNote = false
            onStartVoiceInput { transcript ->
                quickPrompt = TextFieldValue(transcript, TextRange(transcript.length))
            }
        } else {
            micDeniedNote = true
        }
    }

    val capabilities = remember(config) {
        listOf(
            QuickCapability(
                title = "Smart AI Chat",
                subtitle = "Multi-turn & Memory",
                icon = Icons.AutoMirrored.Filled.Chat,
                accentColor = Color(0xFF5CE1E6),
                testTag = "card_smart_chat",
                onClick = { onOpenChatMode(SmartModeType.CHAT) }
            ),
            QuickCapability(
                title = "Image Studio",
                subtitle = "Generate AI artwork",
                icon = Icons.Filled.Image,
                accentColor = Color(0xFFA78BFA),
                testTag = "card_image_studio",
                onClick = { onOpenToolTab(0) }
            ),
            QuickCapability(
                title = "Vision & Camera",
                subtitle = "Analyze photos & scenes",
                icon = Icons.Filled.CameraAlt,
                accentColor = Color(0xFF38BDF8),
                testTag = "card_vision_camera",
                onClick = { onOpenChatMode(SmartModeType.VISION) }
            ),
            QuickCapability(
                title = "Web Search AI",
                subtitle = "Live DuckDuckGo & Wiki",
                icon = Icons.Filled.Public,
                accentColor = Color(0xFF34D399),
                testTag = "card_web_search",
                onClick = { onOpenToolTab(4) }
            ),
            QuickCapability(
                title = "Coding Assistant",
                subtitle = "Debug, build & refactor",
                icon = Icons.Filled.Code,
                accentColor = Color(0xFFF59E0B),
                testTag = "card_coding",
                onClick = { onOpenChatMode(SmartModeType.CODING) }
            ),
            QuickCapability(
                title = "Education System",
                subtitle = "Tutor, notes & mastery",
                icon = Icons.Filled.School,
                accentColor = Color(0xFFF472B6),
                testTag = "card_education",
                onClick = { onOpenToolTab(2) }
            ),
            QuickCapability(
                title = "PDF & Docs Lab",
                subtitle = "Read PDFs & analyze",
                icon = Icons.Filled.Description,
                accentColor = Color(0xFF60A5FA),
                testTag = "card_pdf_docs",
                onClick = { onOpenToolTab(1) }
            ),
            QuickCapability(
                title = "Writing & Translate",
                subtitle = "Prose & multi-language",
                icon = Icons.Filled.Translate,
                accentColor = Color(0xFF2DD4BF),
                testTag = "card_writing_translate",
                onClick = { onOpenToolTab(3) }
            ),
            QuickCapability(
                title = "Memory Vault",
                subtitle = "Long-term AI context",
                icon = Icons.Filled.Psychology,
                accentColor = Color(0xFFC084FC),
                testTag = "card_memory_vault",
                onClick = onOpenMemory
            ),
            QuickCapability(
                title = "Writing Studio",
                subtitle = "Essays, emails & copy",
                icon = Icons.Filled.EditNote,
                accentColor = Color(0xFFFB923C),
                testTag = "card_writing_chat",
                onClick = { onOpenChatMode(SmartModeType.WRITING) }
            )
        )
    }

    Column(modifier = modifier.fillMaxSize()) {
        InfinityTopBar(
            activeEngine = config.activeEngine,
            hasOpenAiKey = hasOpenAiKey,
            onOpenOwnerMode = onOpenOwnerMode
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Studio Card with Smart AI Mode Bar
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outline,
                            RoundedCornerShape(24.dp)
                        )
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.infinity_hero_banner_1795241858402),
                        contentDescription = "INFINITY AI Studio Header",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                    )
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color(0x88090B14),
                                        Color(0xEB090B14)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.AutoAwesome,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "SMART AI MODE • DIRECT ACCESS",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }

                        Text(
                            text = "Ask, create, code, or analyze anything instantly.",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = quickPrompt,
                                onValueChange = { quickPrompt = it },
                                placeholder = {
                                    Text(
                                        if (voiceState.isListening && voiceState.partialTranscript.isNotBlank()) {
                                            voiceState.partialTranscript
                                        } else if (voiceState.isListening) {
                                            "Listening..."
                                        } else {
                                            "Ask INFINITY AI anything..."
                                        }
                                    )
                                },
                                textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.White),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    capitalization = KeyboardCapitalization.Sentences,
                                    imeAction = ImeAction.Send
                                ),
                                keyboardActions = KeyboardActions(
                                    onSend = {
                                        if (quickPrompt.text.isNotBlank()) {
                                            val q = quickPrompt.text
                                            quickPrompt = TextFieldValue("")
                                            onQuickPromptSubmit(q)
                                        } else {
                                            onOpenChatMode(SmartModeType.CHAT)
                                        }
                                    }
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("home_quick_prompt_input"),
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color(0xCC111629),
                                    unfocusedContainerColor = Color(0xAA111629),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    cursorColor = MaterialTheme.colorScheme.primary,
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = Color(0xFF33416B)
                                )
                            )

                            if (config.voiceEnabled) {
                                IconButton(
                                    onClick = {
                                        if (voiceState.isListening) {
                                            onStopVoiceInput()
                                        } else {
                                            val granted = ContextCompat.checkSelfPermission(
                                                context,
                                                Manifest.permission.RECORD_AUDIO
                                            ) == PackageManager.PERMISSION_GRANTED
                                            if (granted) {
                                                onStartVoiceInput { transcript ->
                                                    quickPrompt = TextFieldValue(transcript, TextRange(transcript.length))
                                                }
                                            } else {
                                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (voiceState.isListening) MaterialTheme.colorScheme.error
                                            else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                        .testTag("home_voice_button")
                                ) {
                                    Icon(
                                        imageVector = if (voiceState.isListening) Icons.Filled.GraphicEq else Icons.Filled.Mic,
                                        contentDescription = "Voice AI Input",
                                        tint = if (voiceState.isListening) Color.White else MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    if (quickPrompt.text.isNotBlank()) {
                                        val q = quickPrompt.text
                                        quickPrompt = TextFieldValue("")
                                        onQuickPromptSubmit(q)
                                    } else {
                                        onOpenChatMode(SmartModeType.CHAT)
                                    }
                                },
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("home_launch_chat_button"),
                                shape = RoundedCornerShape(14.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = "Send to Chat"
                                )
                            }
                        }

                        if (micDeniedNote) {
                            Text(
                                text = "Microphone permission denied. Type your prompt or grant access in Owner Mode.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            if ((config.activeEngine == AiEngine.GEMINI && config.geminiApiKey.isBlank()) ||
                (config.activeEngine == AiEngine.OPENAI && !hasOpenAiKey) ||
                (config.activeEngine == AiEngine.SMART_AUTO && !hasOpenAiKey && config.geminiApiKey.isBlank())) {
                item {
                    FirebaseSampleNoticeBanner(onOpenOwnerMode = onOpenOwnerMode)
                }
            }

            // Recent Conversations Strip
            if (recentSessions.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.History,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Recent Sessions",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                            Text(
                                text = "View All",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable(onClick = onOpenMemory)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(recentSessions.take(6), key = { it.id }) { session ->
                                Surface(
                                    modifier = Modifier
                                        .width(210.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable { onSelectSession(session.id) }
                                        .border(
                                            1.dp,
                                            MaterialTheme.colorScheme.outline,
                                            RoundedCornerShape(16.dp)
                                        ),
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = session.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${session.mode} • ${session.engine}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Capabilities Grid (2-column pairs)
            item {
                Text(
                    text = "AI Capabilities Suite",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            val rows = capabilities.chunked(2)
            items(rows) { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    pair.forEach { cap ->
                        CapabilityCard(
                            capability = cap,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (pair.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun CapabilityCard(
    capability: QuickCapability,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = capability.onClick)
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline,
                RoundedCornerShape(18.dp)
            )
            .testTag(capability.testTag),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(capability.accentColor.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = capability.icon,
                    contentDescription = capability.title,
                    tint = capability.accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = capability.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = capability.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
