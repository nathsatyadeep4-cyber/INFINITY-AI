package com.example.ui.screens

import android.Manifest
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NavigateBefore
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.StudyTopicEntity
import com.example.data.model.OwnerConfig
import com.example.data.model.SmartModeType
import com.example.data.model.WebSearchResult
import com.example.ui.ImageStudioState
import com.example.ui.ToolResultState
import com.example.ui.components.EnginePill
import com.example.ui.components.FirebaseSampleNoticeBanner
import com.example.ui.components.FormattedAiContent
import com.example.util.LoadedDocument
import com.example.util.MediaAndDocHelper
import com.example.util.NotificationAndLocationHelper
import kotlinx.coroutines.launch

@Composable
fun ToolsScreen(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    config: OwnerConfig,
    hasOpenAiKey: Boolean,
    imageStudioState: ImageStudioState,
    toolResultState: ToolResultState,
    webSearchResults: List<WebSearchResult>,
    isWebSearching: Boolean,
    studyTopics: List<StudyTopicEntity>,
    onGenerateImage: (String, String, String) -> Unit,
    onRunToolPrompt: (String, SmartModeType, String?, Boolean) -> Unit,
    onRunWebSearch: (String) -> Unit,
    onSaveStudyTopic: (String, String, String) -> Unit,
    onBoostStudyMastery: (StudyTopicEntity) -> Unit,
    onDeleteStudyTopic: (Long) -> Unit,
    onSpeakText: (String) -> Unit,
    onOpenOwnerMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tabs = listOf("Image Studio", "PDF & Docs", "Education", "Write & Translate", "Web Search")

    Column(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text(
                text = "INFINITY AI Tools",
                style = MaterialTheme.typography.headlineMedium
            )
            Text(
                text = "Specialized studios for creation, study, documents & live research",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        ScrollableTabRow(
            selectedTabIndex = selectedTab.coerceIn(0, tabs.lastIndex),
            edgePadding = 12.dp
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { onSelectTab(index) },
                    text = { Text(title) },
                    modifier = Modifier.testTag("tools_tab_$index")
                )
            }
        }

        when (selectedTab) {
            0 -> ImageStudioTab(
                config = config,
                hasOpenAiKey = hasOpenAiKey,
                state = imageStudioState,
                onGenerateImage = onGenerateImage,
                onOpenOwnerMode = onOpenOwnerMode
            )
            1 -> PdfAndDocsTab(
                config = config,
                toolResultState = toolResultState,
                onRunToolPrompt = onRunToolPrompt,
                onSpeakText = onSpeakText
            )
            2 -> EducationTab(
                config = config,
                studyTopics = studyTopics,
                toolResultState = toolResultState,
                onSaveStudyTopic = onSaveStudyTopic,
                onBoostStudyMastery = onBoostStudyMastery,
                onDeleteStudyTopic = onDeleteStudyTopic,
                onRunToolPrompt = onRunToolPrompt
            )
            3 -> WriteAndTranslateTab(
                toolResultState = toolResultState,
                onRunToolPrompt = onRunToolPrompt,
                onSpeakText = onSpeakText
            )
            else -> WebSearchTab(
                webSearchResults = webSearchResults,
                isWebSearching = isWebSearching,
                toolResultState = toolResultState,
                onRunWebSearch = onRunWebSearch
            )
        }
    }
}

@Composable
private fun ImageStudioTab(
    config: OwnerConfig,
    hasOpenAiKey: Boolean,
    state: ImageStudioState,
    onGenerateImage: (String, String, String) -> Unit,
    onOpenOwnerMode: () -> Unit
) {
    var prompt by remember { mutableStateOf("") }
    var aspectRatio by remember { mutableStateOf("1:1") }
    var stylePreset by remember { mutableStateOf("Cinematic Digital Art") }
    val ratios = listOf("1:1", "16:9", "9:16")
    val styles = listOf("Cinematic Digital Art", "Minimalist 3D", "Photorealistic", "Cyberpunk Neon", "Watercolor")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!hasOpenAiKey) {
            item { FirebaseSampleNoticeBanner(onOpenOwnerMode = onOpenOwnerMode) }
        }
        item {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text("Describe the image you want to create") },
                minLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("image_studio_prompt"),
                shape = RoundedCornerShape(16.dp)
            )
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Aspect Ratio", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ratios.forEach { r ->
                        FilterChip(
                            selected = aspectRatio == r,
                            onClick = { aspectRatio = r },
                            label = { Text(r) }
                        )
                    }
                }
                Text("Visual Style", style = MaterialTheme.typography.titleSmall)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(styles) { s ->
                        FilterChip(
                            selected = stylePreset == s,
                            onClick = { stylePreset = s },
                            label = { Text(s) }
                        )
                    }
                }
            }
        }
        item {
            Button(
                onClick = { onGenerateImage(prompt, aspectRatio, stylePreset) },
                enabled = config.imageGenEnabled && prompt.isNotBlank() && state !is ImageStudioState.Loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("image_studio_generate_button"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(" Generate Artwork")
            }
        }
        item {
            when (state) {
                is ImageStudioState.Idle -> {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Image, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
                            Text("AI Image Studio Ready", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Uses DALL-E 3 when an OpenAI key is configured in Owner Mode, or Gemini Nano Banana sample preview.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                is ImageStudioState.Loading -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator()
                        Text("Synthesizing image...", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                is ImageStudioState.Error -> {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = state.message,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
                is ImageStudioState.Success -> {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            EnginePill(label = state.result.engineLabel, isSampleNotice = state.result.isSampleNotice)
                            state.result.imageUrl?.let { url ->
                                AsyncImage(
                                    model = url,
                                    contentDescription = "Generated AI Artwork",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(280.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                )
                            }
                            Text(state.result.caption, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfAndDocsTab(
    config: OwnerConfig,
    toolResultState: ToolResultState,
    onRunToolPrompt: (String, SmartModeType, String?, Boolean) -> Unit,
    onSpeakText: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var loadedDoc by remember { mutableStateOf<LoadedDocument?>(null) }
    var currentPageIndex by remember { mutableIntStateOf(0) }
    var renderedPageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var docQuestion by remember { mutableStateOf("Summarize the main findings and action items.") }
    var loadError by remember { mutableStateOf<String?>(null) }

    val docPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                MediaAndDocHelper.loadDocument(context, uri)
                    .onSuccess { doc ->
                        loadedDoc = doc
                        currentPageIndex = 0
                        loadError = null
                        if (doc.isPdf) {
                            renderedPageBitmap = MediaAndDocHelper.renderPdfPage(context, uri, 0)
                        } else {
                            renderedPageBitmap = null
                        }
                    }
                    .onFailure { err ->
                        loadError = err.localizedMessage ?: "Failed to open document."
                    }
            }
        }
    }

    LaunchedEffect(loadedDoc, currentPageIndex) {
        val doc = loadedDoc
        if (doc != null && doc.isPdf) {
            renderedPageBitmap = MediaAndDocHelper.renderPdfPage(context, Uri.parse(doc.uriString), currentPageIndex)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedButton(
                onClick = { docPicker.launch(arrayOf("application/pdf", "text/*")) },
                enabled = config.pdfAnalysisEnabled,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("pdf_open_document_button"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(" Open PDF or Text Document")
            }
        }

        loadError?.let { err ->
            item {
                Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }

        loadedDoc?.let { doc ->
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(doc.displayName, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "${doc.mimeType} • ${doc.pageCount} page(s)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (doc.isPdf && renderedPageBitmap != null) {
                            Image(
                                bitmap = renderedPageBitmap!!.asImageBitmap(),
                                contentDescription = "PDF Page ${currentPageIndex + 1}",
                                contentScale = ContentScale.FillWidth,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.background)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { if (currentPageIndex > 0) currentPageIndex-- },
                                    enabled = currentPageIndex > 0
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.NavigateBefore, contentDescription = "Previous Page")
                                }
                                Text(
                                    text = "Page ${currentPageIndex + 1} of ${doc.pageCount}",
                                    style = MaterialTheme.typography.labelLarge
                                )
                                IconButton(
                                    onClick = { if (currentPageIndex < doc.pageCount - 1) currentPageIndex++ },
                                    enabled = currentPageIndex < doc.pageCount - 1
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = "Next Page")
                                }
                            }
                        } else {
                            Text(
                                text = doc.extractedText.take(600),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = docQuestion,
                onValueChange = { docQuestion = it },
                label = { Text("Ask AI about this document") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    onRunToolPrompt(
                        docQuestion,
                        SmartModeType.DOCUMENT,
                        loadedDoc?.extractedText ?: "No external file selected; analyze prompt directly.",
                        false
                    )
                },
                enabled = config.pdfAnalysisEnabled && docQuestion.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Analyze Document with AI")
            }
        }

        item { ToolResultCard(toolResultState, onSpeakText = onSpeakText) }
    }
}

@Composable
private fun EducationTab(
    config: OwnerConfig,
    studyTopics: List<StudyTopicEntity>,
    toolResultState: ToolResultState,
    onSaveStudyTopic: (String, String, String) -> Unit,
    onBoostStudyMastery: (StudyTopicEntity) -> Unit,
    onDeleteStudyTopic: (Long) -> Unit,
    onRunToolPrompt: (String, SmartModeType, String?, Boolean) -> Unit
) {
    val context = LocalContext.current
    var subject by remember { mutableStateOf("Computer Science") }
    var topic by remember { mutableStateOf("") }
    var reminderStatus by remember { mutableStateOf<String?>(null) }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            NotificationAndLocationHelper.postAiNotification(
                context,
                "INFINITY AI Study Reminder",
                "Time for a quick study session on ${topic.ifBlank { subject }}!"
            )
            reminderStatus = "Study reminder notification sent!"
        } else {
            reminderStatus = "Notification permission denied; study topic saved locally."
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("Education Tutor & Study Tracker", style = MaterialTheme.typography.titleMedium)
                    }
                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subject") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text("Topic or Question (e.g., Dynamic Programming)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                onRunToolPrompt(
                                    "Teach me $topic in $subject step-by-step with a 3-question quiz at the end.",
                                    SmartModeType.EDUCATION,
                                    null,
                                    false
                                )
                            },
                            enabled = config.educationEnabled && topic.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Generate Lesson")
                        }
                        OutlinedButton(
                            onClick = {
                                if (topic.isNotBlank()) {
                                    onSaveStudyTopic(subject, topic, "Tracked in INFINITY AI")
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                        !NotificationAndLocationHelper.hasNotificationPermission(context)
                                    ) {
                                        notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    } else {
                                        reminderStatus = "Study topic saved to tracker."
                                    }
                                }
                            },
                            enabled = topic.isNotBlank()
                        ) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text(" Track")
                        }
                    }
                    reminderStatus?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        item { ToolResultCard(toolResultState, onSpeakText = null) }

        if (studyTopics.isNotEmpty()) {
            item {
                Text("Your Study Mastery", style = MaterialTheme.typography.titleMedium)
            }
            items(studyTopics, key = { it.id }) { item ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.subject.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Text(item.topic, style = MaterialTheme.typography.titleSmall)
                            }
                            Row {
                                IconButton(onClick = { onBoostStudyMastery(item) }) {
                                    Icon(Icons.Filled.Add, contentDescription = "Boost Mastery", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(onClick = { onDeleteStudyTopic(item.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete Topic", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                        LinearProgressIndicator(
                            progress = { item.masteryPercent / 100f },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                        )
                        Text("${item.masteryPercent}% Mastery", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun WriteAndTranslateTab(
    toolResultState: ToolResultState,
    onRunToolPrompt: (String, SmartModeType, String?, Boolean) -> Unit,
    onSpeakText: (String) -> Unit
) {
    var subMode by remember { mutableIntStateOf(0) } // 0 = Writing, 1 = Translation
    var sourceText by remember { mutableStateOf("") }
    var targetLanguage by remember { mutableStateOf("Spanish") }
    var writingFormat by remember { mutableStateOf("Executive Email") }

    val languages = listOf("Spanish", "French", "Hindi", "Japanese", "German", "Arabic")
    val formats = listOf("Executive Email", "Blog Article", "Essay Outline", "Social Post", "Technical Spec")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = subMode == 0,
                    onClick = { subMode = 0 },
                    label = { Text("Writing Assistant") },
                    leadingIcon = { Icon(Icons.Filled.EditNote, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                FilterChip(
                    selected = subMode == 1,
                    onClick = { subMode = 1 },
                    label = { Text("Translator Pro") },
                    leadingIcon = { Icon(Icons.Filled.Translate, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }
        }

        item {
            if (subMode == 0) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(formats) { f ->
                        FilterChip(selected = writingFormat == f, onClick = { writingFormat = f }, label = { Text(f) })
                    }
                }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(languages) { lang ->
                        FilterChip(selected = targetLanguage == lang, onClick = { targetLanguage = lang }, label = { Text(lang) })
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = sourceText,
                onValueChange = { sourceText = it },
                label = {
                    Text(if (subMode == 0) "Topic, bullet points, or rough draft" else "Text to translate into $targetLanguage")
                },
                minLines = 4,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = {
                    if (subMode == 0) {
                        onRunToolPrompt(
                            "Write a polished $writingFormat based on: $sourceText",
                            SmartModeType.WRITING,
                            null,
                            false
                        )
                    } else {
                        onRunToolPrompt(
                            "Translate the following into natural, idiomatic $targetLanguage and include brief pronunciation notes:\n$sourceText",
                            SmartModeType.TRANSLATION,
                            null,
                            false
                        )
                    }
                },
                enabled = sourceText.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(if (subMode == 0) "Generate Polished Draft" else "Translate to $targetLanguage")
            }
        }

        item { ToolResultCard(toolResultState, onSpeakText = onSpeakText) }
    }
}

@Composable
private fun WebSearchTab(
    webSearchResults: List<WebSearchResult>,
    isWebSearching: Boolean,
    toolResultState: ToolResultState,
    onRunWebSearch: (String) -> Unit
) {
    val uriHandler = LocalUriHandler.current
    var query by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search the live web (DuckDuckGo + Wikipedia)") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("web_search_input"),
                    shape = RoundedCornerShape(14.dp)
                )
                Button(
                    onClick = { onRunWebSearch(query) },
                    enabled = query.isNotBlank() && !isWebSearching,
                    modifier = Modifier.height(54.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.Search, contentDescription = "Search")
                }
            }
        }

        if (isWebSearching) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text("Searching DuckDuckGo & Wikipedia...")
                }
            }
        }

        item { ToolResultCard(toolResultState, onSpeakText = null) }

        if (webSearchResults.isNotEmpty()) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Filled.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Text("Live Web Sources (${webSearchResults.size})", style = MaterialTheme.typography.titleMedium)
                }
            }
            items(webSearchResults) { res ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { runCatching { uriHandler.openUri(res.url) } }
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = res.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                contentDescription = "Open link",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = res.snippet,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${res.source} • ${res.url}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolResultCard(
    state: ToolResultState,
    onSpeakText: ((String) -> Unit)?
) {
    when (state) {
        is ToolResultState.Idle -> Unit
        is ToolResultState.Loading -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Text("Processing with INFINITY AI...", style = MaterialTheme.typography.bodySmall)
            }
        }
        is ToolResultState.Error -> {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(state.message, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(14.dp))
            }
        }
        is ToolResultState.Success -> {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        EnginePill(label = state.engineLabel, isSampleNotice = state.isSampleNotice)
                        onSpeakText?.let { speak ->
                            IconButton(onClick = { speak(state.text) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Read aloud", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    FormattedAiContent(text = state.text)
                }
            }
        }
    }
}
