package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Neural Palette (Obsidian Cosmic + Electric Cyan + Quantum Violet)
val ObsidianVoid = Color(0xFF090B14)
val ObsidianSurface = Color(0xFF111629)
val ObsidianSurfaceHigh = Color(0xFF182039)
val ObsidianOutline = Color(0xFF28345C)

val ElectricCyan = Color(0xFF5CE1E6)
val DeepCyanContainer = Color(0xFF0C3A44)
val QuantumViolet = Color(0xFF8B6EFF)
val DeepVioletContainer = Color(0xFF2A1F5D)
val SkyPulse = Color(0xFF38BDF8)
val SolarAmber = Color(0xFFF59E0B)
val SolarAmberContainer = Color(0xFF3F2A08)
val EmeraldSuccess = Color(0xFF34D399)
val CoralError = Color(0xFFF87171)
val CoralErrorContainer = Color(0xFF4C1419)

val TextPrimaryDark = Color(0xFFF1F5FF)
val TextSecondaryDark = Color(0xFF9BA8CB)

// Light Theme Tokens
val AlabasterBg = Color(0xFFF5F7FC)
val AlabasterSurface = Color(0xFFFFFFFF)
val AlabasterSurfaceHigh = Color(0xFFEAF0FA)
val AlabasterOutline = Color(0xFFD0DAF0)

val IndigoPrimaryLight = Color(0xFF4338CA)
val IndigoContainerLight = Color(0xFFE0E7FF)
val CyanSecondaryLight = Color(0xFF0891B2)
val CyanContainerLight = Color(0xFFCFFAFE)
val AmberOwnerLight = Color(0xFFB45309)
val AmberContainerLight = Color(0xFFFEF3C7)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
