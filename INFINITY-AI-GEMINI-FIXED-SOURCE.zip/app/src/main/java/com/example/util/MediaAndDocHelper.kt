package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

data class LoadedDocument(
    val displayName: String,
    val mimeType: String,
    val isPdf: Boolean,
    val pageCount: Int,
    val extractedText: String,
    val uriString: String
)

object MediaAndDocHelper {

    fun createCameraImageUri(context: Context): Uri {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    suspend fun encodeImageToDataUrl(context: Context, uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val stream = context.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Unable to read selected image.")
            val original = stream.use { BitmapFactory.decodeStream(it) }
                ?: throw IllegalStateException("Unsupported image format.")

            val maxDim = 1024
            val scale = minOf(1f, maxDim.toFloat() / maxOf(original.width, original.height))
            val scaled = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    original,
                    (original.width * scale).toInt().coerceAtLeast(1),
                    (original.height * scale).toInt().coerceAtLeast(1),
                    true
                )
            } else {
                original
            }

            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
            val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            "data:image/jpeg;base64,$b64"
        }
    }

    fun getDisplayName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) return cursor.getString(idx) ?: "Document"
            }
        }
        return uri.lastPathSegment ?: "Document"
    }

    suspend fun loadDocument(context: Context, uri: Uri): Result<LoadedDocument> = withContext(Dispatchers.IO) {
        runCatching {
            val mime = context.contentResolver.getType(uri).orEmpty()
            val name = getDisplayName(context, uri)
            val isPdf = mime.contains("pdf", ignoreCase = true) || name.endsWith(".pdf", ignoreCase = true)

            if (isPdf) {
                val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                    ?: throw IllegalStateException("Cannot open PDF file.")
                val pages = pfd.use { descriptor ->
                    PdfRenderer(descriptor).use { renderer -> renderer.pageCount }
                }
                LoadedDocument(
                    displayName = name,
                    mimeType = mime.ifBlank { "application/pdf" },
                    isPdf = true,
                    pageCount = pages,
                    extractedText = "PDF Document: $name ($pages page(s)). Loaded into INFINITY AI PDF Reader.",
                    uriString = uri.toString()
                )
            } else {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                    it.readText().take(12000)
                }.orEmpty()
                LoadedDocument(
                    displayName = name,
                    mimeType = mime.ifBlank { "text/plain" },
                    isPdf = false,
                    pageCount = 1,
                    extractedText = text.ifBlank { "Empty or binary document ($name)." },
                    uriString = uri.toString()
                )
            }
        }
    }

    suspend fun renderPdfPage(context: Context, uri: Uri, pageIndex: Int): Bitmap? = withContext(Dispatchers.IO) {
        runCatching {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return@runCatching null
            pfd.use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    if (pageIndex < 0 || pageIndex >= renderer.pageCount) return@use null
                    renderer.openPage(pageIndex).use { page ->
                        val width = (page.width * 2).coerceIn(400, 1440)
                        val height = ((page.height.toFloat() / page.width.coerceAtLeast(1)) * width).toInt().coerceAtLeast(400)
                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bitmap
                    }
                }
            }
        }.getOrNull()
    }
}
