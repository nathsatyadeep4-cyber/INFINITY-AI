package com.example.util

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.data.model.OwnerConfig
import com.example.data.model.VoiceLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.Locale

data class VoiceUiState(
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val activeVoiceEngine: String = "HD System Voice",
    val activeLanguageLabel: String = "Auto (Hindi & English)",
    val partialTranscript: String = "",
    val errorMessage: String? = null
)

class VoiceManager(private val context: Context) {

    private val _state = MutableStateFlow(VoiceUiState())
    val state: StateFlow<VoiceUiState> = _state.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady: Boolean = false
    private var mediaPlayer: MediaPlayer? = null
    private var currentAudioTempFile: File? = null

    private val speechAudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setAudioAttributes(speechAudioAttributes)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _state.value = _state.value.copy(isSpeaking = true)
                    }

                    override fun onDone(utteranceId: String?) {
                        _state.value = _state.value.copy(isSpeaking = false)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _state.value = _state.value.copy(isSpeaking = false)
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _state.value = _state.value.copy(isSpeaking = false)
                    }
                })
                applyBestVoiceForLocale(Locale.US)
            }
        }
    }

    fun startListening(
        language: VoiceLanguage = VoiceLanguage.AUTO_DETECT,
        onFinalResult: (String) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _state.value = _state.value.copy(
                isListening = false,
                errorMessage = "Speech recognition service is unavailable on this device."
            )
            return
        }
        stopListening()

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        speechRecognizer = recognizer
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _state.value = _state.value.copy(isListening = true, errorMessage = null, partialTranscript = "")
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _state.value = _state.value.copy(isListening = false)
            }

            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error during speech recognition."
                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please speak clearly and try again."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out."
                    else -> "Speech recognition error ($error)."
                }
                _state.value = _state.value.copy(isListening = false, errorMessage = msg)
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                _state.value = _state.value.copy(isListening = false, partialTranscript = "")
                if (text.isNotBlank()) {
                    onFinalResult(text)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                _state.value = _state.value.copy(partialTranscript = partial)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val recognitionTag = when (language) {
            VoiceLanguage.HINDI_IN -> "hi-IN"
            VoiceLanguage.ENGLISH_IN -> "en-IN"
            VoiceLanguage.ENGLISH_US -> "en-US"
            VoiceLanguage.AUTO_DETECT -> Locale.getDefault().toLanguageTag()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, recognitionTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, recognitionTag)
        }
        recognizer.startListening(intent)
    }

    fun stopListening() {
        runCatching {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        }
        speechRecognizer = null
        _state.value = _state.value.copy(isListening = false)
    }

    fun speakWithSystemTts(
        rawText: String,
        config: OwnerConfig
    ) {
        if (!ttsReady || rawText.isBlank()) return
        stopMediaPlayer()

        val cleanSpeech = prepareNaturalSpeechText(rawText)
        if (cleanSpeech.isBlank()) return

        val locale = resolveTargetLocale(rawText, config.voiceLanguage)
        val selectedVoiceDesc = applyBestVoiceForLocale(locale)

        val rate = config.voiceSpeechRate.coerceIn(0.6f, 1.8f)
        val pitch = config.voicePitch.coerceIn(0.85f, 1.15f)
        val volume = config.voiceVolume.coerceIn(0.0f, 1.0f)

        tts?.setSpeechRate(rate)
        tts?.setPitch(pitch)

        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume)
        }

        val langLabel = if (locale.language == "hi") "Hindi (India)" else "English (${locale.country.ifBlank { "Natural" }})"
        _state.value = _state.value.copy(
            isSpeaking = true,
            activeVoiceEngine = selectedVoiceDesc,
            activeLanguageLabel = langLabel,
            errorMessage = null
        )

        val chunks = splitIntoNaturalChunks(cleanSpeech)
        chunks.forEachIndexed { index, chunk ->
            val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val utteranceId = if (index == chunks.lastIndex) "infinity_tts_last" else "infinity_tts_$index"
            tts?.speak(chunk, queueMode, params, utteranceId)
        }
    }

    fun playNeuralAudioBytes(
        audioBytes: ByteArray,
        volume: Float,
        voiceLabel: String,
        languageLabel: String,
        onPlaybackError: () -> Unit
    ) {
        stopSpeaking()
        runCatching {
            val cacheFile = File(context.cacheDir, "infinity_tts_${System.currentTimeMillis()}.mp3")
            cacheFile.writeBytes(audioBytes)
            currentAudioTempFile = cacheFile

            val player = MediaPlayer().apply {
                setAudioAttributes(speechAudioAttributes)
                setDataSource(cacheFile.absolutePath)
                setVolume(volume.coerceIn(0f, 1f), volume.coerceIn(0f, 1f))
                setOnPreparedListener { mp ->
                    _state.value = _state.value.copy(
                        isSpeaking = true,
                        activeVoiceEngine = voiceLabel,
                        activeLanguageLabel = languageLabel,
                        errorMessage = null
                    )
                    mp.start()
                }
                setOnCompletionListener {
                    _state.value = _state.value.copy(isSpeaking = false)
                    stopMediaPlayer()
                }
                setOnErrorListener { _, _, _ ->
                    _state.value = _state.value.copy(isSpeaking = false)
                    stopMediaPlayer()
                    onPlaybackError()
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        }.onFailure {
            stopMediaPlayer()
            onPlaybackError()
        }
    }

    fun stopSpeaking() {
        runCatching { tts?.stop() }
        stopMediaPlayer()
        _state.value = _state.value.copy(isSpeaking = false)
    }

    private fun stopMediaPlayer() {
        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        mediaPlayer = null
        runCatching { currentAudioTempFile?.delete() }
        currentAudioTempFile = null
    }

    fun clearError() {
        _state.value = _state.value.copy(errorMessage = null)
    }

    fun release() {
        stopListening()
        stopSpeaking()
        runCatching { tts?.shutdown() }
        tts = null
    }

    private fun applyBestVoiceForLocale(locale: Locale): String {
        val engine = tts ?: return "System Voice"
        val voices = runCatching { engine.voices.orEmpty() }.getOrElse { emptySet() }

        val bestVoice = selectHighestQualityVoice(voices, locale)
        if (bestVoice != null) {
            engine.voice = bestVoice
            return if (bestVoice.quality >= Voice.QUALITY_HIGH) {
                "HD Natural Voice (${bestVoice.locale.toLanguageTag()})"
            } else {
                "Natural Voice (${bestVoice.locale.toLanguageTag()})"
            }
        }

        val langResult = engine.setLanguage(locale)
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (locale.language == "hi") {
                engine.setLanguage(Locale("en", "IN"))
                return "Indian English Voice"
            } else {
                engine.setLanguage(Locale.US)
                return "Standard Natural Voice"
            }
        }
        return "Natural Voice (${locale.toLanguageTag()})"
    }

    companion object {
        private val HINDI_ROMANIZED_HINTS = setOf(
            "namaste", "kaise", "kya", "hai", "hain", "aap", "main", "hum", "tum",
            "acha", "accha", "theek", "thik", "shukriya", "dhanyawad", "dhanyavad",
            "nahi", "nahin", "haan", "batao", "samjhao", "madad", "kripya"
        )

        fun resolveTargetLocale(text: String, preference: VoiceLanguage): Locale {
            return when (preference) {
                VoiceLanguage.HINDI_IN -> Locale("hi", "IN")
                VoiceLanguage.ENGLISH_IN -> Locale("en", "IN")
                VoiceLanguage.ENGLISH_US -> Locale.US
                VoiceLanguage.AUTO_DETECT -> {
                    if (containsHindi(text)) Locale("hi", "IN") else Locale.US
                }
            }
        }

        fun containsHindi(text: String): Boolean {
            if (text.any { ch -> ch in '\u0900'..'\u097F' }) return true
            val words = text.lowercase()
                .split(Regex("[^a-z]+"))
                .filter { it.isNotBlank() }
            val matches = words.count { it in HINDI_ROMANIZED_HINTS }
            return matches >= 2
        }

        fun prepareNaturalSpeechText(raw: String): String {
            var text = raw
                // Replace fenced code blocks with a spoken summary instead of reading syntax symbols
                .replace(Regex("```[\\s\\S]*?```"), " See the code snippet on your screen. ")
                // Replace inline code backticks cleanly
                .replace("`", "")
                // Replace URLs with clean spoken word
                .replace(Regex("https?://\\S+"), "link")
                // Strip markdown headings, bold, italics, and blockquotes
                .replace(Regex("[*_~>#]+"), "")
                // Convert bullet markers at line starts into natural pauses
                .replace(Regex("(?m)^\\s*[-•]\\s+"), "")
                // Replace line breaks with natural sentence pauses
                .replace(Regex("\\n+"), ". ")
                // Smooth punctuation into clean pauses
                .replace("—", ", ")
                .replace(";", ", ")
                .replace(":", ", ")
                // Collapse repeated dots/spaces
                .replace(Regex("\\.\\s*\\.+"), ".")
                .replace(Regex("\\s{2,}"), " ")
                .trim()

            // Remove bracketed sample prefixes so speech sounds clean
            text = text.replace(Regex("\\[Sample Gemini Response[^\\]]*\\]"), "").trim()
            return text.take(3600)
        }

        fun splitIntoNaturalChunks(text: String, maxChunkChars: Int = 420): List<String> {
            if (text.length <= maxChunkChars) return listOf(text)
            val sentences = text.split(Regex("(?<=[.!?।])\\s+"))
            val chunks = mutableListOf<String>()
            val current = StringBuilder()
            for (sentence in sentences) {
                if (current.length + sentence.length + 1 > maxChunkChars && current.isNotEmpty()) {
                    chunks.add(current.toString().trim())
                    current.clear()
                }
                if (current.isNotEmpty()) current.append(' ')
                current.append(sentence)
            }
            if (current.isNotEmpty()) chunks.add(current.toString().trim())
            return chunks
        }

        fun selectHighestQualityVoice(voices: Set<Voice>, targetLocale: Locale): Voice? {
            if (voices.isEmpty()) return null
            val sameLang = voices.filter { v ->
                v.locale.language.equals(targetLocale.language, ignoreCase = true) &&
                    !v.name.contains("espeak", ignoreCase = true)
            }
            if (sameLang.isEmpty()) return null

            return sameLang.maxByOrNull { voice ->
                var score = 0
                if (voice.locale.country.equals(targetLocale.country, ignoreCase = true)) score += 40
                score += when (voice.quality) {
                    Voice.QUALITY_VERY_HIGH -> 100
                    Voice.QUALITY_HIGH -> 80
                    Voice.QUALITY_NORMAL -> 40
                    else -> 10
                }
                if (!voice.isNetworkConnectionRequired) score += 20 // Smooth, zero-jitter local HD voices
                if (voice.name.contains("neural", ignoreCase = true) ||
                    voice.name.contains("wavenet", ignoreCase = true) ||
                    voice.name.contains("natural", ignoreCase = true) ||
                    voice.name.contains("x-iom", ignoreCase = true) ||
                    voice.name.contains("sfg", ignoreCase = true)
                ) {
                    score += 30
                }
                score
            }
        }
    }
}
