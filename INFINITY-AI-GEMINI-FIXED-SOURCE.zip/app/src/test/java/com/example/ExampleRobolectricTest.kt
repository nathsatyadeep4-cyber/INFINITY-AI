package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.hasScrollToIndexAction
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.performImeAction
import androidx.compose.ui.test.performScrollToIndex
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTextReplacement
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun appName_isInfinityAi() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("INFINITY AI", context.getString(R.string.app_name))
    }

    @Test
    fun appLaunchesDirectlyToHomeScreenWithoutLogin() {
        composeRule.waitForIdle()
        composeRule.onNodeWithText("INFINITY AI").assertIsDisplayed()
        composeRule.onNodeWithTag("home_quick_prompt_input").assertIsDisplayed()
        composeRule.onNode(hasScrollToIndexAction()).performScrollToIndex(3)
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("card_smart_chat").assertIsDisplayed()
    }

    @Test
    fun chatInputField_supportsTypingDeletingPastingAndSending() {
        composeRule.waitForIdle()

        // Navigate directly to AI Chat
        composeRule.onNodeWithTag("nav_chat").performClick()
        composeRule.waitForIdle()

        val inputNode = composeRule.onNodeWithTag("chat_message_input")
        inputNode.assertIsDisplayed()

        // 1. Typing characters
        inputNode.performClick()
        inputNode.performTextInput("Hello INFINITY")
        composeRule.waitForIdle()
        inputNode.assertTextContains("Hello INFINITY")

        // 2. Deleting / editing characters
        inputNode.performTextClearance()
        composeRule.waitForIdle()
        inputNode.performTextInput("Hello")
        composeRule.waitForIdle()
        inputNode.assertTextContains("Hello")

        // 3. Pasting / replacing multi-word text
        val pastedMessage = "Explain Jetpack Compose state hoisting cleanly"
        inputNode.performTextReplacement(pastedMessage)
        composeRule.waitForIdle()
        inputNode.assertTextContains(pastedMessage)

        // 4. Sending the exact typed message and clearing input
        composeRule.onNodeWithTag("chat_send_button").performClick()
        composeRule.waitForIdle()
        inputNode.assertTextEquals("Message INFINITY AI...", "")

        // Wait for Room + AI repository async emission and verify user message + AI reply
        composeRule.waitUntil(timeoutMillis = 5000) {
            composeRule.onAllNodesWithText(pastedMessage).fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("chat_messages_list").performScrollToNode(hasText(pastedMessage))
        composeRule.waitForIdle()
        composeRule.onNodeWithText(pastedMessage).assertIsDisplayed()
    }

    @Test
    fun homeQuickPromptInput_supportsTypingAndImeSendToChat() {
        composeRule.waitForIdle()
        val quickInput = composeRule.onNodeWithTag("home_quick_prompt_input")
        quickInput.assertIsDisplayed()
        val prompt = "Hello from Home bar"
        quickInput.performTextInput(prompt)
        composeRule.waitForIdle()
        quickInput.assertTextContains(prompt)
        quickInput.performImeAction()

        composeRule.waitUntil(timeoutMillis = 5000) {
            composeRule.onAllNodesWithText(prompt).fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("chat_message_input").assertIsDisplayed()
        composeRule.onNodeWithTag("chat_messages_list").performScrollToNode(hasText(prompt))
        composeRule.waitForIdle()
        composeRule.onNodeWithText(prompt).assertIsDisplayed()
    }

    @Test
    fun navigationTabs_reachToolsMemoryAndOwnerMode() {
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("nav_tools").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("INFINITY AI Tools").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_memory").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Memory & History").assertIsDisplayed()
        composeRule.onNodeWithTag("memory_input_field").performTextInput("Prefer Jetpack Compose")
        composeRule.onNodeWithTag("add_memory_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Prefer Jetpack Compose").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_owner").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("OWNER MODE").assertIsDisplayed()
        composeRule.onNodeWithTag("owner_lazy_column").performScrollToIndex(2)
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("owner_openai_key_input").assertIsDisplayed()
    }
}
