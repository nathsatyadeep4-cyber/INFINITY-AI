package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.configureAppCheck
import com.example.ui.screens.AppShell
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.SuspendedAccountScreen
import com.example.ui.theme.InfinityAiTheme
import com.example.ui.viewmodel.AuthUiState
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check with launch intent BEFORE setContent or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            val context = LocalContext.current
            val authViewModel: AuthViewModel = viewModel(
                factory = AuthViewModel.provideFactory(context)
            )
            val authState by authViewModel.authState.collectAsStateWithLifecycle()
            val isSigningIn by authViewModel.isSigningIn.collectAsStateWithLifecycle()
            var splashComplete by remember { mutableStateOf(false) }

            LaunchedEffect(Unit) {
                authViewModel.tryAutoSignInIfNeeded(context)
                delay(1000L)
                splashComplete = true
            }

            InfinityAiRoot(
                splashComplete = splashComplete,
                authState = authState,
                isSigningIn = isSigningIn,
                onGoogleSignInClick = { authViewModel.signInWithGoogle(context) },
                onCancelSignInClick = { authViewModel.cancelSignIn() },
                onDismissErrorClick = { authViewModel.dismissError() },
                onSignOutClick = { authViewModel.signOut(context) }
            )
        }
    }
}

@Composable
private fun InfinityAiRoot(
    splashComplete: Boolean,
    authState: AuthUiState,
    isSigningIn: Boolean,
    onGoogleSignInClick: () -> Unit,
    onCancelSignInClick: () -> Unit,
    onDismissErrorClick: () -> Unit,
    onSignOutClick: () -> Unit
) {
    val context = LocalContext.current

    if (!splashComplete || authState is AuthUiState.Initializing) {
        InfinityAiTheme(darkTheme = true) {
            SplashScreen()
        }
        return
    }

    when (authState) {
        is AuthUiState.Initializing -> {
            InfinityAiTheme(darkTheme = true) {
                SplashScreen()
            }
        }
        is AuthUiState.Unauthenticated -> {
            InfinityAiTheme(darkTheme = true) {
                AuthScreen(
                    isLoading = isSigningIn,
                    errorMessage = authState.message,
                    onGoogleSignInClick = onGoogleSignInClick,
                    onCancelSignInClick = onCancelSignInClick,
                    onDismissErrorClick = onDismissErrorClick
                )
            }
        }
        is AuthUiState.Suspended -> {
            InfinityAiTheme(darkTheme = true) {
                SuspendedAccountScreen(
                    email = authState.email,
                    onSignOutClick = onSignOutClick
                )
            }
        }
        is AuthUiState.Authenticated -> {
            val uid = authState.user.uid
            key(uid) {
                val mainViewModel: MainViewModel = viewModel(
                    key = uid,
                    factory = MainViewModel.provideFactory(
                        context = context,
                        currentUserId = uid,
                        initialProfile = authState.profile
                    )
                )
                val isDarkTheme by mainViewModel.isDarkTheme.collectAsStateWithLifecycle()
                InfinityAiTheme(darkTheme = isDarkTheme) {
                    AppShell(
                        viewModel = mainViewModel,
                        onSignOutClick = onSignOutClick
                    )
                }
            }
        }
    }
}
