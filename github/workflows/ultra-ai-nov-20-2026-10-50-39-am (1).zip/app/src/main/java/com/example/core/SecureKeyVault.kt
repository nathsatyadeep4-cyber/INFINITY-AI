package com.example.core

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Hardware-backed Android Keystore AES-GCM vault for encrypting Owner-configured
 * third-party API keys (e.g., OpenAI API key) locally on device.
 */
class SecureKeyVault(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    fun saveSecret(slot: String, plaintext: String) {
        if (plaintext.isBlank()) {
            clearSecret(slot)
            return
        }
        try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
            val iv = cipher.iv
            val encrypted = cipher.doFinal(plaintext.trim().toByteArray(Charsets.UTF_8))
            val combined = ByteArray(1 + iv.size + encrypted.size)
            combined[0] = iv.size.toByte()
            System.arraycopy(iv, 0, combined, 1, iv.size)
            System.arraycopy(encrypted, 0, combined, 1 + iv.size, encrypted.size)
            val encoded = Base64.encodeToString(combined, Base64.NO_WRAP)
            prefs.edit().putString(slot, encoded).apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to encrypt key for slot=$slot", e)
        }
    }

    fun readSecret(slot: String): String {
        val encoded = prefs.getString(slot, null) ?: return ""
        return try {
            val combined = Base64.decode(encoded, Base64.NO_WRAP)
            val ivLen = combined[0].toInt() and 0xFF
            val iv = combined.copyOfRange(1, 1 + ivLen)
            val ciphertext = combined.copyOfRange(1 + ivLen, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decrypt key for slot=$slot", e)
            ""
        }
    }

    fun clearSecret(slot: String) {
        prefs.edit().remove(slot).apply()
    }

    fun hasSecret(slot: String): Boolean = readSecret(slot).isNotBlank()

    fun maskedSecret(slot: String): String {
        val value = readSecret(slot)
        if (value.isBlank()) return "Not configured"
        return if (value.length <= 8) "••••••••" else "${value.take(5)}••••••••${value.takeLast(4)}"
    }

    companion object {
        private const val TAG = "SecureKeyVault"
        private const val PREFS_NAME = "infinity_ai_secure_vault"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "infinity_ai_owner_key_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"

        const val SLOT_OPENAI_KEY = "openai_api_key"
        const val SLOT_CUSTOM_GEMINI_KEY = "custom_gemini_api_key"
    }
}
