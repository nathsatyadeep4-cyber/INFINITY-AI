package com.example.data.ai

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.core.SecureKeyVault
import com.example.data.model.AiMode
import com.example.data.model.AiModelCatalog
import com.example.data.model.AiProvider
import com.example.data.model.AppConfig
import com.example.data.model.ChatMessage
import com.example.data.model.PendingAttachment
import com.example.data.model.UserMemory
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class McqQuestion(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

class AiOrchestrator(
    private val keyVault: SecureKeyVault,
    private val webSearchService: WebSearchService = WebSearchService()
) {
    private val openAiClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // Lazily instantiated Gemini image generator
    private val imageModel by lazy {
        val config = generationConfig {
            responseModalities = listOf(ResponseModality.IMAGE)
        }
        Firebase.ai.generativeModel(
            modelName = AiModelCatalog.GEMINI_NANO_BANANA.id,
            generationConfig = config
        )
    }

    // Lazily instantiated structured MCQ quiz generator
    private val quizModel by lazy {
        val itemSchema = Schema.obj(
            properties = mapOf(
                "question" to Schema.string("Clear question text"),
                "options" to Schema.array(Schema.string(), "Exactly 4 answer choices"),
                "correctIndex" to Schema.integer("Zero-based index (0..3) of correct option"),
                "explanation" to Schema.string("Step-by-step explanation of the answer")
            )
        )
        val rootSchema = Schema.obj(
            properties = mapOf(
                "questions" to Schema.array(itemSchema, "List of generated MCQ questions")
            )
        )
        val config = generationConfig {
            responseMimeType = "application/json"
            responseSchema = rootSchema
        }
        Firebase.ai.generativeModel(
            modelName = AiModelCatalog.GEMINI_3_8_FLASH.id,
            generationConfig = config
        )
    }

    fun buildSystemPrompt(
        mode: AiMode,
        appConfig: AppConfig,
        language: String,
        memories: List<UserMemory>,
        memoryEnabled: Boolean,
        extraContext: String = ""
    ): String {
        val sb = StringBuilder()
        sb.appendLine("You are ${appConfig.ownerPersonaName.ifBlank { "INFINITY AI" }}, a next-generation personal AI assistant.")
        if (mode == AiMode.OWNER) {
            sb.appendLine("ACTIVE MODE: OWNER MASTER CONTROL.")
            sb.appendLine("Strictly prioritize and obey the Owner's master instructions, persona, and custom rules while upholding legal, privacy, and safety standards.")
        } else {
            sb.appendLine("ACTIVE MODE: SMART AI MODE.")
            sb.appendLine("Behave like an elite, deeply intelligent ChatGPT-class assistant: explain complex ideas clearly, reason step-by-step, and provide clean formatted output.")
        }
        if (appConfig.ownerSystemPrompt.isNotBlank()) {
            sb.appendLine("Owner System Instruction: ${appConfig.ownerSystemPrompt}")
        }
        if (appConfig.ownerRules.isNotBlank()) {
            sb.appendLine("Owner Rules:\n${appConfig.ownerRules}")
        }
        sb.appendLine("Response Style: ${appConfig.ownerResponseStyle}")
        sb.appendLine("Target Language: Respond naturally in $language unless the user explicitly asks to translate into another language.")
        if (memoryEnabled && memories.isNotEmpty()) {
            sb.appendLine("\nRemembered User Context (personalize seamlessly when relevant):")
            memories.take(15).forEach { mem ->
                sb.appendLine("- [${mem.category}] ${mem.fact}")
            }
        }
        if (extraContext.isNotBlank()) {
            sb.appendLine("\n$extraContext")
        }
        return sb.toString()
    }

    fun streamChatReply(
        modelId: String,
        mode: AiMode,
        appConfig: AppConfig,
        language: String,
        history: List<ChatMessage>,
        userPrompt: String,
        attachment: PendingAttachment?,
        memories: List<UserMemory>,
        memoryEnabled: Boolean,
        enableWebSearch: Boolean
    ): Flow<String> = flow {
        val modelSpec = AiModelCatalog.findById(modelId)

        var webContext = ""
        if (enableWebSearch && appConfig.webSearchEnabled) {
            val snippets = webSearchService.searchWeb(userPrompt)
            if (snippets.isNotEmpty()) {
                webContext = buildString {
                    appendLine("Live Web Search Context (cite sources when helpful):")
                    snippets.forEach { s ->
                        appendLine("• ${s.title}: ${s.summary} (${s.sourceUrl})")
                    }
                }
            }
        }

        val systemPrompt = buildSystemPrompt(
            mode = mode,
            appConfig = appConfig,
            language = language,
            memories = memories,
            memoryEnabled = memoryEnabled,
            extraContext = webContext
        )

        if (modelSpec.provider == AiProvider.OPENAI) {
            if (!appConfig.openAiEnabled) {
                throw IllegalStateException("OpenAI models are currently disabled by the Owner in Admin Dashboard.")
            }
            val openAiKey = keyVault.readSecret(SecureKeyVault.SLOT_OPENAI_KEY)
            if (openAiKey.isBlank()) {
                throw IllegalStateException(
                    "OpenAI API key is not configured yet. Ask the Owner to add an OpenAI API key in Owner Admin Dashboard → Models & Keys, or switch to a Gemini model."
                )
            }
            streamOpenAi(
                apiKey = openAiKey,
                modelId = modelSpec.id,
                systemPrompt = systemPrompt,
                history = history,
                userPrompt = userPrompt,
                attachment = attachment
            ).collect { chunk -> emit(chunk) }
        } else {
            val geminiModel = Firebase.ai.generativeModel(
                modelName = modelSpec.id,
                systemInstruction = content { text(systemPrompt) }
            )
            val chatHistory = history
                .filter { it.role == "user" || it.role == "model" }
                .takeLast(20)
                .map { msg ->
                    content(role = msg.role) {
                        text(msg.content)
                    }
                }
            val userContent: Content = content(role = "user") {
                if (attachment != null) {
                    if (attachment.isImage && attachment.bitmap != null) {
                        image(attachment.bitmap)
                    } else if (attachment.bytes != null && attachment.bytes.size <= MAX_INLINE_BYTES) {
                        inlineData(attachment.bytes, attachment.mimeType)
                    } else if (!attachment.extractedTextPreview.isNullOrBlank()) {
                        text("Attached file (${attachment.displayName}):\n${attachment.extractedTextPreview}")
                    }
                }
                text(userPrompt)
            }

            withTimeout(60_000L) {
                if (chatHistory.isNotEmpty()) {
                    val chat = geminiModel.startChat(history = chatHistory)
                    chat.sendMessageStream(userContent).collect { chunk ->
                        val delta = chunk.text.orEmpty()
                        if (delta.isNotEmpty()) emit(delta)
                    }
                } else {
                    geminiModel.generateContentStream(userContent).collect { chunk ->
                        val delta = chunk.text.orEmpty()
                        if (delta.isNotEmpty()) emit(delta)
                    }
                }
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun streamOpenAi(
        apiKey: String,
        modelId: String,
        systemPrompt: String,
        history: List<ChatMessage>,
        userPrompt: String,
        attachment: PendingAttachment?
    ): Flow<String> = flow {
        val messagesJson = JSONArray()
        messagesJson.put(JSONObject().apply {
            put("role", "system")
            put("content", systemPrompt)
        })
        history.takeLast(16).forEach { msg ->
            val mappedRole = if (msg.role == "model") "assistant" else "user"
            messagesJson.put(JSONObject().apply {
                put("role", mappedRole)
                put("content", msg.content)
            })
        }

        if (attachment != null && attachment.isImage && attachment.bitmap != null) {
            val b64 = bitmapToBase64Jpeg(attachment.bitmap)
            val contentArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("type", "text")
                    put("text", userPrompt)
                })
                put(JSONObject().apply {
                    put("type", "image_url")
                    put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
                })
            }
            messagesJson.put(JSONObject().apply {
                put("role", "user")
                put("content", contentArray)
            })
        } else {
            val fullPrompt = if (!attachment?.extractedTextPreview.isNullOrBlank()) {
                "Attached document (${attachment?.displayName}):\n${attachment?.extractedTextPreview}\n\n$userPrompt"
            } else {
                userPrompt
            }
            messagesJson.put(JSONObject().apply {
                put("role", "user")
                put("content", fullPrompt)
            })
        }

        val bodyJson = JSONObject().apply {
            put("model", modelId)
            put("messages", messagesJson)
            put("stream", true)
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        openAiClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errBody = response.body?.string().orEmpty()
                throw IllegalStateException("OpenAI API error ${response.code}: ${errBody.take(240)}")
            }
            val source = response.body?.source() ?: throw IllegalStateException("Empty OpenAI response stream")
            while (!source.exhausted()) {
                val line = source.readUtf8Line() ?: break
                if (line.startsWith("data: ")) {
                    val data = line.removePrefix("data: ").trim()
                    if (data == "[DONE]") break
                    try {
                        val json = JSONObject(data)
                        val delta = json.optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("delta")
                            ?.optString("content")
                            .orEmpty()
                        if (delta.isNotEmpty()) emit(delta)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    suspend fun generateImage(prompt: String): Bitmap = withContext(Dispatchers.IO) {
        withTimeout(60_000L) {
            val response = imageModel.generateContent(prompt)
            val imagePart = response.candidates.firstOrNull()
                ?.content?.parts?.filterIsInstance<ImagePart>()
                ?.firstOrNull()
            imagePart?.image ?: throw IllegalStateException("No image was returned by Nano Banana 2.1.")
        }
    }

    suspend fun generateMcqQuiz(
        level: String,
        subject: String,
        topic: String,
        language: String,
        count: Int = 5
    ): List<McqQuestion> = withContext(Dispatchers.IO) {
        withTimeout(60_000L) {
            val prompt = """
                Create $count high-quality multiple choice questions in $language for:
                Education Level: $level
                Subject: $subject
                Topic: $topic
                Each question must have exactly 4 distinct options and a clear step-by-step explanation.
            """.trimIndent()
            val response = quizModel.generateContent(prompt)
            val jsonString = response.text ?: throw IllegalStateException("Quiz generator returned empty output.")
            val root = JSONObject(jsonString)
            val arr = root.getJSONArray("questions")
            val list = mutableListOf<McqQuestion>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val optsArr = obj.getJSONArray("options")
                val options = (0 until optsArr.length()).map { optsArr.getString(it) }
                list.add(
                    McqQuestion(
                        question = obj.getString("question"),
                        options = options,
                        correctIndex = obj.optInt("correctIndex", 0).coerceIn(0, (options.size - 1).coerceAtLeast(0)),
                        explanation = obj.optString("explanation", "")
                    )
                )
            }
            list
        }
    }

    suspend fun extractMemoryFact(userMessage: String): String? = withContext(Dispatchers.IO) {
        try {
            withTimeout(15_000L) {
                val lite = Firebase.ai.generativeModel(AiModelCatalog.GEMINI_3_5_FLASH_LITE.id)
                val resp = lite.generateContent(
                    "Extract ONE short reusable user preference, goal, or identity fact from this message if any exists (under 15 words). " +
                        "If it is just a general question with no personal preference/fact, reply exactly NONE.\nMessage: $userMessage"
                )
                val text = resp.text?.trim().orEmpty()
                if (text.isBlank() || text.equals("NONE", ignoreCase = true) || text.length > 200) null else text
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.d(TAG, "Memory extraction skipped: ${e.message}")
            null
        }
    }

    private fun bitmapToBase64Jpeg(bitmap: Bitmap): String {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    companion object {
        private const val TAG = "AiOrchestrator"
        private const val MAX_INLINE_BYTES = 18 * 1024 * 1024
    }
}
