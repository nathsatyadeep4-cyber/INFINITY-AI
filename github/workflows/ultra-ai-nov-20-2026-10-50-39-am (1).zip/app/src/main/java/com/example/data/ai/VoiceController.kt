package com.example.data.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.model.SupportedLanguages
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class VoiceController(context: Context) {
    private val appContext = context.applicationContext

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _voiceError = MutableStateFlow<String?>(null)
    val voiceError: StateFlow<String?> = _voiceError.asStateFlow()

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }
                })
            } else {
                Log.w(TAG, "TextToSpeech init failed with status=$status")
            }
        }
    }

    fun startListening(languageName: String, onFinalResult: (String) -> Unit) {
        interruptSpeaking()
        _voiceError.value = null
        _partialTranscript.value = ""

        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            _voiceError.value = "Speech recognition service is not available on this device."
            return
        }

        val lang = SupportedLanguages.findByName(languageName)
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected. Please speak clearly."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                        else -> "Speech recognition error ($error)."
                    }
                    _voiceError.value = msg
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val best = matches?.firstOrNull().orEmpty().trim()
                    _partialTranscript.value = best
                    if (best.isNotEmpty()) {
                        onFinalResult(best)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    _partialTranscript.value = matches?.firstOrNull().orEmpty()
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.bcp47Tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        _isListening.value = false
    }

    fun speak(text: String, languageName: String, voicePersona: String) {
        if (!ttsReady) return
        val cleanText = text
            .replace(Regex("```[\\s\\S]*?```"), "Code block omitted.")
            .replace(Regex("[#*_`>]"), "")
            .trim()
        if (cleanText.isEmpty()) return

        val lang = SupportedLanguages.findByName(languageName)
        val locale = Locale.forLanguageTag(lang.bcp47Tag)
        tts?.language = locale

        // Configure pitch / voice selection based on persona (Female, Male, Balanced)
        val availableVoices = tts?.voices.orEmpty().filter {
            it.locale.language == locale.language && !it.isNetworkConnectionRequired
        }
        when (voicePersona) {
            "Female" -> {
                val femaleVoice: Voice? = availableVoices.firstOrNull {
                    it.name.contains("female", ignoreCase = true) || it.name.contains("f00", ignoreCase = true)
                }
                if (femaleVoice != null) tts?.voice = femaleVoice
                tts?.setPitch(1.12f)
                tts?.setSpeechRate(1.0f)
            }
            "Male" -> {
                val maleVoice: Voice? = availableVoices.firstOrNull {
                    it.name.contains("male", ignoreCase = true) || it.name.contains("m00", ignoreCase = true)
                }
                if (maleVoice != null) tts?.voice = maleVoice
                tts?.setPitch(0.86f)
                tts?.setSpeechRate(0.98f)
            }
            else -> {
                tts?.setPitch(1.0f)
                tts?.setSpeechRate(1.02f)
            }
        }

        _isSpeaking.value = true
        val chunks = cleanText.chunked(3500)
        chunks.forEachIndexed { idx, chunk ->
            val mode = if (idx == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            tts?.speak(chunk, mode, null, UUID.randomUUID().toString())
        }
    }

    fun interruptSpeaking() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun clearError() {
        _voiceError.value = null
    }

    fun release() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    companion object {
        private const val TAG = "VoiceController"
    }
}
