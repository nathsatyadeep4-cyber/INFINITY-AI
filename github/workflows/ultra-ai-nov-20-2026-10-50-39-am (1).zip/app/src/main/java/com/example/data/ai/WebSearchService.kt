package com.example.data.ai

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class WebSearchSnippet(
    val title: String,
    val summary: String,
    val sourceUrl: String
)

class WebSearchService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
) {
    suspend fun searchWeb(query: String): List<WebSearchSnippet> = withContext(Dispatchers.IO) {
        val clean = query.trim()
        if (clean.isEmpty()) return@withContext emptyList()

        val results = mutableListOf<WebSearchSnippet>()
        try {
            val encoded = URLEncoder.encode(clean, "UTF-8")
            val wikiReq = Request.Builder()
                .url("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$encoded&srlimit=3&format=json&utf8=1")
                .header("User-Agent", "InfinityAI-Android/1.0")
                .build()
            client.newCall(wikiReq).execute().use { resp ->
                if (resp.isSuccessful) {
                    val body = resp.body?.string().orEmpty()
                    val json = JSONObject(body)
                    val searchArr = json.optJSONObject("query")?.optJSONArray("search")
                    if (searchArr != null) {
                        for (i in 0 until searchArr.length()) {
                            val item = searchArr.optJSONObject(i) ?: continue
                            val title = item.optString("title")
                            val rawSnippet = item.optString("snippet")
                                .replace(Regex("<[^>]*>"), "")
                                .replace("&quot;", "\"")
                                .replace("&amp;", "&")
                            if (title.isNotBlank()) {
                                val urlTitle = URLEncoder.encode(title.replace(" ", "_"), "UTF-8")
                                results.add(
                                    WebSearchSnippet(
                                        title = title,
                                        summary = rawSnippet,
                                        sourceUrl = "https://en.wikipedia.org/wiki/$urlTitle"
                                    )
                                )
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Wikipedia search failed: ${e.message}")
        }

        if (results.isEmpty()) {
            try {
                val encoded = URLEncoder.encode(clean, "UTF-8")
                val ddgReq = Request.Builder()
                    .url("https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1")
                    .header("User-Agent", "InfinityAI-Android/1.0")
                    .build()
                client.newCall(ddgReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val json = JSONObject(resp.body?.string().orEmpty())
                        val abstract = json.optString("AbstractText")
                        val heading = json.optString("Heading")
                        val url = json.optString("AbstractURL")
                        if (abstract.isNotBlank()) {
                            results.add(
                                WebSearchSnippet(
                                    title = heading.ifBlank { clean },
                                    summary = abstract,
                                    sourceUrl = url.ifBlank { "https://duckduckgo.com/?q=$encoded" }
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "DuckDuckGo search failed: ${e.message}")
            }
        }

        results
    }

    companion object {
        private const val TAG = "WebSearchService"
    }
}
