package com.example.data.model

import android.graphics.Bitmap
import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class AiMode(val wireValue: String, val label: String, val subtitle: String) {
    OWNER("owner", "Owner Mode", "Master Control • Follows Owner Rules & Custom Persona"),
    SMART("smart", "Smart AI", "Next-Gen Assistant • Reasoning, Coding, Education & Research");

    companion object {
        fun fromWire(raw: String?): AiMode =
            entries.firstOrNull { it.wireValue == raw } ?: SMART
    }
}

enum class ChatCategory(val wireValue: String, val label: String) {
    CHAT("chat", "General Chat"),
    CODING("coding", "Coding Studio"),
    EDUCATION("education", "Education"),
    TOOLS("tools", "AI Tools"),
    VOICE("voice", "Voice AI");

    companion object {
        fun fromWire(raw: String?): ChatCategory =
            entries.firstOrNull { it.wireValue == raw } ?: CHAT
    }
}

@Keep
@IgnoreExtraProperties
data class ChatSession(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "New Conversation",
    val mode: String = AiMode.SMART.wireValue,
    val modelId: String = AiModelCatalog.GEMINI_3_8_FLASH.id,
    val category: String = ChatCategory.CHAT.wireValue,
    val language: String = "English",
    val pinned: Boolean = false,
    val messageCount: Long = 0L,
    val lastMessagePreview: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val chatId: String = "",
    val role: String = "user",
    val content: String = "",
    val modelId: String = AiModelCatalog.GEMINI_3_8_FLASH.id,
    val attachmentName: String? = null,
    val attachmentType: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class PendingAttachment(
    val displayName: String,
    val mimeType: String,
    val isImage: Boolean,
    val bitmap: Bitmap? = null,
    val bytes: ByteArray? = null,
    val extractedTextPreview: String? = null
)

data class LanguageOption(
    val name: String,
    val nativeName: String,
    val bcp47Tag: String
)

object SupportedLanguages {
    val all: List<LanguageOption> = listOf(
        LanguageOption("English", "English", "en-US"),
        LanguageOption("Hindi", "हिन्दी", "hi-IN"),
        LanguageOption("Bengali", "বাংলা", "bn-IN"),
        LanguageOption("Assamese", "অসমীয়া", "as-IN"),
        LanguageOption("Urdu", "اردو", "ur-PK"),
        LanguageOption("Arabic", "العربية", "ar-SA"),
        LanguageOption("Spanish", "Español", "es-ES"),
        LanguageOption("French", "Français", "fr-FR"),
        LanguageOption("German", "Deutsch", "de-DE"),
        LanguageOption("Chinese", "中文", "zh-CN"),
        LanguageOption("Japanese", "日本語", "ja-JP"),
        LanguageOption("Portuguese", "Português", "pt-BR"),
        LanguageOption("Russian", "Русский", "ru-RU"),
        LanguageOption("Korean", "한국어", "ko-KR")
    )

    fun findByName(name: String): LanguageOption =
        all.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: all.first()
}

object EducationCatalog {
    val levels = listOf(
        "Class 1 - 5 (Primary)",
        "Class 6 - 8 (Middle School)",
        "Class 9 - 10 (Secondary)",
        "Class 11 - 12 (Senior Secondary)",
        "College / Graduation",
        "Post-Graduation",
        "Competitive Exams (JEE/NEET/UPSC/SSC)",
        "Computer Education & Coding"
    )

    val subjects = listOf(
        "Mathematics",
        "Science",
        "Physics",
        "Chemistry",
        "Biology",
        "Computer Science",
        "English",
        "Hindi",
        "Bengali",
        "Assamese",
        "History",
        "Geography",
        "Political Science",
        "Economics",
        "General Knowledge"
    )

    val studyModes = listOf(
        "Step-by-Step Topic Explainer",
        "Mathematics Problem Solver",
        "Structured Study Notes",
        "Q&A Set (Short & Long)",
        "Practice Exam Paper",
        "Exam Preparation Plan"
    )
}

object CodingCatalog {
    val languages = listOf(
        "HTML/CSS/JS",
        "Kotlin",
        "Python",
        "JavaScript",
        "React",
        "Node.js",
        "Java",
        "C",
        "C++",
        "PHP",
        "Flutter (Dart)",
        "SQL"
    )
}
