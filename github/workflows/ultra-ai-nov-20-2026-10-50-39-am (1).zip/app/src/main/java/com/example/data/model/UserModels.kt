package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class UserRole(val wireValue: String, val displayLabel: String) {
    OWNER("owner", "Owner (Master Control)"),
    USER("user", "Standard User");

    companion object {
        fun fromWire(raw: String?): UserRole =
            entries.firstOrNull { it.wireValue == raw } ?: USER
    }
}

enum class SubscriptionTier(val wireValue: String, val displayLabel: String) {
    FREE("free", "Free"),
    PRO("pro", "Pro"),
    INFINITY("ultra", "Infinity");

    companion object {
        fun fromWire(raw: String?): SubscriptionTier =
            entries.firstOrNull { it.wireValue == raw } ?: FREE
    }
}

enum class AccountStatus(val wireValue: String, val displayLabel: String) {
    ACTIVE("active", "Active"),
    SUSPENDED("suspended", "Suspended");

    companion object {
        fun fromWire(raw: String?): AccountStatus =
            entries.firstOrNull { it.wireValue == raw } ?: ACTIVE
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val photoUrl: String? = null,
    val role: String = UserRole.USER.wireValue,
    val subscriptionTier: String = SubscriptionTier.FREE.wireValue,
    val accountStatus: String = AccountStatus.ACTIVE.wireValue,
    val memoryEnabled: Boolean = true,
    val preferredLanguage: String = "English",
    val preferredVoice: String = "Balanced",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val parsedRole: UserRole get() = UserRole.fromWire(role)
    val parsedTier: SubscriptionTier get() = SubscriptionTier.fromWire(subscriptionTier)
    val parsedStatus: AccountStatus get() = AccountStatus.fromWire(accountStatus)
    val hasOwnerAccess: Boolean get() = parsedRole == UserRole.OWNER
}

@Keep
@IgnoreExtraProperties
data class AppConfig(
    @DocumentId val id: String = "",
    val defaultModelId: String = AiModelCatalog.GEMINI_3_8_FLASH.id,
    val ownerSystemPrompt: String = "You are INFINITY AI, a brilliant, accurate, and articulate next-generation personal AI assistant.",
    val ownerPersonaName: String = "Infinity Core",
    val ownerResponseStyle: String = "Balanced & Structured",
    val ownerRules: String = "1. Be clear, truthful, and actionable.\n2. Format code cleanly with language tags.\n3. Adapt explanations to the user's skill level.",
    val defaultLanguage: String = "English",
    val codingStudioEnabled: Boolean = true,
    val educationSuiteEnabled: Boolean = true,
    val voiceAiEnabled: Boolean = true,
    val imageGenEnabled: Boolean = true,
    val webSearchEnabled: Boolean = true,
    val openAiEnabled: Boolean = true,
    val rateLimitPerMinute: Long = 30L,
    val updatedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserMemory(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fact: String = "",
    val category: String = "context",
    val sourceChatId: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UsageLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val modelId: String = "",
    val feature: String = "chat",
    val status: String = "success",
    val errorMessage: String? = null,
    val latencyMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

enum class AiProvider(val label: String) {
    GEMINI("Google Gemini (Firebase AI)"),
    OPENAI("OpenAI API")
}

data class AiModelSpec(
    val id: String,
    val displayName: String,
    val provider: AiProvider,
    val badge: String,
    val description: String,
    val supportsVision: Boolean = true,
    val supportsStreaming: Boolean = true,
    val supportsImageGen: Boolean = false
)

object AiModelCatalog {
    val GEMINI_3_8_FLASH = AiModelSpec(
        id = "gemini-3.8-flash",
        displayName = "Gemini 3.8 Flash",
        provider = AiProvider.GEMINI,
        badge = "Default • Fast",
        description = "Frontier performance for everyday chat, coding, documents, and multimodal tasks."
    )
    val GEMINI_4_ARGON = AiModelSpec(
        id = "gemini-4-argon",
        displayName = "Gemini 4 Argon",
        provider = AiProvider.GEMINI,
        badge = "Deep Reasoning",
        description = "Flagship intelligence for complex STEM, architecture, and advanced mathematics."
    )
    val GEMINI_3_5_FLASH_LITE = AiModelSpec(
        id = "gemini-3.5-flash-lite",
        displayName = "Gemini 3.5 Flash-Lite",
        provider = AiProvider.GEMINI,
        badge = "Hyper Fast",
        description = "Instant responses for translations, quick Q&A, and lightweight summaries."
    )
    val GEMINI_NANO_BANANA = AiModelSpec(
        id = "gemini-nano-banana-2.1",
        displayName = "Nano Banana 2.1",
        provider = AiProvider.GEMINI,
        badge = "Image Gen",
        description = "High-efficiency AI image synthesis and visual editing.",
        supportsStreaming = false,
        supportsImageGen = true
    )
    val OPENAI_GPT_4O = AiModelSpec(
        id = "gpt-4o",
        displayName = "OpenAI GPT-4o",
        provider = AiProvider.OPENAI,
        badge = "OpenAI Flagship",
        description = "Omni model via Owner-configured OpenAI API key."
    )
    val OPENAI_GPT_4O_MINI = AiModelSpec(
        id = "gpt-4o-mini",
        displayName = "OpenAI GPT-4o Mini",
        provider = AiProvider.OPENAI,
        badge = "OpenAI Fast",
        description = "Fast, cost-efficient OpenAI model for chat and coding."
    )
    val OPENAI_O3_MINI = AiModelSpec(
        id = "o3-mini",
        displayName = "OpenAI o3-mini",
        provider = AiProvider.OPENAI,
        badge = "OpenAI Reasoning",
        description = "Structured reasoning model via OpenAI API.",
        supportsVision = false
    )

    val chatModels: List<AiModelSpec> = listOf(
        GEMINI_3_8_FLASH,
        GEMINI_4_ARGON,
        GEMINI_3_5_FLASH_LITE,
        OPENAI_GPT_4O,
        OPENAI_GPT_4O_MINI,
        OPENAI_O3_MINI
    )

    val allModels: List<AiModelSpec> = chatModels + GEMINI_NANO_BANANA

    fun findById(id: String): AiModelSpec =
        allModels.firstOrNull { it.id == id } ?: GEMINI_3_8_FLASH
}
