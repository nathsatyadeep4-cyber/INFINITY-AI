package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

interface AuthGateway {
    fun currentUser(): FirebaseUser?
    fun authStateFlow(): Flow<FirebaseUser?>
    suspend fun attemptAutoSignIn(context: Context): Result<FirebaseUser?>
    suspend fun signInInteractive(context: Context): Result<FirebaseUser>
    suspend fun signOut(context: Context)
}

class AuthRepository(
    private val auth: FirebaseAuth = Firebase.auth
) : AuthGateway {

    // Prevents duplicate overlapping Credential Manager launches
    private val interactiveMutex = Mutex()

    override fun currentUser(): FirebaseUser? = auth.currentUser

    override fun authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    override suspend fun attemptAutoSignIn(context: Context): Result<FirebaseUser?> {
        val existing = auth.currentUser
        if (existing != null) return Result.success(existing)

        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            Log.w(TAG, "default_web_client_id missing for silent sign-in", e)
            return Result.success(null)
        }

        return try {
            val credentialManager = CredentialManager.create(context)
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(true)
                .setServerClientId(clientId)
                .setAutoSelectEnabled(true)
                .build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result = credentialManager.getCredential(context, request)
            val cred = result.credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                val authResult = auth.signInWithCredential(
                    GoogleAuthProvider.getCredential(token, null)
                ).await()
                Result.success(authResult.user)
            } else {
                Result.success(null)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.d(TAG, "Silent auto sign-in unavailable: ${e.message}")
            Result.success(null)
        }
    }

    override suspend fun signInInteractive(context: Context): Result<FirebaseUser> {
        if (!interactiveMutex.tryLock()) {
            return Result.failure(DuplicateSignInRequestException("Google Sign-In is already in progress."))
        }

        return try {
            val clientId = try {
                context.getString(R.string.default_web_client_id)
            } catch (e: Exception) {
                return Result.failure(
                    IllegalStateException("Google Sign-In configuration missing: default_web_client_id not found")
                )
            }

            val activity = context as? Activity
                ?: return Result.failure(IllegalStateException("Interactive sign-in requires an Activity context."))

            val credentialManager = CredentialManager.create(context)
            val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(signInOption)
                .build()

            val cred = credentialManager.getCredential(activity, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                val authResult = auth.signInWithCredential(
                    GoogleAuthProvider.getCredential(token, null)
                ).await()
                val user = authResult.user
                    ?: return Result.failure(IllegalStateException("Firebase returned null user after Google Sign-In."))
                Result.success(user)
            } else {
                Result.failure(IllegalStateException("Unexpected credential type received."))
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Google Sign-In cancelled or dismissed: ${e.message}", e)
            Result.failure(SignInCancelledException("Google Sign-In was cancelled. Tap Retry to select an account."))
        } catch (e: NoCredentialException) {
            Log.w(TAG, "No Google credential available on device: ${e.message}", e)
            Result.failure(
                NoGoogleAccountException(
                    "No existing Google account was found on this device. On a physical phone with Google accounts signed in, tapping Continue with Google shows the account picker."
                )
            )
        } catch (e: GetCredentialException) {
            Log.e(TAG, "Credential Manager error during Google Sign-In: ${e.type} - ${e.message}", e)
            Result.failure(
                IllegalStateException(
                    "Unable to complete Google Sign-In (${e.errorMessage ?: "verify Google Play Services and network"})."
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Google Sign-In failed", e)
            Result.failure(e)
        } finally {
            interactiveMutex.unlock()
        }
    }

    override suspend fun signOut(context: Context) {
        withContext(NonCancellable) {
            try {
                CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w(TAG, "Failed to clear credential state: ${e.message}")
            } finally {
                auth.signOut()
            }
        }
    }

    companion object {
        private const val TAG = "AuthRepository"
        const val BOOTSTRAPPED_OWNER_EMAIL = "satya18x@gmail.com"
    }
}

class SignInCancelledException(message: String) : Exception(message)

class NoGoogleAccountException(message: String) : Exception(message)

class DuplicateSignInRequestException(message: String) : Exception(message)
