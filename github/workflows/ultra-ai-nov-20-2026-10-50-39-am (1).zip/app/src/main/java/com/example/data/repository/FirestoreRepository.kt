package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.AppConfig
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.model.UserMemory
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.model.UsageLog
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    // --- USER PROFILE & ROLE BOOTSTRAPPING ---

    suspend fun ensureUserProfile(user: FirebaseUser): Result<UserProfile> {
        val uid = user.uid
        val path = "users/$uid"
        return try {
            val docRef = db.collection("users").document(uid)
            val existing = docRef.get().await()
            if (existing.exists()) {
                val parsed = existing.toObject(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                if (parsed != null) {
                    // If bootstrapped owner email is verified and role wasn't owner yet, upgrade cleanly
                    val isBootstrappedOwner = user.isEmailVerified &&
                        user.email.equals(AuthRepository.BOOTSTRAPPED_OWNER_EMAIL, ignoreCase = true)
                    if (isBootstrappedOwner && parsed.role != UserRole.OWNER.wireValue) {
                        docRef.update(
                            mapOf(
                                "role" to UserRole.OWNER.wireValue,
                                "subscriptionTier" to "ultra",
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                        ensureAdminDocument(uid, user.email.orEmpty(), uid)
                        return Result.success(parsed.copy(role = UserRole.OWNER.wireValue, subscriptionTier = "ultra"))
                    }
                    return Result.success(parsed)
                }
            }

            val isBootstrappedOwner = user.isEmailVerified &&
                user.email.equals(AuthRepository.BOOTSTRAPPED_OWNER_EMAIL, ignoreCase = true)
            val isAdminDoc = try {
                db.collection("admins").document(uid).get().await().exists()
            } catch (_: Exception) {
                false
            }
            val assignedRole = if (isBootstrappedOwner || isAdminDoc) UserRole.OWNER.wireValue else UserRole.USER.wireValue
            val assignedTier = if (assignedRole == UserRole.OWNER.wireValue) "ultra" else "free"
            val email = user.email?.takeIf { it.isNotBlank() } ?: "$uid@users.infinityai.app"
            val displayName = user.displayName?.takeIf { it.isNotBlank() } ?: email.substringBefore("@").take(40)

            val payload = mutableMapOf<String, Any?>(
                "userId" to uid,
                "email" to email.take(256),
                "displayName" to displayName.take(120),
                "photoUrl" to user.photoUrl?.toString()?.take(1000),
                "role" to assignedRole,
                "subscriptionTier" to assignedTier,
                "accountStatus" to "active",
                "memoryEnabled" to true,
                "preferredLanguage" to "English",
                "preferredVoice" to "Balanced",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>

            docRef.set(payload).await()
            if (isBootstrappedOwner) {
                ensureAdminDocument(uid, email, uid)
                ensureDefaultAppConfig(uid)
            }

            val created = docRef.get().await().toObject(
                UserProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: UserProfile(
                id = uid,
                userId = uid,
                email = email,
                displayName = displayName,
                photoUrl = user.photoUrl?.toString(),
                role = assignedRole,
                subscriptionTier = assignedTier
            )
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private suspend fun ensureAdminDocument(uid: String, email: String, grantedBy: String) {
        val adminRef = db.collection("admins").document(uid)
        try {
            if (!adminRef.get().await().exists()) {
                adminRef.set(
                    mapOf(
                        "uid" to uid,
                        "email" to email.take(256),
                        "grantedBy" to grantedBy,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Admin record check/create skipped: ${e.message}")
        }
    }

    private suspend fun ensureDefaultAppConfig(uid: String) {
        val ref = db.collection("app_config").document(GLOBAL_CONFIG_ID)
        try {
            if (!ref.get().await().exists()) {
                val defaults = AppConfig(updatedBy = uid)
                ref.set(
                    mapOf(
                        "defaultModelId" to defaults.defaultModelId,
                        "ownerSystemPrompt" to defaults.ownerSystemPrompt,
                        "ownerPersonaName" to defaults.ownerPersonaName,
                        "ownerResponseStyle" to defaults.ownerResponseStyle,
                        "ownerRules" to defaults.ownerRules,
                        "defaultLanguage" to defaults.defaultLanguage,
                        "codingStudioEnabled" to defaults.codingStudioEnabled,
                        "educationSuiteEnabled" to defaults.educationSuiteEnabled,
                        "voiceAiEnabled" to defaults.voiceAiEnabled,
                        "imageGenEnabled" to defaults.imageGenEnabled,
                        "webSearchEnabled" to defaults.webSearchEnabled,
                        "openAiEnabled" to defaults.openAiEnabled,
                        "rateLimitPerMinute" to defaults.rateLimitPerMinute,
                        "updatedBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Default app_config setup skipped: ${e.message}")
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    suspend fun updateUserPreferences(
        userId: String,
        memoryEnabled: Boolean,
        preferredLanguage: String,
        preferredVoice: String
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            db.collection("users").document(userId).update(
                mapOf(
                    "memoryEnabled" to memoryEnabled,
                    "preferredLanguage" to preferredLanguage.take(64).ifBlank { "English" },
                    "preferredVoice" to preferredVoice.take(64).ifBlank { "Balanced" },
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- GLOBAL APP CONFIG (OWNER MASTER CONTROL) ---

    fun observeAppConfig(currentUserId: String): Flow<AppConfig> = flow {
        val path = "app_config/$GLOBAL_CONFIG_ID"
        emitAll(
            db.collection("app_config").document(GLOBAL_CONFIG_ID)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            AppConfig::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        ) ?: AppConfig()
                    } else {
                        AppConfig()
                    }
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.GET, path, currentUserId)
                    emit(AppConfig())
                }
        )
    }

    suspend fun saveAppConfig(config: AppConfig): Result<Unit> {
        val path = "app_config/$GLOBAL_CONFIG_ID"
        return try {
            val uid = requireUserId()
            val ref = db.collection("app_config").document(GLOBAL_CONFIG_ID)
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.update(
                    mapOf(
                        "defaultModelId" to config.defaultModelId.take(64).ifBlank { "gemini-3.8-flash" },
                        "ownerSystemPrompt" to config.ownerSystemPrompt.take(4000),
                        "ownerPersonaName" to config.ownerPersonaName.take(80).ifBlank { "Infinity Core" },
                        "ownerResponseStyle" to config.ownerResponseStyle.take(120).ifBlank { "Balanced" },
                        "ownerRules" to config.ownerRules.take(4000),
                        "defaultLanguage" to config.defaultLanguage.take(64).ifBlank { "English" },
                        "codingStudioEnabled" to config.codingStudioEnabled,
                        "educationSuiteEnabled" to config.educationSuiteEnabled,
                        "voiceAiEnabled" to config.voiceAiEnabled,
                        "imageGenEnabled" to config.imageGenEnabled,
                        "webSearchEnabled" to config.webSearchEnabled,
                        "openAiEnabled" to config.openAiEnabled,
                        "rateLimitPerMinute" to config.rateLimitPerMinute.coerceIn(1L, 1000L),
                        "updatedBy" to uid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.set(
                    mapOf(
                        "defaultModelId" to config.defaultModelId.take(64).ifBlank { "gemini-3.8-flash" },
                        "ownerSystemPrompt" to config.ownerSystemPrompt.take(4000),
                        "ownerPersonaName" to config.ownerPersonaName.take(80).ifBlank { "Infinity Core" },
                        "ownerResponseStyle" to config.ownerResponseStyle.take(120).ifBlank { "Balanced" },
                        "ownerRules" to config.ownerRules.take(4000),
                        "defaultLanguage" to config.defaultLanguage.take(64).ifBlank { "English" },
                        "codingStudioEnabled" to config.codingStudioEnabled,
                        "educationSuiteEnabled" to config.educationSuiteEnabled,
                        "voiceAiEnabled" to config.voiceAiEnabled,
                        "imageGenEnabled" to config.imageGenEnabled,
                        "webSearchEnabled" to config.webSearchEnabled,
                        "openAiEnabled" to config.openAiEnabled,
                        "rateLimitPerMinute" to config.rateLimitPerMinute.coerceIn(1L, 1000L),
                        "updatedBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    // --- OWNER ADMIN: USERS & TELEMETRY ---

    fun observeAllUsers(currentUserId: String): Flow<List<UserProfile>> = flow {
        val path = "users"
        emitAll(
            db.collection("users")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.LIST, path, currentUserId)
                    throw error
                }
        )
    }

    suspend fun adminUpdateUser(
        targetUserId: String,
        targetEmail: String,
        role: String,
        subscriptionTier: String,
        accountStatus: String
    ): Result<Unit> {
        val path = "users/$targetUserId"
        return try {
            val adminUid = requireUserId()
            db.collection("users").document(targetUserId).update(
                mapOf(
                    "role" to role,
                    "subscriptionTier" to subscriptionTier,
                    "accountStatus" to accountStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (role == UserRole.OWNER.wireValue) {
                ensureAdminDocument(targetUserId, targetEmail, adminUid)
            } else {
                try {
                    db.collection("admins").document(targetUserId).delete().await()
                } catch (_: Exception) {
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeUsageLogs(currentUserId: String, isOwner: Boolean): Flow<List<UsageLog>> = flow {
        val path = "usage_logs"
        val query: Query = if (isOwner) {
            db.collection("usage_logs").limit(100)
        } else {
            db.collection("usage_logs").whereEqualTo("userId", currentUserId).limit(50)
        }
        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        UsageLog::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.LIST, path, currentUserId)
                    emit(emptyList())
                }
        )
    }

    suspend fun logUsage(
        userEmail: String,
        modelId: String,
        feature: String,
        status: String,
        latencyMs: Long,
        errorMessage: String? = null
    ) {
        val path = "usage_logs"
        try {
            val uid = auth.currentUser?.uid ?: return
            val docRef = db.collection("usage_logs").document()
            val payload = mutableMapOf<String, Any?>(
                "userId" to uid,
                "userEmail" to userEmail.take(256).ifBlank { "user@infinityai.app" },
                "modelId" to modelId.take(64).ifBlank { "gemini-3.8-flash" },
                "feature" to feature,
                "status" to status,
                "errorMessage" to errorMessage?.take(1000),
                "latencyMs" to latencyMs.coerceIn(0L, 600_000L),
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
        }
    }

    // --- CHATS & MESSAGES ---

    fun observeChats(userId: String): Flow<List<ChatSession>> = flow {
        val path = "users/$userId/chats"
        emitAll(
            db.collection("users").document(userId).collection("chats")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ChatSession::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareByDescending<ChatSession> { it.pinned }
                            .thenByDescending { it.updatedAt?.seconds ?: 0L }
                    )
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeMessages(userId: String, chatId: String): Flow<List<ChatMessage>> = flow {
        val path = "users/$userId/chats/$chatId/messages"
        emitAll(
            db.collection("users").document(userId)
                .collection("chats").document(chatId)
                .collection("messages")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ChatMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.createdAt?.toDate()?.time ?: Long.MAX_VALUE }
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    suspend fun createChatWithMessage(
        userId: String,
        title: String,
        mode: String,
        modelId: String,
        category: String,
        language: String,
        firstMessageContent: String,
        attachmentName: String? = null,
        attachmentType: String? = null
    ): Result<String> {
        val path = "users/$userId/chats"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            val chatRef = db.collection("users").document(userId).collection("chats").document()
            val msgRef = chatRef.collection("messages").document()
            val safeTitle = title.trim().ifBlank { "New Conversation" }.take(140)
            val safePreview = firstMessageContent.trim().take(300)

            val chatPayload = mapOf(
                "userId" to userId,
                "title" to safeTitle,
                "mode" to mode,
                "modelId" to modelId.take(64),
                "category" to category,
                "language" to language.take(64).ifBlank { "English" },
                "pinned" to false,
                "messageCount" to 1L,
                "lastMessagePreview" to safePreview,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val msgPayload = mutableMapOf<String, Any?>(
                "userId" to userId,
                "chatId" to chatRef.id,
                "role" to "user",
                "content" to firstMessageContent.take(32000),
                "modelId" to modelId.take(64),
                "attachmentName" to attachmentName?.take(256),
                "attachmentType" to attachmentType?.take(64),
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>

            val batch = db.batch()
            batch.set(chatRef, chatPayload)
            batch.set(msgRef, msgPayload)
            batch.commit().await()
            Result.success(chatRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun appendMessage(
        userId: String,
        chatId: String,
        role: String,
        content: String,
        modelId: String,
        attachmentName: String? = null,
        attachmentType: String? = null
    ): Result<String> {
        val path = "users/$userId/chats/$chatId/messages"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            val chatRef = db.collection("users").document(userId).collection("chats").document(chatId)
            val msgRef = chatRef.collection("messages").document()

            val msgPayload = mutableMapOf<String, Any?>(
                "userId" to userId,
                "chatId" to chatId,
                "role" to role,
                "content" to content.take(32000),
                "modelId" to modelId.take(64),
                "attachmentName" to attachmentName?.take(256),
                "attachmentType" to attachmentType?.take(64),
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>

            val batch = db.batch()
            batch.set(msgRef, msgPayload)
            batch.update(
                chatRef,
                mapOf(
                    "modelId" to modelId.take(64),
                    "messageCount" to FieldValue.increment(1L),
                    "lastMessagePreview" to content.trim().take(300),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(msgRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun renameChat(userId: String, chatId: String, newTitle: String): Result<Unit> {
        val path = "users/$userId/chats/$chatId"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            val title = newTitle.trim().take(140)
            require(title.isNotEmpty()) { "Title cannot be empty" }
            db.collection("users").document(userId).collection("chats").document(chatId)
                .update(mapOf("title" to title, "updatedAt" to FieldValue.serverTimestamp()))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun togglePinChat(userId: String, chatId: String, pinned: Boolean): Result<Unit> {
        val path = "users/$userId/chats/$chatId"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            db.collection("users").document(userId).collection("chats").document(chatId)
                .update(mapOf("pinned" to pinned, "updatedAt" to FieldValue.serverTimestamp()))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteChat(userId: String, chatId: String): Result<Unit> {
        val path = "users/$userId/chats/$chatId"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            val chatRef = db.collection("users").document(userId).collection("chats").document(chatId)
            val msgs = chatRef.collection("messages").get().await()
            val batch = db.batch()
            msgs.documents.forEach { batch.delete(it.reference) }
            batch.delete(chatRef)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- USER MEMORIES ---

    fun observeMemories(userId: String): Flow<List<UserMemory>> = flow {
        val path = "users/$userId/memories"
        emitAll(
            db.collection("users").document(userId).collection("memories")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        UserMemory::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    suspend fun addMemory(
        userId: String,
        fact: String,
        category: String,
        sourceChatId: String? = null
    ): Result<Unit> {
        val path = "users/$userId/memories"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            val cleanFact = fact.trim().take(1000)
            require(cleanFact.isNotEmpty()) { "Memory cannot be empty" }
            val docRef = db.collection("users").document(userId).collection("memories").document()
            val payload = mutableMapOf<String, Any?>(
                "userId" to userId,
                "fact" to cleanFact,
                "category" to category,
                "sourceChatId" to sourceChatId?.take(128),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteMemory(userId: String, memoryId: String): Result<Unit> {
        val path = "users/$userId/memories/$memoryId"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            db.collection("users").document(userId)
                .collection("memories").document(memoryId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private fun unwrapAndLogFlowError(
        error: Throwable,
        operationType: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }

    companion object {
        private const val TAG = "FirestoreRepo"
        const val GLOBAL_CONFIG_ID = "global"
    }
}
