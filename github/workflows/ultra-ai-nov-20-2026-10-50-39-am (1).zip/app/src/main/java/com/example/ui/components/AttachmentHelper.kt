package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.PendingAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

object AttachmentHelper {

    suspend fun loadImageAttachment(context: Context, uri: Uri): PendingAttachment? =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val mime = resolver.getType(uri) ?: "image/jpeg"
                val name = resolveDisplayName(context, uri) ?: "image.jpg"
                val original = resolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)
                } ?: return@withContext null

                val scaled = scaleBitmapIfNeeded(original, 1440)
                val baos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 85, baos)
                PendingAttachment(
                    displayName = name,
                    mimeType = mime,
                    isImage = true,
                    bitmap = scaled,
                    bytes = baos.toByteArray()
                )
            } catch (_: Exception) {
                null
            }
        }

    suspend fun loadDocumentAttachment(context: Context, uri: Uri): PendingAttachment? =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val mime = resolver.getType(uri) ?: "application/octet-stream"
                val name = resolveDisplayName(context, uri) ?: "document"
                val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: return@withContext null
                if (bytes.size > 18 * 1024 * 1024) {
                    return@withContext null
                }

                val isText = mime.startsWith("text/") ||
                    name.endsWith(".txt", true) ||
                    name.endsWith(".md", true) ||
                    name.endsWith(".json", true) ||
                    name.endsWith(".csv", true) ||
                    name.endsWith(".kt", true) ||
                    name.endsWith(".py", true) ||
                    name.endsWith(".js", true) ||
                    name.endsWith(".html", true)

                val preview = if (isText) {
                    String(bytes.take(12000).toByteArray(), Charsets.UTF_8)
                } else {
                    null
                }

                PendingAttachment(
                    displayName = name,
                    mimeType = mime,
                    isImage = false,
                    bytes = bytes,
                    extractedTextPreview = preview
                )
            } catch (_: Exception) {
                null
            }
        }

    private fun resolveDisplayName(context: Context, uri: Uri): String? {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return cursor.getString(idx)
                }
            }
        return uri.lastPathSegment
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxEdge: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxEdge && h <= maxEdge) return bitmap
        val ratio = maxEdge.toFloat() / maxOf(w, h).toFloat()
        return Bitmap.createScaledBitmap(
            bitmap,
            (w * ratio).toInt().coerceAtLeast(1),
            (h * ratio).toInt().coerceAtLeast(1),
            true
        )
    }
}
