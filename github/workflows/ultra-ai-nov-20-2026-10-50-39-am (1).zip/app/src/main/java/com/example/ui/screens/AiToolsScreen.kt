package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AttachmentHelper
import com.example.ui.components.MarkdownContent
import com.example.ui.viewmodel.ImageGenUiState
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ToolRunUiState
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiToolsScreen(
    viewModel: MainViewModel,
    showMenuButton: Boolean,
    onOpenDrawer: () -> Unit,
    onBackToChat: () -> Unit
) {
    BackHandler { onBackToChat() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val imageState by viewModel.imageGenState.collectAsStateWithLifecycle()
    val toolState by viewModel.toolRunState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val pendingAttachment by viewModel.pendingAttachment.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var imagePrompt by remember { mutableStateOf("") }

    val toolPresets = listOf(
        "PDF & Doc Summarizer",
        "Universal Translator",
        "Email Writer",
        "Resume Builder",
        "Presentation Slides",
        "Business & Data Analyst",
        "Web Research Assistant",
        "Website & App Architect"
    )
    var selectedTool by remember { mutableStateOf(toolPresets.first()) }
    var toolInput by remember { mutableStateOf("") }

    val docPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val att = AttachmentHelper.loadDocumentAttachment(context, uri)
                if (att != null) viewModel.setPendingAttachment(att)
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("AI Tools & Image Studio") },
            navigationIcon = {
                if (showMenuButton) {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "Open sidebar")
                    }
                }
            }
        )

        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Smart AI Tools") },
                icon = { Icon(Icons.Default.AutoFixHigh, contentDescription = null) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Image Generator") },
                icon = { Icon(Icons.Default.Brush, contentDescription = null) }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (selectedTab == 0) {
                Text("Choose Specialized Tool", style = MaterialTheme.typography.titleSmall)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    toolPresets.forEach { tool ->
                        FilterChip(
                            selected = selectedTool == tool,
                            onClick = { selectedTool = tool },
                            label = { Text(tool) }
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            docPicker.launch(
                                arrayOf("application/pdf", "text/plain", "text/csv", "application/json", "*/*")
                            )
                        },
                        modifier = Modifier.testTag("tool_attach_doc_button")
                    ) {
                        Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(pendingAttachment?.displayName ?: "Attach PDF / File")
                    }
                }

                OutlinedTextField(
                    value = toolInput,
                    onValueChange = { toolInput = it },
                    label = { Text("$selectedTool Input") },
                    placeholder = { Text("Paste text, topic, email brief, or instructions…") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tool_prompt_input"),
                    shape = RoundedCornerShape(16.dp)
                )

                Button(
                    onClick = {
                        val useSearch = selectedTool == "Web Research Assistant"
                        val prompt = """
                            Tool Mode: $selectedTool
                            Target Language: $selectedLanguage
                            Input / Context:
                            ${toolInput.ifBlank { "Analyze and summarize the attached document thoroughly." }}
                            
                            Deliver polished, structured, ready-to-use output.
                        """.trimIndent()
                        viewModel.runToolPrompt(prompt, featureTag = "tool", useWebSearch = useSearch)
                    },
                    enabled = toolInput.isNotBlank() || pendingAttachment != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("run_ai_tool_button")
                ) {
                    Text("Run $selectedTool")
                }

                when (val state = toolState) {
                    is ToolRunUiState.Loading -> LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    is ToolRunUiState.Streaming -> {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                            MarkdownContent(markdown = state.text, modifier = Modifier.padding(14.dp))
                        }
                    }
                    is ToolRunUiState.Success -> {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                            MarkdownContent(markdown = state.text, modifier = Modifier.padding(14.dp))
                        }
                    }
                    is ToolRunUiState.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
                    else -> {}
                }
            } else {
                Text(
                    text = "Powered by Gemini Nano Banana 2.1",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = imagePrompt,
                    onValueChange = { imagePrompt = it },
                    label = { Text("Describe the image to generate") },
                    placeholder = { Text("e.g., Isometric neon-lit futuristic coding workstation with holographic charts") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("image_gen_prompt_input"),
                    shape = RoundedCornerShape(16.dp)
                )

                Button(
                    onClick = { viewModel.generateAiImage(imagePrompt) },
                    enabled = imagePrompt.isNotBlank() && imageState !is ImageGenUiState.Loading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_image_button")
                ) {
                    Text("Generate Image")
                }

                when (val state = imageState) {
                    is ImageGenUiState.Idle -> {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Enter a detailed visual prompt above to synthesize custom art, diagrams, or illustrations.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                    is ImageGenUiState.Loading -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator()
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = "Synthesizing image with Nano Banana 2.1 (30–60s)…",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                    is ImageGenUiState.Success -> {
                        Image(
                            bitmap = state.bitmap.asImageBitmap(),
                            contentDescription = state.prompt,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp)),
                            contentScale = ContentScale.FillWidth
                        )
                    }
                    is ImageGenUiState.Error -> {
                        Text(
                            text = state.message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
