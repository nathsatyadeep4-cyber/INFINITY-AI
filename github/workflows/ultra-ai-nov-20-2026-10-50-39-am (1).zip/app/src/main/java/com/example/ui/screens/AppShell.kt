package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.ChatSession
import com.example.ui.theme.AmberOwner
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.UiState
import kotlinx.coroutines.launch

enum class WorkspaceRoute(val label: String, val icon: ImageVector) {
    CHAT("Smart Chat", Icons.Default.ChatBubbleOutline),
    CODING("Coding Studio", Icons.Default.Code),
    EDUCATION("Education Suite", Icons.Default.School),
    TOOLS("AI Tools & Images", Icons.Default.AutoFixHigh),
    VOICE("Voice AI", Icons.Default.GraphicEq),
    MEMORY("Memory Vault", Icons.Default.Psychology),
    OWNER_ADMIN("Owner Admin", Icons.Default.AdminPanelSettings)
}

@Composable
fun AppShell(
    viewModel: MainViewModel,
    onSignOutClick: () -> Unit
) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val chatsState by viewModel.chatsState.collectAsStateWithLifecycle()
    val activeChatId by viewModel.activeChatId.collectAsStateWithLifecycle()
    val searchQuery by viewModel.chatSearchQuery.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    var currentRoute by remember { mutableStateOf(WorkspaceRoute.CHAT) }
    var renameTarget by remember { mutableStateOf<ChatSession?>(null) }
    var renameDraft by remember { mutableStateOf("") }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusBanner) {
        val msg = statusBanner
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    val chats = (chatsState as? UiState.Success)?.data.orEmpty()
    val filteredChats = remember(chats, searchQuery) {
        if (searchQuery.isBlank()) chats
        else chats.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                it.lastMessagePreview.contains(searchQuery, ignoreCase = true)
        }
    }

    val sidebarContent: @Composable (onCloseDrawer: () -> Unit) -> Unit = { closeDrawer ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            // Branding Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.infinity_ai_logo),
                    contentDescription = "INFINITY AI Logo",
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(0.6f), RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = if (profile.hasOwnerAccess) "OWNER MASTER CONTROL" else "SMART AI WORKSPACE",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (profile.hasOwnerAccess) AmberOwner else MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(
                    onClick = { viewModel.toggleTheme() },
                    modifier = Modifier.testTag("theme_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = "Toggle Dark or Light Mode"
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // New Chat Button
            Button(
                onClick = {
                    viewModel.startNewChat()
                    currentRoute = WorkspaceRoute.CHAT
                    closeDrawer()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("new_chat_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.new_chat))
            }

            Spacer(Modifier.height(8.dp))

            // Search Chats
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setChatSearchQuery(it) },
                placeholder = { Text(stringResource(R.string.search_chats)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_chats_input"),
                shape = RoundedCornerShape(14.dp)
            )

            Spacer(Modifier.height(10.dp))

            // Workspaces
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                item {
                    Text(
                        text = "WORKSPACES",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                val availableRoutes = buildList {
                    add(WorkspaceRoute.CHAT)
                    if (appConfig.codingStudioEnabled || profile.hasOwnerAccess) add(WorkspaceRoute.CODING)
                    if (appConfig.educationSuiteEnabled || profile.hasOwnerAccess) add(WorkspaceRoute.EDUCATION)
                    add(WorkspaceRoute.TOOLS)
                    if (appConfig.voiceAiEnabled || profile.hasOwnerAccess) add(WorkspaceRoute.VOICE)
                    add(WorkspaceRoute.MEMORY)
                    if (profile.hasOwnerAccess) add(WorkspaceRoute.OWNER_ADMIN)
                }

                items(availableRoutes) { route ->
                    NavigationDrawerItem(
                        label = { Text(route.label) },
                        selected = currentRoute == route,
                        onClick = {
                            currentRoute = route
                            closeDrawer()
                        },
                        icon = {
                            Icon(
                                route.icon,
                                contentDescription = null,
                                tint = if (route == WorkspaceRoute.OWNER_ADMIN) AmberOwner
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        modifier = Modifier.testTag("nav_${route.name.lowercase()}")
                    )
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    Text(
                        text = "RECENT CONVERSATIONS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                items(filteredChats, key = { it.id }) { chat ->
                    val isSelected = chat.id == activeChatId && currentRoute == WorkspaceRoute.CHAT
                    Surface(
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectChat(chat.id)
                                currentRoute = WorkspaceRoute.CHAT
                                closeDrawer()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = chat.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (chat.lastMessagePreview.isNotBlank()) {
                                    Text(
                                        text = chat.lastMessagePreview,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            IconButton(
                                onClick = { viewModel.togglePinChat(chat.id, !chat.pinned) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.PushPin,
                                    contentDescription = "Pin chat",
                                    modifier = Modifier.size(16.dp),
                                    tint = if (chat.pinned) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    renameTarget = chat
                                    renameDraft = chat.title
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.Edit,
                                    contentDescription = "Rename chat",
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(
                                onClick = { viewModel.deleteChat(chat.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete chat",
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            // User Profile & Sign Out Footer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = profile.displayName.take(1).uppercase().ifBlank { "I" },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = profile.displayName,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${profile.parsedRole.displayLabel} • ${profile.parsedTier.displayLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(
                    onClick = onSignOutClick,
                    modifier = Modifier.testTag("sign_out_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = stringResource(R.string.sign_out))
                }
            }
        }
    }

    val renderWorkspace: @Composable (showMenuButton: Boolean, onOpenDrawer: () -> Unit) -> Unit =
        { showMenu, openDrawer ->
            when (currentRoute) {
                WorkspaceRoute.CHAT -> ChatScreen(
                    viewModel = viewModel,
                    showMenuButton = showMenu,
                    onOpenDrawer = openDrawer,
                    onOpenVoiceMode = { currentRoute = WorkspaceRoute.VOICE }
                )
                WorkspaceRoute.CODING -> CodingStudioScreen(
                    viewModel = viewModel,
                    showMenuButton = showMenu,
                    onOpenDrawer = openDrawer,
                    onBackToChat = { currentRoute = WorkspaceRoute.CHAT }
                )
                WorkspaceRoute.EDUCATION -> EducationSuiteScreen(
                    viewModel = viewModel,
                    showMenuButton = showMenu,
                    onOpenDrawer = openDrawer,
                    onBackToChat = { currentRoute = WorkspaceRoute.CHAT }
                )
                WorkspaceRoute.TOOLS -> AiToolsScreen(
                    viewModel = viewModel,
                    showMenuButton = showMenu,
                    onOpenDrawer = openDrawer,
                    onBackToChat = { currentRoute = WorkspaceRoute.CHAT }
                )
                WorkspaceRoute.VOICE -> VoiceAiScreen(
                    viewModel = viewModel,
                    showMenuButton = showMenu,
                    onOpenDrawer = openDrawer,
                    onBackToChat = { currentRoute = WorkspaceRoute.CHAT }
                )
                WorkspaceRoute.MEMORY -> MemoryVaultScreen(
                    viewModel = viewModel,
                    showMenuButton = showMenu,
                    onOpenDrawer = openDrawer,
                    onBackToChat = { currentRoute = WorkspaceRoute.CHAT }
                )
                WorkspaceRoute.OWNER_ADMIN -> OwnerAdminScreen(
                    viewModel = viewModel,
                    showMenuButton = showMenu,
                    onOpenDrawer = openDrawer,
                    onBackToChat = { currentRoute = WorkspaceRoute.CHAT }
                )
            }
        }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isExpandedScreen = maxWidth >= 840.dp
            if (isExpandedScreen) {
                Row(modifier = Modifier.fillMaxSize()) {
                    Surface(
                        modifier = Modifier
                            .width(300.dp)
                            .fillMaxHeight(),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 2.dp
                    ) {
                        sidebarContent {}
                    }
                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        renderWorkspace(false) {}
                    }
                }
            } else {
                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        ModalDrawerSheet(
                            modifier = Modifier
                                .width(310.dp)
                                .windowInsetsPadding(WindowInsets.safeDrawing)
                        ) {
                            sidebarContent { scope.launch { drawerState.close() } }
                        }
                    }
                ) {
                    renderWorkspace(true) {
                        scope.launch { drawerState.open() }
                    }
                }
            }
        }
    }

    renameTarget?.let { chat ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Conversation") },
            text = {
                OutlinedTextField(
                    value = renameDraft,
                    onValueChange = { renameDraft = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.renameChat(chat.id, renameDraft)
                        renameTarget = null
                    },
                    enabled = renameDraft.isNotBlank()
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
