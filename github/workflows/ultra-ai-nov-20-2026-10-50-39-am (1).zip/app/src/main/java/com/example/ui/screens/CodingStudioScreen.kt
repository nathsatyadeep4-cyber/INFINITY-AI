package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CodingCatalog
import com.example.ui.components.HtmlPreviewDialog
import com.example.ui.components.MarkdownContent
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ToolRunUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodingStudioScreen(
    viewModel: MainViewModel,
    showMenuButton: Boolean,
    onOpenDrawer: () -> Unit,
    onBackToChat: () -> Unit
) {
    BackHandler { onBackToChat() }

    val toolState by viewModel.toolRunState.collectAsStateWithLifecycle()
    var selectedLang by remember { mutableStateOf(CodingCatalog.languages.first()) }
    var selectedTask by remember { mutableStateOf("Generate Complete Code") }
    var codeOrPrompt by remember { mutableStateOf("") }
    var htmlToPreview by remember { mutableStateOf<String?>(null) }

    val tasks = listOf(
        "Generate Complete Code",
        "Explain Line by Line",
        "Debug & Fix Errors",
        "Optimize & Refactor",
        "Build Project Structure",
        "Create REST API"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Coding Studio") },
            navigationIcon = {
                if (showMenuButton) {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "Open sidebar")
                    }
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Programming Language / Stack", style = MaterialTheme.typography.titleSmall)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CodingCatalog.languages.forEach { lang ->
                    FilterChip(
                        selected = selectedLang == lang,
                        onClick = { selectedLang = lang },
                        label = { Text(lang) }
                    )
                }
            }

            Text("Engineering Action", style = MaterialTheme.typography.titleSmall)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tasks.forEach { task ->
                    FilterChip(
                        selected = selectedTask == task,
                        onClick = { selectedTask = task },
                        label = { Text(task) }
                    )
                }
            }

            OutlinedTextField(
                value = codeOrPrompt,
                onValueChange = { codeOrPrompt = it },
                label = { Text("Describe your app/API or paste code to debug") },
                placeholder = { Text("e.g., Build a responsive interactive calculator in HTML, CSS & JS") },
                minLines = 4,
                maxLines = 8,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("coding_prompt_input"),
                shape = RoundedCornerShape(16.dp)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val isRunning = toolState is ToolRunUiState.Loading || toolState is ToolRunUiState.Streaming
                if (isRunning) {
                    Button(
                        onClick = { viewModel.stopToolRun() },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("coding_stop_button")
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Stop")
                    }
                } else {
                    Button(
                        onClick = {
                            val prompt = """
                                Act as an expert software architect & programmer for $selectedLang.
                                Task: $selectedTask
                                Requirements / Code:
                                $codeOrPrompt
                                
                                Provide complete, production-ready code inside fenced markdown blocks with language tags.
                                If building a web app or HTML/CSS/JS component, output a single self-contained ```html block with inline CSS & JS so it can be previewed live in a sandbox.
                            """.trimIndent()
                            viewModel.runToolPrompt(prompt, featureTag = "coding")
                        },
                        enabled = codeOrPrompt.isNotBlank(),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("coding_run_button")
                    ) {
                        Icon(
                            if (selectedTask.contains("Debug")) Icons.Default.BugReport else Icons.Default.Code,
                            contentDescription = null
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Execute in Studio")
                    }
                }

                if (selectedLang == "HTML/CSS/JS" && codeOrPrompt.contains("<html", ignoreCase = true)) {
                    OutlinedButton(
                        onClick = { htmlToPreview = codeOrPrompt },
                        modifier = Modifier.testTag("preview_raw_html_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Run HTML")
                    }
                }
            }

            when (val state = toolState) {
                is ToolRunUiState.Idle -> {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Select a stack and enter your prompt or code above. HTML/CSS/JS output includes a live sandboxed Preview button!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                is ToolRunUiState.Loading -> {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                is ToolRunUiState.Streaming -> {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        MarkdownContent(
                            markdown = state.text,
                            modifier = Modifier.padding(14.dp),
                            onPreviewHtml = { htmlToPreview = it }
                        )
                    }
                }
                is ToolRunUiState.Success -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        MarkdownContent(
                            markdown = state.text,
                            modifier = Modifier.padding(14.dp),
                            onPreviewHtml = { htmlToPreview = it }
                        )
                    }
                }
                is ToolRunUiState.Error -> {
                    Text(
                        text = state.message,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    htmlToPreview?.let { html ->
        HtmlPreviewDialog(html = html, onDismiss = { htmlToPreview = null })
    }
}
