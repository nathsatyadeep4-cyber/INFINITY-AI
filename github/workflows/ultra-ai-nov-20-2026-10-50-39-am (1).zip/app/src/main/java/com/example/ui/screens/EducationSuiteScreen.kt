package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.EducationCatalog
import com.example.ui.components.MarkdownContent
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.QuizUiState
import com.example.ui.viewmodel.ToolRunUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EducationSuiteScreen(
    viewModel: MainViewModel,
    showMenuButton: Boolean,
    onOpenDrawer: () -> Unit,
    onBackToChat: () -> Unit
) {
    BackHandler { onBackToChat() }

    val toolState by viewModel.toolRunState.collectAsStateWithLifecycle()
    val quizState by viewModel.quizState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedLevel by remember { mutableStateOf(EducationCatalog.levels[3]) }
    var selectedSubject by remember { mutableStateOf(EducationCatalog.subjects[0]) }
    var selectedStudyMode by remember { mutableStateOf(EducationCatalog.studyModes[0]) }
    var topicInput by remember { mutableStateOf("") }

    val selectedAnswers = remember { mutableStateMapOf<Int, Int>() }
    var quizSubmitted by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Education Suite") },
            navigationIcon = {
                if (showMenuButton) {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "Open sidebar")
                    }
                }
            }
        )

        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Tutor & Solver") },
                icon = { Icon(Icons.Default.School, contentDescription = null) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("MCQ Practice Test") },
                icon = { Icon(Icons.Default.Quiz, contentDescription = null) }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Class / Academic Level", style = MaterialTheme.typography.titleSmall)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EducationCatalog.levels.forEach { lvl ->
                    FilterChip(
                        selected = selectedLevel == lvl,
                        onClick = { selectedLevel = lvl },
                        label = { Text(lvl) }
                    )
                }
            }

            Text("Subject", style = MaterialTheme.typography.titleSmall)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EducationCatalog.subjects.forEach { subj ->
                    FilterChip(
                        selected = selectedSubject == subj,
                        onClick = { selectedSubject = subj },
                        label = { Text(subj) }
                    )
                }
            }

            if (selectedTab == 0) {
                Text("Study Mode", style = MaterialTheme.typography.titleSmall)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EducationCatalog.studyModes.forEach { mode ->
                        FilterChip(
                            selected = selectedStudyMode == mode,
                            onClick = { selectedStudyMode = mode },
                            label = { Text(mode) }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = topicInput,
                onValueChange = { topicInput = it },
                label = { Text("Topic, Chapter, or Math Problem") },
                placeholder = { Text("e.g., Quadratic Equations, Newton's Laws, or Assamese Literature") },
                minLines = 2,
                maxLines = 5,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("education_topic_input"),
                shape = RoundedCornerShape(16.dp)
            )

            if (selectedTab == 0) {
                Button(
                    onClick = {
                        val prompt = """
                            You are an expert AI Tutor for $selectedLevel studying $selectedSubject.
                            Mode: $selectedStudyMode
                            Output Language: $selectedLanguage
                            Student Request / Topic: $topicInput
                            
                            Provide clear, step-by-step explanations in simple, encouraging language with examples, key formulas, and exam tips.
                        """.trimIndent()
                        viewModel.runToolPrompt(prompt, featureTag = "education")
                    },
                    enabled = topicInput.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("education_generate_button")
                ) {
                    Text("Generate $selectedStudyMode")
                }

                when (val state = toolState) {
                    is ToolRunUiState.Loading -> LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    is ToolRunUiState.Streaming -> {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                            MarkdownContent(markdown = state.text, modifier = Modifier.padding(14.dp))
                        }
                    }
                    is ToolRunUiState.Success -> {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                            MarkdownContent(markdown = state.text, modifier = Modifier.padding(14.dp))
                        }
                    }
                    is ToolRunUiState.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
                    else -> {}
                }
            } else {
                Button(
                    onClick = {
                        selectedAnswers.clear()
                        quizSubmitted = false
                        viewModel.generateEducationQuiz(selectedLevel, selectedSubject, topicInput)
                    },
                    enabled = topicInput.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_mcq_button")
                ) {
                    Text("Generate 5-Question MCQ Test")
                }

                when (val qState = quizState) {
                    is QuizUiState.Loading -> LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    is QuizUiState.Error -> Text(qState.message, color = MaterialTheme.colorScheme.error)
                    is QuizUiState.Ready -> {
                        if (quizSubmitted) {
                            val score = qState.questions.indices.count { i ->
                                selectedAnswers[i] == qState.questions[i].correctIndex
                            }
                            Surface(
                                color = EmeraldSuccess.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Score: $score / ${qState.questions.size}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }

                        qState.questions.forEachIndexed { qIdx, q ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Q${qIdx + 1}. ${q.question}",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    q.options.forEachIndexed { oIdx, option ->
                                        val isPicked = selectedAnswers[qIdx] == oIdx
                                        val isCorrect = oIdx == q.correctIndex
                                        val borderColor = when {
                                            quizSubmitted && isCorrect -> EmeraldSuccess
                                            quizSubmitted && isPicked && !isCorrect -> MaterialTheme.colorScheme.error
                                            isPicked -> MaterialTheme.colorScheme.primary
                                            else -> Color.Transparent
                                        }
                                        Surface(
                                            onClick = { if (!quizSubmitted) selectedAnswers[qIdx] = oIdx },
                                            shape = RoundedCornerShape(10.dp),
                                            color = MaterialTheme.colorScheme.surface,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 3.dp)
                                                .border(1.5.dp, borderColor, RoundedCornerShape(10.dp))
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                RadioButton(
                                                    selected = isPicked,
                                                    onClick = { if (!quizSubmitted) selectedAnswers[qIdx] = oIdx }
                                                )
                                                Spacer(Modifier.width(6.dp))
                                                Text(option, style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                    }

                                    if (quizSubmitted && q.explanation.isNotBlank()) {
                                        Spacer(Modifier.height(8.dp))
                                        Text(
                                            text = "Explanation: ${q.explanation}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }

                        if (!quizSubmitted) {
                            Button(
                                onClick = { quizSubmitted = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("submit_mcq_button")
                            ) {
                                Text("Submit & Grade Quiz")
                            }
                        }
                    }
                    else -> {}
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
