package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AccountStatus
import com.example.data.model.AiModelCatalog
import com.example.data.model.AppConfig
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserRole
import com.example.ui.theme.AmberOwner
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwnerAdminScreen(
    viewModel: MainViewModel,
    showMenuButton: Boolean,
    onOpenDrawer: () -> Unit,
    onBackToChat: () -> Unit
) {
    BackHandler { onBackToChat() }

    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val adminUsers by viewModel.adminUsers.collectAsStateWithLifecycle()
    val usageLogs by viewModel.usageLogs.collectAsStateWithLifecycle()
    val openAiKeyMasked by viewModel.openAiKeyMasked.collectAsStateWithLifecycle()
    val hasOpenAiKey by viewModel.hasOpenAiKey.collectAsStateWithLifecycle()

    if (!profile.hasOwnerAccess) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Access Denied: Owner Mode privileges required.")
        }
        return
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var draftConfig by remember { mutableStateOf(appConfig) }
    var openAiKeyInput by remember { mutableStateOf("") }

    LaunchedEffect(appConfig) {
        draftConfig = appConfig
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Shield,
                        contentDescription = null,
                        tint = AmberOwner
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Owner Master Control")
                }
            },
            navigationIcon = {
                if (showMenuButton) {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "Open sidebar")
                    }
                }
            }
        )

        ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 12.dp) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Master Rules") },
                icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = null) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Models & Keys") },
                icon = { Icon(Icons.Default.Key, contentDescription = null) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Users & Roles") },
                icon = { Icon(Icons.Default.Group, contentDescription = null) }
            )
            Tab(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                text = { Text("Usage & Logs") },
                icon = { Icon(Icons.Default.Analytics, contentDescription = null) }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    OutlinedTextField(
                        value = draftConfig.ownerPersonaName,
                        onValueChange = { draftConfig = draftConfig.copy(ownerPersonaName = it) },
                        label = { Text("AI Persona Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("owner_persona_input"),
                        shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = draftConfig.ownerResponseStyle,
                        onValueChange = { draftConfig = draftConfig.copy(ownerResponseStyle = it) },
                        label = { Text("Response Style") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = draftConfig.ownerSystemPrompt,
                        onValueChange = { draftConfig = draftConfig.copy(ownerSystemPrompt = it) },
                        label = { Text("Owner Master System Prompt") },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("owner_system_prompt_input"),
                        shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = draftConfig.ownerRules,
                        onValueChange = { draftConfig = draftConfig.copy(ownerRules = it) },
                        label = { Text("Custom Rules & Safety Directives") },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = draftConfig.rateLimitPerMinute.toString(),
                        onValueChange = { raw ->
                            val parsed = raw.filter { it.isDigit() }.toLongOrNull() ?: 30L
                            draftConfig = draftConfig.copy(rateLimitPerMinute = parsed.coerceIn(1L, 1000L))
                        },
                        label = { Text("Rate Limit (Requests / Minute)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    )

                    Button(
                        onClick = { viewModel.saveAppConfig(draftConfig) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_owner_config_button")
                    ) {
                        Text("Save Master Control Rules")
                    }
                }

                1 -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Google Gemini (Firebase AI Logic)", style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "Authenticated via Firebase App Check — zero client-side Gemini API key required.",
                                style = MaterialTheme.typography.bodySmall,
                                color = EmeraldSuccess
                            )
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("OpenAI API Key Vault (AES-GCM Keystore)", style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "Stored Key: $openAiKeyMasked",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (hasOpenAiKey) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = openAiKeyInput,
                                onValueChange = { openAiKeyInput = it },
                                label = { Text("Enter OpenAI API Key (sk-...)") },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("openai_key_input"),
                                shape = RoundedCornerShape(12.dp)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        viewModel.saveOpenAiApiKey(openAiKeyInput)
                                        openAiKeyInput = ""
                                    },
                                    enabled = openAiKeyInput.isNotBlank(),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("save_openai_key_button")
                                ) {
                                    Text("Encrypt & Save")
                                }
                                if (hasOpenAiKey) {
                                    OutlinedButton(
                                        onClick = { viewModel.clearOpenAiApiKey() },
                                        modifier = Modifier.testTag("clear_openai_key_button")
                                    ) {
                                        Text("Remove")
                                    }
                                }
                            }
                        }
                    }

                    Text("Default AI Model", style = MaterialTheme.typography.titleSmall)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AiModelCatalog.chatModels.forEach { model ->
                            FilterChip(
                                selected = draftConfig.defaultModelId == model.id,
                                onClick = { draftConfig = draftConfig.copy(defaultModelId = model.id) },
                                label = { Text(model.displayName) }
                            )
                        }
                    }

                    Text("Feature Switches", style = MaterialTheme.typography.titleSmall)
                    FeatureToggleRow("OpenAI Provider", draftConfig.openAiEnabled) {
                        draftConfig = draftConfig.copy(openAiEnabled = it)
                    }
                    FeatureToggleRow("Coding Studio", draftConfig.codingStudioEnabled) {
                        draftConfig = draftConfig.copy(codingStudioEnabled = it)
                    }
                    FeatureToggleRow("Education Suite", draftConfig.educationSuiteEnabled) {
                        draftConfig = draftConfig.copy(educationSuiteEnabled = it)
                    }
                    FeatureToggleRow("Voice AI Assistant", draftConfig.voiceAiEnabled) {
                        draftConfig = draftConfig.copy(voiceAiEnabled = it)
                    }
                    FeatureToggleRow("Image Generator (Nano Banana)", draftConfig.imageGenEnabled) {
                        draftConfig = draftConfig.copy(imageGenEnabled = it)
                    }
                    FeatureToggleRow("Live Web Search", draftConfig.webSearchEnabled) {
                        draftConfig = draftConfig.copy(webSearchEnabled = it)
                    }

                    Button(
                        onClick = { viewModel.saveAppConfig(draftConfig) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Apply Model & Feature Settings")
                    }
                }

                2 -> {
                    Text(
                        text = "Registered Users (${adminUsers.size})",
                        style = MaterialTheme.typography.titleSmall
                    )
                    adminUsers.forEach { user ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(user.displayName, style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            user.email,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = user.role.uppercase(),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (user.hasOwnerAccess) AmberOwner else MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SubscriptionTier.entries.forEach { tier ->
                                        FilterChip(
                                            selected = user.subscriptionTier == tier.wireValue,
                                            onClick = {
                                                viewModel.adminUpdateUser(
                                                    user.userId,
                                                    user.email,
                                                    user.role,
                                                    tier.wireValue,
                                                    user.accountStatus
                                                )
                                            },
                                            label = { Text(tier.displayLabel) }
                                        )
                                    }
                                }

                                if (user.userId != profile.userId) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        val nextRole = if (user.hasOwnerAccess) UserRole.USER.wireValue else UserRole.OWNER.wireValue
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.adminUpdateUser(
                                                    user.userId,
                                                    user.email,
                                                    nextRole,
                                                    user.subscriptionTier,
                                                    user.accountStatus
                                                )
                                            }
                                        ) {
                                            Text(if (user.hasOwnerAccess) "Demote to User" else "Grant Owner")
                                        }
                                        val nextStatus = if (user.parsedStatus == AccountStatus.ACTIVE) {
                                            AccountStatus.SUSPENDED.wireValue
                                        } else {
                                            AccountStatus.ACTIVE.wireValue
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.adminUpdateUser(
                                                    user.userId,
                                                    user.email,
                                                    user.role,
                                                    user.subscriptionTier,
                                                    nextStatus
                                                )
                                            }
                                        ) {
                                            Text(if (user.parsedStatus == AccountStatus.ACTIVE) "Suspend" else "Activate")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    val totalCalls = usageLogs.size
                    val errorCount = usageLogs.count { it.status == "error" }
                    val avgLatency = if (totalCalls > 0) usageLogs.map { it.latencyMs }.average().toLong() else 0L

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatTile("Requests", "$totalCalls", Modifier.weight(1f))
                        StatTile("Errors", "$errorCount", Modifier.weight(1f))
                        StatTile("Avg Latency", "${avgLatency}ms", Modifier.weight(1f))
                    }

                    usageLogs.forEach { log ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${log.modelId} • ${log.feature}",
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                    Text(
                                        text = "${log.status.uppercase()} (${log.latencyMs}ms)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (log.status == "error") MaterialTheme.colorScheme.error else EmeraldSuccess
                                    )
                                }
                                Text(
                                    text = log.userEmail,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (!log.errorMessage.isNullOrBlank()) {
                                    Text(
                                        text = log.errorMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun FeatureToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainer,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.headlineSmall)
        }
    }
}
