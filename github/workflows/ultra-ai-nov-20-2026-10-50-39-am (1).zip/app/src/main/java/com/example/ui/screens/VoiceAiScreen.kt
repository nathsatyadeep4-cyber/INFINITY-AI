package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatCategory
import com.example.data.model.SupportedLanguages
import com.example.ui.theme.AmberOwner
import com.example.ui.theme.CyanElectric
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceAiScreen(
    viewModel: MainViewModel,
    showMenuButton: Boolean,
    onOpenDrawer: () -> Unit,
    onBackToChat: () -> Unit
) {
    BackHandler { onBackToChat() }

    val context = LocalContext.current
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val selectedVoice by viewModel.selectedVoicePersona.collectAsStateWithLifecycle()
    val messages by viewModel.activeMessages.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val isListening by viewModel.voiceController.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.voiceController.isSpeaking.collectAsStateWithLifecycle()
    val partialTranscript by viewModel.voiceController.partialTranscript.collectAsStateWithLifecycle()
    val voiceError by viewModel.voiceController.voiceError.collectAsStateWithLifecycle()

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.voiceController.startListening(selectedLanguage) { spoken ->
                viewModel.sendChatMessage(spoken, category = ChatCategory.VOICE, autoSpeak = true)
            }
        }
    }

    val pulseTransition = rememberInfiniteTransition(label = "voice_orb")
    val orbScale by pulseTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = if (isListening || isSpeaking) 1.14f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_scale"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Voice AI Assistant") },
            navigationIcon = {
                if (showMenuButton) {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "Open sidebar")
                    }
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Voice Persona Selector
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("Balanced", "Female", "Male").forEach { persona ->
                    FilterChip(
                        selected = selectedVoice == persona,
                        onClick = { viewModel.setVoicePersona(persona) },
                        label = { Text("$persona Voice") }
                    )
                }
            }

            Spacer(Modifier.height(6.dp))

            // Language Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SupportedLanguages.all.forEach { lang ->
                    FilterChip(
                        selected = selectedLanguage == lang.name,
                        onClick = { viewModel.setLanguage(lang.name) },
                        label = { Text("${lang.name} • ${lang.nativeName}") }
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            // Animated Voice Orb
            Box(
                modifier = Modifier
                    .size(148.dp)
                    .scale(orbScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                if (isListening) MaterialTheme.colorScheme.error.copy(0.45f)
                                else if (isSpeaking) AmberOwner.copy(0.45f)
                                else CyanElectric.copy(0.35f),
                                Color.Transparent
                            )
                        )
                    )
                    .border(
                        width = 2.dp,
                        color = if (isListening) MaterialTheme.colorScheme.error
                        else if (isSpeaking) AmberOwner
                        else CyanElectric,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.Mic else Icons.Default.GraphicEq,
                    contentDescription = "Voice status orb",
                    modifier = Modifier.size(52.dp),
                    tint = Color.White
                )
            }

            Spacer(Modifier.height(12.dp))
            Text(
                text = when {
                    isListening -> partialTranscript.ifBlank { "Listening in $selectedLanguage…" }
                    isGenerating -> "Thinking…"
                    isSpeaking -> "Speaking in $selectedLanguage ($selectedVoice)…"
                    else -> "Tap Talk to start natural voice conversation"
                },
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )

            if (!voiceError.isNullOrBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = voiceError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(Modifier.height(14.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = {
                        if (isListening) {
                            viewModel.voiceController.stopListening()
                        } else {
                            val granted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (granted) {
                                viewModel.voiceController.startListening(selectedLanguage) { spoken ->
                                    viewModel.sendChatMessage(spoken, category = ChatCategory.VOICE, autoSpeak = true)
                                }
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("voice_talk_button")
                ) {
                    Icon(if (isListening) Icons.Default.Stop else Icons.Default.Mic, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isListening) "Stop Listening" else "Talk Now")
                }

                if (isSpeaking) {
                    OutlinedButton(
                        onClick = { viewModel.voiceController.interruptSpeaking() },
                        modifier = Modifier.testTag("voice_interrupt_button")
                    ) {
                        Icon(Icons.Default.VolumeOff, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Interrupt AI")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Voice Conversation Transcript History
            Surface(
                color = MaterialTheme.colorScheme.surfaceContainer,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (messages.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Voice conversation history will appear here.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages.takeLast(12)) { msg ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (msg.role == "user")
                                        MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surface
                                )
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = if (msg.role == "user") "You" else "INFINITY AI",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = msg.content,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
