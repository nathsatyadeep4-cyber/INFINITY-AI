package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// INFINITY AI Brand Palette — Midnight Obsidian, Electric Cyan, Owner Amber Gold
val ObsidianDeep = Color(0xFF070B19)
val ObsidianSurface = Color(0xFF0F1629)
val ObsidianCard = Color(0xFF162038)
val ObsidianElevated = Color(0xFF1E2B4A)
val ObsidianBorder = Color(0xFF28385E)

val CyanElectric = Color(0xFF22D3EE)
val CyanSoft = Color(0xFF67E8F9)
val CyanDeep = Color(0xFF0891B2)
val CyanContainerDark = Color(0xFF0E3A4D)

val AmberOwner = Color(0xFFF59E0B)
val AmberOwnerSoft = Color(0xFFFCD34D)
val AmberOwnerDeep = Color(0xFFB45309)
val AmberContainerDark = Color(0xFF452A08)

val EmeraldSuccess = Color(0xFF10B981)
val CoralError = Color(0xFFEF4444)
val VioletAccent = Color(0xFF818CF8)

// Light Theme Surfaces
val AlabasterBg = Color(0xFFF5F7FB)
val PureWhiteSurface = Color(0xFFFFFFFF)
val SlateCardLight = Color(0xFFEAF0F8)
val SlateBorderLight = Color(0xFFCBD5E1)
val InkPrimary = Color(0xFF0F172A)
val InkSecondary = Color(0xFF475569)

// Dark Theme Text
val StarWhite = Color(0xFFF1F5F9)
val MistGray = Color(0xFF94A3B8)
