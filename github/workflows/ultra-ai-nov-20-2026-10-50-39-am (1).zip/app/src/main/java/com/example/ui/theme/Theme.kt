package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val InfinityDarkColorScheme = darkColorScheme(
    primary = CyanElectric,
    onPrimary = ObsidianDeep,
    primaryContainer = CyanContainerDark,
    onPrimaryContainer = CyanSoft,
    secondary = AmberOwner,
    onSecondary = ObsidianDeep,
    secondaryContainer = AmberContainerDark,
    onSecondaryContainer = AmberOwnerSoft,
    tertiary = VioletAccent,
    onTertiary = ObsidianDeep,
    background = ObsidianDeep,
    onBackground = StarWhite,
    surface = ObsidianSurface,
    onSurface = StarWhite,
    surfaceVariant = ObsidianCard,
    onSurfaceVariant = MistGray,
    surfaceContainerLowest = ObsidianDeep,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianCard,
    surfaceContainerHigh = ObsidianElevated,
    outline = ObsidianBorder,
    outlineVariant = Color(0xFF1F2D4D),
    error = CoralError,
    onError = Color.White
)

private val InfinityLightColorScheme = lightColorScheme(
    primary = CyanDeep,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCFFAFE),
    onPrimaryContainer = Color(0xFF083344),
    secondary = AmberOwnerDeep,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFEF3C7),
    onSecondaryContainer = Color(0xFF451A03),
    tertiary = Color(0xFF4F46E5),
    onTertiary = Color.White,
    background = AlabasterBg,
    onBackground = InkPrimary,
    surface = PureWhiteSurface,
    onSurface = InkPrimary,
    surfaceVariant = SlateCardLight,
    onSurfaceVariant = InkSecondary,
    surfaceContainerLowest = PureWhiteSurface,
    surfaceContainerLow = AlabasterBg,
    surfaceContainer = SlateCardLight,
    surfaceContainerHigh = Color(0xFFE2E8F0),
    outline = SlateBorderLight,
    outlineVariant = Color(0xFFE2E8F0),
    error = Color(0xFFDC2626),
    onError = Color.White
)

val InfinityShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun InfinityAiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) InfinityDarkColorScheme else InfinityLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = InfinityTypography,
        shapes = InfinityShapes,
        content = content
    )
}
