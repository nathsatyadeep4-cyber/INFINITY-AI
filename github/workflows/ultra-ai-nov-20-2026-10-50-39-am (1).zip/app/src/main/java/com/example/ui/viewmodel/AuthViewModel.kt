package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.data.model.AccountStatus
import com.example.data.model.UserProfile
import com.example.data.repository.AuthGateway
import com.example.data.repository.AuthRepository
import com.example.data.repository.DuplicateSignInRequestException
import com.example.data.repository.FirestoreRepository
import com.example.data.repository.NoGoogleAccountException
import com.example.data.repository.SignInCancelledException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

sealed interface AuthUiState {
    data object Initializing : AuthUiState
    data class Unauthenticated(val message: String? = null) : AuthUiState
    data class Suspended(val email: String) : AuthUiState
    data class Authenticated(val user: FirebaseUser, val profile: UserProfile) : AuthUiState
}

class AuthViewModel(
    private val authRepository: AuthGateway,
    private val profileResolver: suspend (FirebaseUser) -> Result<UserProfile>
) : ViewModel() {

    constructor(
        authRepository: AuthRepository,
        firestoreRepository: FirestoreRepository
    ) : this(
        authRepository = authRepository,
        profileResolver = { user -> firestoreRepository.ensureUserProfile(user) }
    )

    private val _authState = MutableStateFlow<AuthUiState>(AuthUiState.Initializing)
    val authState: StateFlow<AuthUiState> = _authState.asStateFlow()

    private val _isSigningIn = MutableStateFlow(false)
    val isSigningIn: StateFlow<Boolean> = _isSigningIn.asStateFlow()

    private var autoSignInAttempted = false
    private var activeSignInJob: Job? = null
    private val profileMutex = Mutex()
    private var resolvedUid: String? = null

    init {
        viewModelScope.launch {
            authRepository.authStateFlow().collect { user ->
                if (user == null) {
                    resolvedUid = null
                    if (_authState.value !is AuthUiState.Unauthenticated) {
                        _authState.value = AuthUiState.Unauthenticated()
                    }
                } else {
                    resolveUserProfile(user)
                }
            }
        }
    }

    fun tryAutoSignInIfNeeded(context: Context) {
        if (autoSignInAttempted) return
        autoSignInAttempted = true
        if (authRepository.currentUser() != null) return

        viewModelScope.launch {
            val res = authRepository.attemptAutoSignIn(context)
            res.onSuccess { user ->
                if (user == null && _authState.value is AuthUiState.Initializing) {
                    _authState.value = AuthUiState.Unauthenticated()
                }
            }.onFailure {
                if (_authState.value is AuthUiState.Initializing) {
                    _authState.value = AuthUiState.Unauthenticated()
                }
            }
        }
    }

    fun signInWithGoogle(context: Context) {
        if (_isSigningIn.value || activeSignInJob?.isActive == true) return
        activeSignInJob = viewModelScope.launch {
            _isSigningIn.value = true
            try {
                val result = authRepository.signInInteractive(context)
                result.onSuccess { user ->
                    resolveUserProfile(user)
                }.onFailure { error ->
                    if (error is DuplicateSignInRequestException) return@onFailure
                    val message = when (error) {
                        is SignInCancelledException -> error.message
                        is NoGoogleAccountException -> error.message
                        else -> error.localizedMessage ?: "Google Sign-In failed. Please try again."
                    }
                    _authState.value = AuthUiState.Unauthenticated(message)
                }
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isSigningIn.value = false
            }
        }
    }

    fun cancelSignIn() {
        activeSignInJob?.cancel()
        activeSignInJob = null
        _isSigningIn.value = false
        _authState.value = AuthUiState.Unauthenticated(null)
    }

    fun dismissError() {
        if (_authState.value is AuthUiState.Unauthenticated) {
            _authState.value = AuthUiState.Unauthenticated(null)
        }
    }

    private suspend fun resolveUserProfile(user: FirebaseUser) {
        profileMutex.withLock {
            val current = _authState.value
            if (current is AuthUiState.Authenticated && resolvedUid == user.uid) {
                return
            }
            val profileResult = profileResolver(user)
            profileResult.onSuccess { profile ->
                resolvedUid = user.uid
                if (profile.parsedStatus == AccountStatus.SUSPENDED && !profile.hasOwnerAccess) {
                    _authState.value = AuthUiState.Suspended(profile.email)
                } else {
                    _authState.value = AuthUiState.Authenticated(user, profile)
                }
            }.onFailure { error ->
                resolvedUid = null
                Log.e(TAG, "Failed to resolve Firestore user profile", error)
                _authState.value = AuthUiState.Unauthenticated(
                    "Signed in, but could not load profile: ${error.localizedMessage ?: "Firestore error"}"
                )
            }
        }
    }

    fun signOut(context: Context) {
        viewModelScope.launch {
            activeSignInJob?.cancel()
            activeSignInJob = null
            _isSigningIn.value = false
            resolvedUid = null
            authRepository.signOut(context)
            _authState.value = AuthUiState.Unauthenticated()
        }
    }

    companion object {
        private const val TAG = "AuthViewModel"

        fun provideFactory(context: Context): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val appContext = context.applicationContext
                val db = FirebaseFirestore.getInstance(
                    appContext.getString(R.string.firestore_database_id)
                )
                AuthViewModel(
                    authRepository = AuthRepository(),
                    firestoreRepository = FirestoreRepository(db)
                )
            }
        }
    }
}
