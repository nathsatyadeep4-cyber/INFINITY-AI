package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.core.SecureKeyVault
import com.example.data.ai.AiOrchestrator
import com.example.data.ai.McqQuestion
import com.example.data.ai.VoiceController
import com.example.data.model.AiMode
import com.example.data.model.AiModelCatalog
import com.example.data.model.AppConfig
import com.example.data.model.ChatCategory
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.model.PendingAttachment
import com.example.data.model.UserMemory
import com.example.data.model.UserProfile
import com.example.data.model.UsageLog
import com.example.data.repository.FirestoreRepository
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface ImageGenUiState {
    data object Idle : ImageGenUiState
    data object Loading : ImageGenUiState
    data class Success(val bitmap: Bitmap, val prompt: String) : ImageGenUiState
    data class Error(val message: String) : ImageGenUiState
}

sealed interface QuizUiState {
    data object Idle : QuizUiState
    data object Loading : QuizUiState
    data class Ready(val questions: List<McqQuestion>) : QuizUiState
    data class Error(val message: String) : QuizUiState
}

sealed interface ToolRunUiState {
    data object Idle : ToolRunUiState
    data object Loading : ToolRunUiState
    data class Streaming(val text: String) : ToolRunUiState
    data class Success(val text: String) : ToolRunUiState
    data class Error(val message: String) : ToolRunUiState
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    private val currentUserId: String,
    private val initialProfile: UserProfile,
    private val firestoreRepository: FirestoreRepository,
    private val aiOrchestrator: AiOrchestrator,
    private val keyVault: SecureKeyVault,
    val voiceController: VoiceController
) : ViewModel() {

    // --- REALTIME FIRESTORE STREAMS ---

    val userProfile: StateFlow<UserProfile> = firestoreRepository.observeUserProfile(currentUserId)
        .map { it ?: initialProfile }
        .catch { error ->
            unwrapFirestoreOrRethrow(error, "userProfile")
            emit(initialProfile)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), initialProfile)

    val appConfig: StateFlow<AppConfig> = firestoreRepository.observeAppConfig(currentUserId)
        .catch { error ->
            unwrapFirestoreOrRethrow(error, "appConfig")
            emit(AppConfig())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppConfig())

    val chatsState: StateFlow<UiState<List<ChatSession>>> = firestoreRepository.observeChats(currentUserId)
        .map<List<ChatSession>, UiState<List<ChatSession>>> { UiState.Success(it) }
        .catch { error ->
            val msg = unwrapFirestoreOrRethrow(error, "chats")
            emit(UiState.Error(msg))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val memoriesState: StateFlow<UiState<List<UserMemory>>> = firestoreRepository.observeMemories(currentUserId)
        .map<List<UserMemory>, UiState<List<UserMemory>>> { UiState.Success(it) }
        .catch { error ->
            val msg = unwrapFirestoreOrRethrow(error, "memories")
            emit(UiState.Error(msg))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private val _activeChatId = MutableStateFlow<String?>(null)
    val activeChatId: StateFlow<String?> = _activeChatId.asStateFlow()

    val activeMessages: StateFlow<List<ChatMessage>> = _activeChatId
        .flatMapLatest { chatId ->
            if (chatId.isNullOrBlank()) flowOf(emptyList())
            else firestoreRepository.observeMessages(currentUserId, chatId)
                .catch { error ->
                    unwrapFirestoreOrRethrow(error, "messages")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminUsers: StateFlow<List<UserProfile>> =
        if (initialProfile.hasOwnerAccess) {
            firestoreRepository.observeAllUsers(currentUserId)
                .catch { error ->
                    unwrapFirestoreOrRethrow(error, "adminUsers")
                    emit(emptyList())
                }
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
        } else {
            MutableStateFlow(emptyList())
        }

    val usageLogs: StateFlow<List<UsageLog>> = firestoreRepository.observeUsageLogs(
        currentUserId = currentUserId,
        isOwner = initialProfile.hasOwnerAccess
    )
        .catch { error ->
            unwrapFirestoreOrRethrow(error, "usageLogs")
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // --- WORKSPACE INTERACTIVE STATES ---

    private val _activeMode = MutableStateFlow(
        if (initialProfile.hasOwnerAccess) AiMode.OWNER else AiMode.SMART
    )
    val activeMode: StateFlow<AiMode> = _activeMode.asStateFlow()

    private val _selectedModelId = MutableStateFlow(AiModelCatalog.GEMINI_3_8_FLASH.id)
    val selectedModelId: StateFlow<String> = _selectedModelId.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(initialProfile.preferredLanguage.ifBlank { "English" })
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _selectedVoicePersona = MutableStateFlow(initialProfile.preferredVoice.ifBlank { "Balanced" })
    val selectedVoicePersona: StateFlow<String> = _selectedVoicePersona.asStateFlow()

    private val _webSearchEnabled = MutableStateFlow(false)
    val webSearchEnabled: StateFlow<Boolean> = _webSearchEnabled.asStateFlow()

    private val _chatSearchQuery = MutableStateFlow("")
    val chatSearchQuery: StateFlow<String> = _chatSearchQuery.asStateFlow()

    private val _pendingAttachment = MutableStateFlow<PendingAttachment?>(null)
    val pendingAttachment: StateFlow<PendingAttachment?> = _pendingAttachment.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingReply = MutableStateFlow<String?>(null)
    val streamingReply: StateFlow<String?> = _streamingReply.asStateFlow()

    private val _chatError = MutableStateFlow<String?>(null)
    val chatError: StateFlow<String?> = _chatError.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _imageGenState = MutableStateFlow<ImageGenUiState>(ImageGenUiState.Idle)
    val imageGenState: StateFlow<ImageGenUiState> = _imageGenState.asStateFlow()

    private val _quizState = MutableStateFlow<QuizUiState>(QuizUiState.Idle)
    val quizState: StateFlow<QuizUiState> = _quizState.asStateFlow()

    private val _toolRunState = MutableStateFlow<ToolRunUiState>(ToolRunUiState.Idle)
    val toolRunState: StateFlow<ToolRunUiState> = _toolRunState.asStateFlow()

    private val _openAiKeyMasked = MutableStateFlow(keyVault.maskedSecret(SecureKeyVault.SLOT_OPENAI_KEY))
    val openAiKeyMasked: StateFlow<String> = _openAiKeyMasked.asStateFlow()

    private val _hasOpenAiKey = MutableStateFlow(keyVault.hasSecret(SecureKeyVault.SLOT_OPENAI_KEY))
    val hasOpenAiKey: StateFlow<Boolean> = _hasOpenAiKey.asStateFlow()

    private var activeGenJob: Job? = null
    private var activeToolJob: Job? = null

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun setMode(mode: AiMode) {
        if (mode == AiMode.OWNER && !userProfile.value.hasOwnerAccess) {
            _statusBanner.value = "Owner Mode is restricted to authorized Owners."
            return
        }
        _activeMode.value = mode
    }

    fun setModel(modelId: String) {
        _selectedModelId.value = modelId
    }

    fun setLanguage(language: String) {
        _selectedLanguage.value = language
        viewModelScope.launch {
            firestoreRepository.updateUserPreferences(
                userId = currentUserId,
                memoryEnabled = userProfile.value.memoryEnabled,
                preferredLanguage = language,
                preferredVoice = _selectedVoicePersona.value
            )
        }
    }

    fun setVoicePersona(voice: String) {
        _selectedVoicePersona.value = voice
        viewModelScope.launch {
            firestoreRepository.updateUserPreferences(
                userId = currentUserId,
                memoryEnabled = userProfile.value.memoryEnabled,
                preferredLanguage = _selectedLanguage.value,
                preferredVoice = voice
            )
        }
    }

    fun toggleMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch {
            firestoreRepository.updateUserPreferences(
                userId = currentUserId,
                memoryEnabled = enabled,
                preferredLanguage = _selectedLanguage.value,
                preferredVoice = _selectedVoicePersona.value
            )
        }
    }

    fun toggleWebSearch() {
        _webSearchEnabled.value = !_webSearchEnabled.value
    }

    fun setChatSearchQuery(query: String) {
        _chatSearchQuery.value = query
    }

    fun setPendingAttachment(attachment: PendingAttachment?) {
        _pendingAttachment.value = attachment
    }

    fun clearChatError() {
        _chatError.value = null
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun startNewChat() {
        stopGenerating()
        _activeChatId.value = null
        _chatError.value = null
    }

    fun selectChat(chatId: String) {
        stopGenerating()
        _activeChatId.value = chatId
        _chatError.value = null
    }

    fun renameChat(chatId: String, newTitle: String) {
        viewModelScope.launch {
            firestoreRepository.renameChat(currentUserId, chatId, newTitle)
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to rename chat." }
        }
    }

    fun togglePinChat(chatId: String, pinned: Boolean) {
        viewModelScope.launch {
            firestoreRepository.togglePinChat(currentUserId, chatId, pinned)
        }
    }

    fun deleteChat(chatId: String) {
        viewModelScope.launch {
            if (_activeChatId.value == chatId) {
                _activeChatId.value = null
            }
            firestoreRepository.deleteChat(currentUserId, chatId)
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to delete chat." }
        }
    }

    // --- CHAT STREAMING, STOP, REGENERATE ---

    fun sendChatMessage(
        rawPrompt: String,
        category: ChatCategory = ChatCategory.CHAT,
        autoSpeak: Boolean = false
    ) {
        val prompt = rawPrompt.trim()
        val attachment = _pendingAttachment.value
        if (prompt.isEmpty() && attachment == null) return

        val effectivePrompt = prompt.ifEmpty {
            "Please analyze this attached file (${attachment?.displayName})."
        }

        val currentProfile = userProfile.value
        val mode = if (currentProfile.hasOwnerAccess) _activeMode.value else AiMode.SMART
        val modelId = _selectedModelId.value
        val language = _selectedLanguage.value
        val config = appConfig.value
        val memories = (memoriesState.value as? UiState.Success)?.data ?: emptyList()
        val historySnapshot = activeMessages.value

        _pendingAttachment.value = null
        _chatError.value = null
        voiceController.interruptSpeaking()

        activeGenJob?.cancel()
        activeGenJob = viewModelScope.launch {
            val startMs = System.currentTimeMillis()
            _isGenerating.value = true
            _streamingReply.value = ""
            val accumulated = StringBuilder()

            var chatId = _activeChatId.value
            if (chatId.isNullOrBlank()) {
                val createRes = firestoreRepository.createChatWithMessage(
                    userId = currentUserId,
                    title = effectivePrompt.take(44),
                    mode = mode.wireValue,
                    modelId = modelId,
                    category = category.wireValue,
                    language = language,
                    firstMessageContent = effectivePrompt,
                    attachmentName = attachment?.displayName,
                    attachmentType = attachment?.mimeType
                )
                createRes.onSuccess { newId ->
                    chatId = newId
                    _activeChatId.value = newId
                }.onFailure { err ->
                    _isGenerating.value = false
                    _streamingReply.value = null
                    _chatError.value = "Could not save chat: ${err.localizedMessage}"
                    return@launch
                }
            } else {
                firestoreRepository.appendMessage(
                    userId = currentUserId,
                    chatId = chatId!!,
                    role = "user",
                    content = effectivePrompt,
                    modelId = modelId,
                    attachmentName = attachment?.displayName,
                    attachmentType = attachment?.mimeType
                )
            }

            // Optional background memory extraction when memory is enabled
            if (currentProfile.memoryEnabled && effectivePrompt.length > 18) {
                launch {
                    val fact = aiOrchestrator.extractMemoryFact(effectivePrompt)
                    if (!fact.isNullOrBlank()) {
                        firestoreRepository.addMemory(
                            userId = currentUserId,
                            fact = fact,
                            category = "context",
                            sourceChatId = chatId
                        )
                    }
                }
            }

            try {
                aiOrchestrator.streamChatReply(
                    modelId = modelId,
                    mode = mode,
                    appConfig = config,
                    language = language,
                    history = historySnapshot,
                    userPrompt = effectivePrompt,
                    attachment = attachment,
                    memories = memories,
                    memoryEnabled = currentProfile.memoryEnabled,
                    enableWebSearch = _webSearchEnabled.value
                ).collect { delta ->
                    accumulated.append(delta)
                    _streamingReply.value = accumulated.toString()
                }

                val finalText = accumulated.toString().trim()
                if (finalText.isNotEmpty() && !chatId.isNullOrBlank()) {
                    firestoreRepository.appendMessage(
                        userId = currentUserId,
                        chatId = chatId!!,
                        role = "model",
                        content = finalText,
                        modelId = modelId
                    )
                    if (autoSpeak) {
                        voiceController.speak(finalText, language, _selectedVoicePersona.value)
                    }
                    firestoreRepository.logUsage(
                        userEmail = currentProfile.email,
                        modelId = modelId,
                        feature = category.wireValue,
                        status = "success",
                        latencyMs = System.currentTimeMillis() - startMs
                    )
                } else {
                    _chatError.value = "The AI model returned an empty response."
                }
            } catch (e: CancellationException) {
                // Save partial streamed response if user tapped Stop Generating
                val partial = accumulated.toString().trim()
                if (partial.isNotEmpty() && !chatId.isNullOrBlank()) {
                    firestoreRepository.appendMessage(
                        userId = currentUserId,
                        chatId = chatId!!,
                        role = "model",
                        content = "$partial\n\n*(Stopped)*",
                        modelId = modelId
                    )
                }
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI generation failed", e)
                val msg = e.localizedMessage ?: "Generation failed."
                _chatError.value = msg
                firestoreRepository.logUsage(
                    userEmail = currentProfile.email,
                    modelId = modelId,
                    feature = category.wireValue,
                    status = "error",
                    latencyMs = System.currentTimeMillis() - startMs,
                    errorMessage = msg
                )
            } finally {
                _isGenerating.value = false
                _streamingReply.value = null
            }
        }
    }

    fun stopGenerating() {
        activeGenJob?.cancel()
        activeGenJob = null
        _isGenerating.value = false
        _streamingReply.value = null
    }

    fun regenerateLastResponse() {
        val lastUserMsg = activeMessages.value.lastOrNull { it.role == "user" } ?: return
        val historyBeforeLast = activeMessages.value.dropLastWhile { it.role != "user" }.dropLast(1)
        val chatId = _activeChatId.value ?: return
        val currentProfile = userProfile.value
        val mode = if (currentProfile.hasOwnerAccess) _activeMode.value else AiMode.SMART
        val modelId = _selectedModelId.value
        val language = _selectedLanguage.value
        val memories = (memoriesState.value as? UiState.Success)?.data ?: emptyList()

        _chatError.value = null
        activeGenJob?.cancel()
        activeGenJob = viewModelScope.launch {
            val startMs = System.currentTimeMillis()
            _isGenerating.value = true
            _streamingReply.value = ""
            val accumulated = StringBuilder()
            try {
                aiOrchestrator.streamChatReply(
                    modelId = modelId,
                    mode = mode,
                    appConfig = appConfig.value,
                    language = language,
                    history = historyBeforeLast,
                    userPrompt = lastUserMsg.content,
                    attachment = null,
                    memories = memories,
                    memoryEnabled = currentProfile.memoryEnabled,
                    enableWebSearch = _webSearchEnabled.value
                ).collect { delta ->
                    accumulated.append(delta)
                    _streamingReply.value = accumulated.toString()
                }
                val finalText = accumulated.toString().trim()
                if (finalText.isNotEmpty()) {
                    firestoreRepository.appendMessage(
                        userId = currentUserId,
                        chatId = chatId,
                        role = "model",
                        content = finalText,
                        modelId = modelId
                    )
                    firestoreRepository.logUsage(
                        userEmail = currentProfile.email,
                        modelId = modelId,
                        feature = "chat",
                        status = "success",
                        latencyMs = System.currentTimeMillis() - startMs
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _chatError.value = e.localizedMessage ?: "Regeneration failed."
            } finally {
                _isGenerating.value = false
                _streamingReply.value = null
            }
        }
    }

    // --- DEDICATED STUDIOS (CODING, EDUCATION, TOOLS, IMAGE GEN) ---

    fun runToolPrompt(prompt: String, featureTag: String, useWebSearch: Boolean = false) {
        activeToolJob?.cancel()
        val currentProfile = userProfile.value
        val mode = if (currentProfile.hasOwnerAccess) _activeMode.value else AiMode.SMART
        val memories = (memoriesState.value as? UiState.Success)?.data ?: emptyList()
        val modelId = _selectedModelId.value

        activeToolJob = viewModelScope.launch {
            val startMs = System.currentTimeMillis()
            _toolRunState.value = ToolRunUiState.Loading
            val accumulated = StringBuilder()
            try {
                aiOrchestrator.streamChatReply(
                    modelId = modelId,
                    mode = mode,
                    appConfig = appConfig.value,
                    language = _selectedLanguage.value,
                    history = emptyList(),
                    userPrompt = prompt,
                    attachment = _pendingAttachment.value,
                    memories = memories,
                    memoryEnabled = currentProfile.memoryEnabled,
                    enableWebSearch = useWebSearch
                ).collect { delta ->
                    accumulated.append(delta)
                    _toolRunState.value = ToolRunUiState.Streaming(accumulated.toString())
                }
                val final = accumulated.toString().trim()
                if (final.isNotEmpty()) {
                    _toolRunState.value = ToolRunUiState.Success(final)
                    firestoreRepository.logUsage(
                        userEmail = currentProfile.email,
                        modelId = modelId,
                        feature = featureTag,
                        status = "success",
                        latencyMs = System.currentTimeMillis() - startMs
                    )
                } else {
                    _toolRunState.value = ToolRunUiState.Error("Empty response from model.")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = e.localizedMessage ?: "Tool execution failed."
                _toolRunState.value = ToolRunUiState.Error(msg)
                firestoreRepository.logUsage(
                    userEmail = currentProfile.email,
                    modelId = modelId,
                    feature = featureTag,
                    status = "error",
                    latencyMs = System.currentTimeMillis() - startMs,
                    errorMessage = msg
                )
            }
        }
    }

    fun stopToolRun() {
        activeToolJob?.cancel()
        activeToolJob = null
        val current = _toolRunState.value
        if (current is ToolRunUiState.Streaming && current.text.isNotBlank()) {
            _toolRunState.value = ToolRunUiState.Success(current.text)
        } else {
            _toolRunState.value = ToolRunUiState.Idle
        }
    }

    fun generateAiImage(prompt: String) {
        if (prompt.isBlank()) return
        if (!appConfig.value.imageGenEnabled) {
            _imageGenState.value = ImageGenUiState.Error("Image Generation is disabled by the Owner.")
            return
        }
        viewModelScope.launch {
            val startMs = System.currentTimeMillis()
            _imageGenState.value = ImageGenUiState.Loading
            try {
                val bitmap = aiOrchestrator.generateImage(prompt.trim())
                _imageGenState.value = ImageGenUiState.Success(bitmap, prompt.trim())
                firestoreRepository.logUsage(
                    userEmail = userProfile.value.email,
                    modelId = AiModelCatalog.GEMINI_NANO_BANANA.id,
                    feature = "image_gen",
                    status = "success",
                    latencyMs = System.currentTimeMillis() - startMs
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = e.localizedMessage ?: "Image generation failed."
                _imageGenState.value = ImageGenUiState.Error(msg)
                firestoreRepository.logUsage(
                    userEmail = userProfile.value.email,
                    modelId = AiModelCatalog.GEMINI_NANO_BANANA.id,
                    feature = "image_gen",
                    status = "error",
                    latencyMs = System.currentTimeMillis() - startMs,
                    errorMessage = msg
                )
            }
        }
    }

    fun generateEducationQuiz(level: String, subject: String, topic: String) {
        if (topic.isBlank()) return
        viewModelScope.launch {
            val startMs = System.currentTimeMillis()
            _quizState.value = QuizUiState.Loading
            try {
                val questions = aiOrchestrator.generateMcqQuiz(
                    level = level,
                    subject = subject,
                    topic = topic.trim(),
                    language = _selectedLanguage.value,
                    count = 5
                )
                _quizState.value = QuizUiState.Ready(questions)
                firestoreRepository.logUsage(
                    userEmail = userProfile.value.email,
                    modelId = AiModelCatalog.GEMINI_3_8_FLASH.id,
                    feature = "education",
                    status = "success",
                    latencyMs = System.currentTimeMillis() - startMs
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = e.localizedMessage ?: "Failed to generate MCQ test."
                _quizState.value = QuizUiState.Error(msg)
                firestoreRepository.logUsage(
                    userEmail = userProfile.value.email,
                    modelId = AiModelCatalog.GEMINI_3_8_FLASH.id,
                    feature = "education",
                    status = "error",
                    latencyMs = System.currentTimeMillis() - startMs,
                    errorMessage = msg
                )
            }
        }
    }

    // --- MEMORY MANAGEMENT ---

    fun addMemory(fact: String, category: String) {
        viewModelScope.launch {
            firestoreRepository.addMemory(currentUserId, fact, category)
                .onSuccess { _statusBanner.value = "Memory saved." }
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to save memory." }
        }
    }

    fun deleteMemory(memoryId: String) {
        viewModelScope.launch {
            firestoreRepository.deleteMemory(currentUserId, memoryId)
        }
    }

    // --- OWNER ADMIN DASHBOARD ACTIONS ---

    fun saveAppConfig(updated: AppConfig) {
        if (!userProfile.value.hasOwnerAccess) {
            _statusBanner.value = "Owner permission required."
            return
        }
        viewModelScope.launch {
            firestoreRepository.saveAppConfig(updated)
                .onSuccess { _statusBanner.value = "Master Control configuration saved." }
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to save config." }
        }
    }

    fun saveOpenAiApiKey(apiKey: String) {
        if (!userProfile.value.hasOwnerAccess) return
        keyVault.saveSecret(SecureKeyVault.SLOT_OPENAI_KEY, apiKey)
        _openAiKeyMasked.value = keyVault.maskedSecret(SecureKeyVault.SLOT_OPENAI_KEY)
        _hasOpenAiKey.value = keyVault.hasSecret(SecureKeyVault.SLOT_OPENAI_KEY)
        _statusBanner.value = "OpenAI API key encrypted & stored in Android Keystore."
    }

    fun clearOpenAiApiKey() {
        if (!userProfile.value.hasOwnerAccess) return
        keyVault.clearSecret(SecureKeyVault.SLOT_OPENAI_KEY)
        _openAiKeyMasked.value = keyVault.maskedSecret(SecureKeyVault.SLOT_OPENAI_KEY)
        _hasOpenAiKey.value = false
        _statusBanner.value = "OpenAI API key removed."
    }

    fun adminUpdateUser(
        targetUserId: String,
        targetEmail: String,
        role: String,
        subscriptionTier: String,
        accountStatus: String
    ) {
        if (!userProfile.value.hasOwnerAccess) return
        viewModelScope.launch {
            firestoreRepository.adminUpdateUser(targetUserId, targetEmail, role, subscriptionTier, accountStatus)
                .onSuccess { _statusBanner.value = "Updated user $targetEmail." }
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to update user." }
        }
    }

    private fun unwrapFirestoreOrRethrow(error: Throwable, tag: String): String {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val root = firestoreError ?: error
        Log.w(TAG, "Stream error in $tag", root)
        return root.message ?: "Failed to sync $tag."
    }

    override fun onCleared() {
        super.onCleared()
        voiceController.release()
    }

    companion object {
        private const val TAG = "MainViewModel"

        fun provideFactory(
            context: Context,
            currentUserId: String,
            initialProfile: UserProfile
        ): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val appContext = context.applicationContext
                val db = FirebaseFirestore.getInstance(
                    appContext.getString(R.string.firestore_database_id)
                )
                val vault = SecureKeyVault(appContext)
                MainViewModel(
                    currentUserId = currentUserId,
                    initialProfile = initialProfile,
                    firestoreRepository = FirestoreRepository(db),
                    aiOrchestrator = AiOrchestrator(vault),
                    keyVault = vault,
                    voiceController = VoiceController(appContext)
                )
            }
        }
    }
}
