package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.UserProfile
import com.example.data.repository.AuthGateway
import com.example.data.repository.NoGoogleAccountException
import com.example.data.repository.SignInCancelledException
import com.example.ui.viewmodel.AuthUiState
import com.example.ui.viewmodel.AuthViewModel
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuthViewModelTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    private class FakeAuthGateway : AuthGateway {
        val userFlow = MutableStateFlow<FirebaseUser?>(null)
        var autoSignInCalls = 0
        var interactiveCalls = 0
        var nextInteractiveDeferred: CompletableDeferred<Result<FirebaseUser>>? = null
        var nextInteractiveResult: Result<FirebaseUser> =
            Result.failure(SignInCancelledException("Cancelled"))

        override fun currentUser(): FirebaseUser? = userFlow.value

        override fun authStateFlow(): Flow<FirebaseUser?> = userFlow

        override suspend fun attemptAutoSignIn(context: Context): Result<FirebaseUser?> {
            autoSignInCalls++
            return Result.success(null)
        }

        override suspend fun signInInteractive(context: Context): Result<FirebaseUser> {
            interactiveCalls++
            val deferred = nextInteractiveDeferred
            return deferred?.await() ?: nextInteractiveResult
        }

        override suspend fun signOut(context: Context) {
            userFlow.value = null
        }
    }

    @Test
    fun `auto sign in unavailable stays unauthenticated without interactive loop`() = runTest(testDispatcher) {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val fakeGateway = FakeAuthGateway()
        val vm = AuthViewModel(fakeGateway) { Result.success(UserProfile()) }

        vm.tryAutoSignInIfNeeded(context)
        vm.tryAutoSignInIfNeeded(context)
        advanceUntilIdle()

        assertEquals(1, fakeGateway.autoSignInCalls)
        assertEquals(0, fakeGateway.interactiveCalls)
        assertEquals(AuthUiState.Unauthenticated(null), vm.authState.value)
        assertFalse(vm.isSigningIn.value)
    }

    @Test
    fun `duplicate concurrent google sign in clicks trigger only one request`() = runTest(testDispatcher) {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val fakeGateway = FakeAuthGateway()
        val pending = CompletableDeferred<Result<FirebaseUser>>()
        fakeGateway.nextInteractiveDeferred = pending

        val vm = AuthViewModel(fakeGateway) { Result.success(UserProfile()) }
        advanceUntilIdle()

        vm.signInWithGoogle(context)
        vm.signInWithGoogle(context)
        vm.signInWithGoogle(context)
        testDispatcher.scheduler.runCurrent()

        assertTrue(vm.isSigningIn.value)
        assertEquals(1, fakeGateway.interactiveCalls)

        pending.complete(Result.failure(SignInCancelledException("Google Sign-In was cancelled.")))
        advanceUntilIdle()

        assertFalse(vm.isSigningIn.value)
        val state = vm.authState.value as AuthUiState.Unauthenticated
        assertEquals("Google Sign-In was cancelled.", state.message)
    }

    @Test
    fun `cancelSignIn stops in-flight sign in and clears error`() = runTest(testDispatcher) {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val fakeGateway = FakeAuthGateway()
        fakeGateway.nextInteractiveDeferred = CompletableDeferred()

        val vm = AuthViewModel(fakeGateway) { Result.success(UserProfile()) }
        advanceUntilIdle()

        vm.signInWithGoogle(context)
        testDispatcher.scheduler.runCurrent()
        assertTrue(vm.isSigningIn.value)

        vm.cancelSignIn()
        advanceUntilIdle()

        assertFalse(vm.isSigningIn.value)
        val state = vm.authState.value as AuthUiState.Unauthenticated
        assertNull(state.message)
    }

    @Test
    fun `dismissError clears error message and allows retry`() = runTest(testDispatcher) {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val fakeGateway = FakeAuthGateway().apply {
            nextInteractiveResult = Result.failure(NoGoogleAccountException("No Google account found."))
        }

        val vm = AuthViewModel(fakeGateway) { Result.success(UserProfile()) }
        advanceUntilIdle()

        vm.signInWithGoogle(context)
        advanceUntilIdle()

        assertEquals(
            "No Google account found.",
            (vm.authState.value as AuthUiState.Unauthenticated).message
        )

        vm.dismissError()
        assertNull((vm.authState.value as AuthUiState.Unauthenticated).message)

        vm.signInWithGoogle(context)
        advanceUntilIdle()
        assertEquals(2, fakeGateway.interactiveCalls)
    }
}
