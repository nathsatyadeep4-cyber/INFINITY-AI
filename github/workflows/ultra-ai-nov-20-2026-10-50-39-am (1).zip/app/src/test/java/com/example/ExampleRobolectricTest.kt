package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppConfig
import com.example.data.model.SubscriptionTier
import com.example.ui.screens.AuthScreen
import com.example.ui.theme.InfinityAiTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule
  val composeRule = createComposeRule()

  @Test
  fun `app branding and resources use INFINITY AI`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    val tagline = context.getString(R.string.tagline)
    val placeholder = context.getString(R.string.message_placeholder)

    assertEquals("INFINITY AI", appName)
    assertEquals("Beyond Limits. Beyond Intelligence.", tagline)
    assertTrue(placeholder.contains("INFINITY AI"))

    val defaultConfig = AppConfig()
    assertEquals("Infinity Core", defaultConfig.ownerPersonaName)
    assertTrue(defaultConfig.ownerSystemPrompt.contains("INFINITY AI"))
    assertEquals("Infinity", SubscriptionTier.INFINITY.displayLabel)
  }

  @Test
  fun `auth screen exposes continue with google, cancel, and retry controls`() {
    var signInClicks = 0
    var cancelClicks = 0
    var dismissClicks = 0

    composeRule.setContent {
      InfinityAiTheme(darkTheme = true) {
        AuthScreen(
          isLoading = false,
          errorMessage = "Sign-in was cancelled.",
          onGoogleSignInClick = { signInClicks++ },
          onCancelSignInClick = { cancelClicks++ },
          onDismissErrorClick = { dismissClicks++ }
        )
      }
    }

    composeRule.onNodeWithTag("google_sign_in_button").assertIsDisplayed()
    composeRule.onNodeWithTag("retry_sign_in_button").assertIsDisplayed().performClick()
    composeRule.onNodeWithTag("cancel_error_button").assertIsDisplayed().performClick()

    assertEquals(1, signInClicks)
    assertEquals(1, dismissClicks)
    assertEquals(0, cancelClicks)
  }
}
