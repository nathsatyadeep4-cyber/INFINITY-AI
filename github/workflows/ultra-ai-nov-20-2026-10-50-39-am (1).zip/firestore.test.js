const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const OWNER_UID = "owner_satya";
const OWNER_EMAIL = "satya18x@gmail.com";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function pastDate(offsetMs = 5000) {
  return new Date(Date.now() - offsetMs);
}

test("Unauthenticated requests are denied across all collections", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("app_config").doc("global").get());
  await assertFails(unauth.collection("usage_logs").where("userId", "==", ALICE_UID).get());
  await assertFails(
    unauth.collection("users").doc(ALICE_UID).collection("chats").get()
  );
});

test("Email spoofing with unverified email cannot obtain owner privileges", async () => {
  const spoofOwner = testEnv
    .authenticatedContext("spoof_uid", {
      email: OWNER_EMAIL,
      email_verified: false,
    })
    .firestore();

  const now = pastDate();
  await assertFails(
    spoofOwner.collection("users").doc("spoof_uid").set({
      userId: "spoof_uid",
      email: OWNER_EMAIL,
      displayName: "Spoofer",
      role: "owner",
      subscriptionTier: "ultra",
      accountStatus: "active",
      memoryEnabled: true,
      preferredLanguage: "English",
      preferredVoice: "Balanced",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(
    spoofOwner.collection("app_config").doc("global").set({
      defaultModelId: "gemini-3.8-flash",
      ownerSystemPrompt: "Hacked",
      ownerPersonaName: "Hack",
      ownerResponseStyle: "Balanced",
      ownerRules: "",
      defaultLanguage: "English",
      codingStudioEnabled: true,
      educationSuiteEnabled: true,
      voiceAiEnabled: true,
      imageGenEnabled: true,
      webSearchEnabled: true,
      openAiEnabled: true,
      rateLimitPerMinute: 30,
      updatedBy: "spoof_uid",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Normal user cannot self-assign owner role, ghost fields, or list all users", async () => {
  const alice = testEnv
    .authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true })
    .firestore();
  const now = pastDate();

  // Cannot self-assign owner
  await assertFails(
    alice.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      role: "owner",
      subscriptionTier: "free",
      accountStatus: "active",
      memoryEnabled: true,
      preferredLanguage: "English",
      preferredVoice: "Balanced",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Cannot inject ghost field
  await assertFails(
    alice.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      role: "user",
      subscriptionTier: "free",
      accountStatus: "active",
      memoryEnabled: true,
      preferredLanguage: "English",
      preferredVoice: "Balanced",
      isVerified: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Valid normal user registration succeeds
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      role: "user",
      subscriptionTier: "free",
      accountStatus: "active",
      memoryEnabled: true,
      preferredLanguage: "English",
      preferredVoice: "Balanced",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Normal user can update allowed preferences
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).update({
      preferredLanguage: "Hindi",
      memoryEnabled: false,
      updatedAt: pastDate(1000),
    })
  );

  // Normal user cannot escalate own role or subscriptionTier
  await assertFails(
    alice.collection("users").doc(ALICE_UID).update({
      role: "owner",
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    alice.collection("users").doc(ALICE_UID).update({
      subscriptionTier: "ultra",
      updatedAt: pastDate(500),
    })
  );

  // Normal user cannot list users collection (PII protection)
  await assertFails(alice.collection("users").get());
});

test("Bootstrapped verified owner can manage app_config, list users, and update user roles/tiers", async () => {
  const owner = testEnv
    .authenticatedContext(OWNER_UID, { email: OWNER_EMAIL, email_verified: true })
    .firestore();
  const alice = testEnv
    .authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true })
    .firestore();
  const now = pastDate();

  // Owner creates own profile with owner role
  await assertSucceeds(
    owner.collection("users").doc(OWNER_UID).set({
      userId: OWNER_UID,
      email: OWNER_EMAIL,
      displayName: "Satya (Owner)",
      role: "owner",
      subscriptionTier: "ultra",
      accountStatus: "active",
      memoryEnabled: true,
      preferredLanguage: "English",
      preferredVoice: "Balanced",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice creates normal profile
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      role: "user",
      subscriptionTier: "free",
      accountStatus: "active",
      memoryEnabled: true,
      preferredLanguage: "English",
      preferredVoice: "Balanced",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Owner creates global app_config
  await assertSucceeds(
    owner.collection("app_config").doc("global").set({
      defaultModelId: "gemini-3.8-flash",
      ownerSystemPrompt: "Be concise and helpful.",
      ownerPersonaName: "Infinity Core",
      ownerResponseStyle: "Balanced",
      ownerRules: "Always cite formulas clearly.",
      defaultLanguage: "English",
      codingStudioEnabled: true,
      educationSuiteEnabled: true,
      voiceAiEnabled: true,
      imageGenEnabled: true,
      webSearchEnabled: true,
      openAiEnabled: true,
      rateLimitPerMinute: 30,
      updatedBy: OWNER_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice can read app_config/global, but cannot modify it
  await assertSucceeds(alice.collection("app_config").doc("global").get());
  await assertFails(
    alice.collection("app_config").doc("global").update({
      ownerSystemPrompt: "Override",
      updatedAt: pastDate(1000),
    })
  );

  // Owner can list users and upgrade Alice's subscription
  await assertSucceeds(owner.collection("users").get());
  await assertSucceeds(
    owner.collection("users").doc(ALICE_UID).update({
      subscriptionTier: "pro",
      updatedAt: pastDate(1000),
    })
  );
});

test("User chat sessions, messages, and memories enforce strict user isolation and schema parity", async () => {
  const alice = testEnv
    .authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true })
    .firestore();
  const bob = testEnv
    .authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true })
    .firestore();
  const now = pastDate();

  // Batch create chat + first message (mirrors Kotlin WriteBatch)
  const batch = alice.batch();
  const chatRef = alice.collection("users").doc(ALICE_UID).collection("chats").doc("chat_1");
  const msgRef = chatRef.collection("messages").doc("msg_1");
  batch.set(chatRef, {
    userId: ALICE_UID,
    title: "Kotlin Coroutines Help",
    mode: "smart",
    modelId: "gemini-3.8-flash",
    category: "coding",
    language: "English",
    pinned: false,
    messageCount: 1,
    lastMessagePreview: "Explain Flow vs StateFlow",
    createdAt: now,
    updatedAt: now,
  });
  batch.set(msgRef, {
    userId: ALICE_UID,
    chatId: "chat_1",
    role: "user",
    content: "Explain Flow vs StateFlow",
    modelId: "gemini-3.8-flash",
    createdAt: now,
  });
  await assertSucceeds(batch.commit());

  // Alice lists her chats & messages
  await assertSucceeds(alice.collection("users").doc(ALICE_UID).collection("chats").get());
  await assertSucceeds(chatRef.collection("messages").get());

  // Alice updates chat title
  await assertSucceeds(
    chatRef.update({
      title: "Coroutines Deep Dive",
      pinned: true,
      updatedAt: pastDate(1000),
    })
  );

  // Reject immutable createdAt mutation
  await assertFails(
    chatRef.update({
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );

  // Reject @DocumentId 'id' in payload
  await assertFails(
    alice.collection("users").doc(ALICE_UID).collection("chats").doc("chat_2").set({
      id: "chat_2",
      userId: ALICE_UID,
      title: "Bad ID",
      mode: "smart",
      modelId: "gemini-3.8-flash",
      category: "chat",
      language: "English",
      pinned: false,
      messageCount: 0,
      lastMessagePreview: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob cannot read or write Alice's chats, messages, or memories
  await assertFails(bob.collection("users").doc(ALICE_UID).collection("chats").get());
  await assertFails(bob.collection("users").doc(ALICE_UID).collection("chats").doc("chat_1").get());
  await assertFails(bob.collection("users").doc(ALICE_UID).collection("memories").get());

  // Alice creates and updates a memory
  const memRef = alice.collection("users").doc(ALICE_UID).collection("memories").doc("mem_1");
  await assertSucceeds(
    memRef.set({
      userId: ALICE_UID,
      fact: "Prefers Kotlin Jetpack Compose examples.",
      category: "preference",
      sourceChatId: "chat_1",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    memRef.update({
      fact: "Prefers Jetpack Compose with Material 3.",
      updatedAt: pastDate(1000),
    })
  );
});

test("Usage logs enforce scoped queries for regular users and full access for owner", async () => {
  const alice = testEnv
    .authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true })
    .firestore();
  const bob = testEnv
    .authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true })
    .firestore();
  const owner = testEnv
    .authenticatedContext(OWNER_UID, { email: OWNER_EMAIL, email_verified: true })
    .firestore();
  const now = pastDate();

  await assertSucceeds(
    alice.collection("usage_logs").doc("log_1").set({
      userId: ALICE_UID,
      userEmail: "alice@example.com",
      modelId: "gemini-3.8-flash",
      feature: "chat",
      status: "success",
      latencyMs: 840,
      createdAt: now,
    })
  );

  // Alice can query her own logs
  await assertSucceeds(alice.collection("usage_logs").where("userId", "==", ALICE_UID).get());
  // Unfiltered query by Alice or Bob fails
  await assertFails(alice.collection("usage_logs").get());
  await assertFails(bob.collection("usage_logs").where("userId", "==", ALICE_UID).get());
  // Logs are immutable
  await assertFails(alice.collection("usage_logs").doc("log_1").update({ status: "error" }));
  // Owner can list all usage logs
  await assertSucceeds(owner.collection("usage_logs").get());
});
