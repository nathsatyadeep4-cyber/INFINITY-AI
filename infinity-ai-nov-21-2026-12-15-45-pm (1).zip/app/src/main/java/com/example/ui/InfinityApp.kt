package com.example.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.SmartModeType
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MemoryScreen
import com.example.ui.screens.OwnerModeScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.theme.InfinityAiTheme

object AppRoutes {
    const val HOME = "home"
    const val CHAT = "chat"
    const val TOOLS = "tools"
    const val MEMORY = "memory"
    const val OWNER = "owner"
}

private data class NavDestinationItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun InfinityApp(
    viewModel: InfinityViewModel = viewModel()
) {
    val ownerConfig by viewModel.ownerConfig.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val messages by viewModel.activeMessages.collectAsStateWithLifecycle()
    val chatUiState by viewModel.chatUiState.collectAsStateWithLifecycle()
    val imageStudioState by viewModel.imageStudioState.collectAsStateWithLifecycle()
    val toolResultState by viewModel.toolResultState.collectAsStateWithLifecycle()
    val webSearchResults by viewModel.webSearchResults.collectAsStateWithLifecycle()
    val isWebSearching by viewModel.isWebSearching.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val studyTopics by viewModel.studyTopics.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val ownerUnlocked by viewModel.ownerUnlocked.collectAsStateWithLifecycle()
    val apiTestStatus by viewModel.apiTestStatus.collectAsStateWithLifecycle()

    val hasOpenAiKey = remember(ownerConfig.openAiApiKey) {
        viewModel.hasOpenAiKeyConfigured()
    }

    var selectedToolTab by remember { mutableIntStateOf(0) }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: AppRoutes.HOME

    val destinations = remember {
        listOf(
            NavDestinationItem(AppRoutes.HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
            NavDestinationItem(AppRoutes.CHAT, "Chat", Icons.AutoMirrored.Filled.Chat, Icons.AutoMirrored.Outlined.Chat, "nav_chat"),
            NavDestinationItem(AppRoutes.TOOLS, "Tools", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome, "nav_tools"),
            NavDestinationItem(AppRoutes.MEMORY, "Memory", Icons.Filled.Psychology, Icons.Outlined.Psychology, "nav_memory"),
            NavDestinationItem(AppRoutes.OWNER, "Owner", Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings, "nav_owner")
        )
    }

    fun navigateTopLevel(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    InfinityAiTheme(themeMode = ownerConfig.themeMode) {
        val density = LocalDensity.current
        val isImeVisible = WindowInsets.ime.getBottom(density) > 0

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavRail = maxWidth >= 600.dp
            val hideBottomBarForKeyboard =
                isImeVisible && (currentRoute == AppRoutes.CHAT || currentRoute == AppRoutes.HOME)

            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.systemBars,
                bottomBar = {
                    if (!useNavRail && !hideBottomBarForKeyboard) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            destinations.forEach { item ->
                                val selected = currentRoute == item.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(item.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = item.label,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    modifier = Modifier.testTag(item.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .consumeWindowInsets(innerPadding)
                        .imePadding()
                ) {
                    if (useNavRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            destinations.forEach { item ->
                                val selected = currentRoute == item.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(item.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    },
                                    label = { Text(item.label) },
                                    modifier = Modifier.testTag(item.testTag)
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = AppRoutes.HOME,
                        modifier = Modifier.weight(1f)
                    ) {
                        composable(AppRoutes.HOME) {
                            HomeScreen(
                                config = ownerConfig,
                                hasOpenAiKey = hasOpenAiKey,
                                recentSessions = sessions,
                                voiceState = voiceState,
                                onQuickPromptSubmit = { prompt ->
                                    viewModel.startNewSession(SmartModeType.CHAT)
                                    viewModel.sendChatMessage(prompt)
                                    navigateTopLevel(AppRoutes.CHAT)
                                },
                                onStartVoiceInput = { callback -> viewModel.startVoiceInput(callback) },
                                onStopVoiceInput = { viewModel.stopVoiceInput() },
                                onOpenChatMode = { mode ->
                                    viewModel.selectMode(mode)
                                    navigateTopLevel(AppRoutes.CHAT)
                                },
                                onOpenToolTab = { tabIndex ->
                                    selectedToolTab = tabIndex
                                    viewModel.resetToolResult()
                                    navigateTopLevel(AppRoutes.TOOLS)
                                },
                                onOpenMemory = { navigateTopLevel(AppRoutes.MEMORY) },
                                onOpenOwnerMode = { navigateTopLevel(AppRoutes.OWNER) },
                                onSelectSession = { sessionId ->
                                    viewModel.selectSession(sessionId)
                                    navigateTopLevel(AppRoutes.CHAT)
                                }
                            )
                        }

                        composable(AppRoutes.CHAT) {
                            ChatScreen(
                                config = ownerConfig,
                                hasOpenAiKey = hasOpenAiKey,
                                chatUiState = chatUiState,
                                messages = messages,
                                voiceState = voiceState,
                                onSelectMode = viewModel::selectMode,
                                onToggleWebSearch = viewModel::toggleChatWebSearch,
                                onNewChat = { viewModel.startNewSession(chatUiState.selectedMode) },
                                onAttachImage = viewModel::attachImage,
                                onAttachDocument = viewModel::attachDocument,
                                onClearAttachments = viewModel::clearPendingAttachments,
                                onSendMessage = viewModel::sendChatMessage,
                                onClearError = viewModel::clearChatError,
                                onStartVoiceInput = viewModel::startVoiceInput,
                                onStopVoiceInput = viewModel::stopVoiceInput,
                                onSpeakText = viewModel::speakText,
                                onStopSpeaking = viewModel::stopSpeaking,
                                onUpdateConfig = viewModel::updateOwnerConfig,
                                onOpenOwnerMode = { navigateTopLevel(AppRoutes.OWNER) }
                            )
                        }

                        composable(AppRoutes.TOOLS) {
                            ToolsScreen(
                                selectedTab = selectedToolTab,
                                onSelectTab = { idx ->
                                    selectedToolTab = idx
                                    viewModel.resetToolResult()
                                },
                                config = ownerConfig,
                                hasOpenAiKey = hasOpenAiKey,
                                imageStudioState = imageStudioState,
                                toolResultState = toolResultState,
                                webSearchResults = webSearchResults,
                                isWebSearching = isWebSearching,
                                studyTopics = studyTopics,
                                onGenerateImage = viewModel::generateStudioImage,
                                onRunToolPrompt = viewModel::runToolPrompt,
                                onRunWebSearch = viewModel::runLiveWebSearch,
                                onSaveStudyTopic = viewModel::saveStudyTopic,
                                onBoostStudyMastery = { topic -> viewModel.boostStudyMastery(topic) },
                                onDeleteStudyTopic = viewModel::deleteStudyTopic,
                                onSpeakText = viewModel::speakText,
                                onOpenOwnerMode = { navigateTopLevel(AppRoutes.OWNER) }
                            )
                        }

                        composable(AppRoutes.MEMORY) {
                            MemoryScreen(
                                memories = memories,
                                sessions = sessions,
                                memoryEnabled = ownerConfig.memoryEnabled,
                                onAddMemory = viewModel::addMemory,
                                onDeleteMemory = viewModel::deleteMemory,
                                onClearMemories = viewModel::clearAllMemories,
                                onSelectSession = { sessionId ->
                                    viewModel.selectSession(sessionId)
                                    navigateTopLevel(AppRoutes.CHAT)
                                },
                                onTogglePinSession = viewModel::togglePinSession,
                                onDeleteSession = viewModel::deleteSession,
                                onClearAllChats = viewModel::clearAllChats
                            )
                        }

                        composable(AppRoutes.OWNER) {
                            OwnerModeScreen(
                                config = ownerConfig,
                                ownerUnlocked = ownerUnlocked,
                                apiTestStatus = apiTestStatus,
                                onUnlockOwner = viewModel::unlockOwnerMode,
                                onLockOwner = viewModel::lockOwnerMode,
                                onUpdateConfig = viewModel::updateOwnerConfig,
                                onTestOpenAiKey = viewModel::testOpenAiKey,
                                onPreviewEnglishVoice = viewModel::previewEnglishVoice,
                                onPreviewHindiVoice = viewModel::previewHindiVoice,
                                onClearAllChats = viewModel::clearAllChats,
                                onClearAllMemories = viewModel::clearAllMemories
                            )
                        }
                    }
                }
            }
        }
    }
}
