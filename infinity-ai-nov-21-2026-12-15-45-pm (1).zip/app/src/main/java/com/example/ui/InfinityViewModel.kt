package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.local.InfinityDatabase
import com.example.data.local.MemoryItemEntity
import com.example.data.local.OwnerSettingsStore
import com.example.data.local.StudyTopicEntity
import com.example.data.model.ImageGenerationResult
import com.example.data.model.OwnerConfig
import com.example.data.model.SmartModeType
import com.example.data.model.WebSearchResult
import com.example.data.remote.OpenAiApiService
import com.example.data.remote.WebSearchService
import com.example.data.repository.AiRepository
import com.example.data.repository.ChatRepository
import com.example.data.repository.InfinityAiRepository
import com.example.util.LoadedDocument
import com.example.util.MediaAndDocHelper
import com.example.util.NotificationAndLocationHelper
import com.example.util.VoiceManager
import com.example.util.VoiceUiState
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatUiState(
    val selectedMode: SmartModeType = SmartModeType.CHAT,
    val isSending: Boolean = false,
    val useWebSearch: Boolean = false,
    val errorMessage: String? = null,
    val pendingImageUri: Uri? = null,
    val pendingDocument: LoadedDocument? = null
)

sealed interface ImageStudioState {
    data object Idle : ImageStudioState
    data object Loading : ImageStudioState
    data class Success(val result: ImageGenerationResult) : ImageStudioState
    data class Error(val message: String) : ImageStudioState
}

sealed interface ToolResultState {
    data object Idle : ToolResultState
    data object Loading : ToolResultState
    data class Success(
        val text: String,
        val engineLabel: String,
        val isSampleNotice: Boolean
    ) : ToolResultState
    data class Error(val message: String) : ToolResultState
}

@OptIn(ExperimentalCoroutinesApi::class)
class InfinityViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsStore = OwnerSettingsStore(application)
    private val openAiApi = OpenAiApiService()
    private val webSearchService = WebSearchService()
    private val aiRepository: AiRepository = InfinityAiRepository(openAiApi, webSearchService)
    private val dao = InfinityDatabase.getInstance(application).infinityDao()
    private val chatRepository = ChatRepository(dao, aiRepository)
    private val voiceManager = VoiceManager(application)

    val ownerConfig: StateFlow<OwnerConfig> = settingsStore.configFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = OwnerConfig()
    )

    val sessions: StateFlow<List<ChatSessionEntity>> = chatRepository.sessions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val memories: StateFlow<List<MemoryItemEntity>> = chatRepository.memories.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val studyTopics: StateFlow<List<StudyTopicEntity>> = chatRepository.studyTopics.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _activeSessionId = MutableStateFlow<Long?>(null)
    val activeSessionId: StateFlow<Long?> = _activeSessionId.asStateFlow()

    val activeMessages: StateFlow<List<ChatMessageEntity>> = _activeSessionId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else chatRepository.observeMessages(id)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _chatUiState = MutableStateFlow(ChatUiState())
    val chatUiState: StateFlow<ChatUiState> = _chatUiState.asStateFlow()

    private val _imageStudioState = MutableStateFlow<ImageStudioState>(ImageStudioState.Idle)
    val imageStudioState: StateFlow<ImageStudioState> = _imageStudioState.asStateFlow()

    private val _toolResultState = MutableStateFlow<ToolResultState>(ToolResultState.Idle)
    val toolResultState: StateFlow<ToolResultState> = _toolResultState.asStateFlow()

    private val _webSearchResults = MutableStateFlow<List<WebSearchResult>>(emptyList())
    val webSearchResults: StateFlow<List<WebSearchResult>> = _webSearchResults.asStateFlow()

    private val _isWebSearching = MutableStateFlow(false)
    val isWebSearching: StateFlow<Boolean> = _isWebSearching.asStateFlow()

    val voiceState: StateFlow<VoiceUiState> = voiceManager.state

    private val _ownerUnlocked = MutableStateFlow(false)
    val ownerUnlocked: StateFlow<Boolean> = _ownerUnlocked.asStateFlow()

    private val _apiTestStatus = MutableStateFlow<String?>(null)
    val apiTestStatus: StateFlow<String?> = _apiTestStatus.asStateFlow()

    fun hasOpenAiKeyConfigured(): Boolean =
        aiRepository.resolveEffectiveOpenAiKey(ownerConfig.value).isNotBlank()

    fun selectMode(mode: SmartModeType) {
        _chatUiState.value = _chatUiState.value.copy(
            selectedMode = mode,
            useWebSearch = mode == SmartModeType.WEB_SEARCH || _chatUiState.value.useWebSearch
        )
    }

    fun toggleChatWebSearch() {
        _chatUiState.value = _chatUiState.value.copy(useWebSearch = !_chatUiState.value.useWebSearch)
    }

    fun attachImage(uri: Uri?) {
        _chatUiState.value = _chatUiState.value.copy(pendingImageUri = uri)
    }

    fun attachDocument(uri: Uri) {
        viewModelScope.launch {
            MediaAndDocHelper.loadDocument(getApplication(), uri)
                .onSuccess { doc ->
                    _chatUiState.value = _chatUiState.value.copy(pendingDocument = doc)
                }
                .onFailure { err ->
                    _chatUiState.value = _chatUiState.value.copy(
                        errorMessage = err.localizedMessage ?: "Failed to read document."
                    )
                }
        }
    }

    fun clearPendingAttachments() {
        _chatUiState.value = _chatUiState.value.copy(pendingImageUri = null, pendingDocument = null)
    }

    fun clearChatError() {
        _chatUiState.value = _chatUiState.value.copy(errorMessage = null)
    }

    fun startNewSession(mode: SmartModeType = SmartModeType.CHAT) {
        _activeSessionId.value = null
        _chatUiState.value = _chatUiState.value.copy(
            selectedMode = mode,
            useWebSearch = mode == SmartModeType.WEB_SEARCH,
            errorMessage = null
        )
    }

    fun selectSession(sessionId: Long) {
        _activeSessionId.value = sessionId
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            chatRepository.deleteSession(sessionId)
            if (_activeSessionId.value == sessionId) {
                _activeSessionId.value = null
            }
        }
    }

    fun togglePinSession(session: ChatSessionEntity) {
        viewModelScope.launch { chatRepository.togglePinSession(session) }
    }

    fun sendChatMessage(rawPrompt: String) {
        val prompt = rawPrompt.trim()
        val state = _chatUiState.value
        if (prompt.isBlank() && state.pendingImageUri == null && state.pendingDocument == null) return
        if (state.isSending) return

        val effectivePrompt = prompt.ifBlank {
            when {
                state.pendingImageUri != null -> "Analyze this image in detail."
                state.pendingDocument != null -> "Summarize and explain the key points in this document."
                else -> "Hello"
            }
        }

        viewModelScope.launch {
            _chatUiState.value = _chatUiState.value.copy(isSending = true, errorMessage = null)
            val config = ownerConfig.value

            val sessionId = _activeSessionId.value ?: chatRepository.createSession(
                title = effectivePrompt,
                mode = state.selectedMode,
                engineLabel = config.activeEngine.label
            ).also { _activeSessionId.value = it }

            val imageUrl = state.pendingImageUri?.let { uri ->
                MediaAndDocHelper.encodeImageToDataUrl(getApplication(), uri).getOrNull()
            }

            val attachmentLabel = listOfNotNull(
                state.pendingImageUri?.let { "Image attached" },
                state.pendingDocument?.let { "Doc: ${it.displayName}" }
            ).joinToString(" • ").ifBlank { null }

            val locationHint = if (config.locationContextEnabled) {
                NotificationAndLocationHelper.getApproximateLocationHint(getApplication())
            } else null

            val result = chatRepository.sendMessage(
                sessionId = sessionId,
                prompt = effectivePrompt,
                mode = state.selectedMode,
                config = config,
                useWebSearch = state.useWebSearch,
                attachmentLabel = attachmentLabel,
                attachmentUri = state.pendingImageUri?.toString(),
                documentContext = state.pendingDocument?.extractedText,
                imageBase64DataUrl = imageUrl,
                locationHint = locationHint
            )

            result.onSuccess { reply ->
                _chatUiState.value = _chatUiState.value.copy(
                    isSending = false,
                    pendingImageUri = null,
                    pendingDocument = null
                )
                if (config.voiceAutoSpeak && config.voiceEnabled) {
                    speakText(reply.text)
                }
            }.onFailure { err ->
                _chatUiState.value = _chatUiState.value.copy(
                    isSending = false,
                    errorMessage = err.localizedMessage ?: "Failed to generate response."
                )
            }
        }
    }

    fun generateStudioImage(prompt: String, aspectRatio: String, stylePreset: String) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            _imageStudioState.value = ImageStudioState.Loading
            aiRepository.generateImage(
                prompt = prompt.trim(),
                aspectRatio = aspectRatio,
                stylePreset = stylePreset,
                config = ownerConfig.value
            ).onSuccess { res ->
                _imageStudioState.value = ImageStudioState.Success(res)
                NotificationAndLocationHelper.postAiNotification(
                    getApplication(),
                    "INFINITY AI Image Studio",
                    "Your image request finished (${res.engineLabel})."
                )
            }.onFailure { err ->
                _imageStudioState.value = ImageStudioState.Error(
                    err.localizedMessage ?: "Image generation failed."
                )
            }
        }
    }

    fun runToolPrompt(
        prompt: String,
        mode: SmartModeType,
        documentContext: String? = null,
        useWebSearch: Boolean = false
    ) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            _toolResultState.value = ToolResultState.Loading
            val config = ownerConfig.value
            val topMemories = if (config.memoryEnabled) emptyList<MemoryItemEntity>() else emptyList()
            aiRepository.generateResponse(
                prompt = prompt.trim(),
                mode = mode,
                config = config,
                memories = topMemories,
                useWebSearch = useWebSearch,
                documentContext = documentContext
            ).onSuccess { res ->
                _toolResultState.value = ToolResultState.Success(
                    text = res.text,
                    engineLabel = res.engineLabel,
                    isSampleNotice = res.isSampleNotice
                )
            }.onFailure { err ->
                _toolResultState.value = ToolResultState.Error(
                    err.localizedMessage ?: "Tool execution failed."
                )
            }
        }
    }

    fun resetToolResult() {
        _toolResultState.value = ToolResultState.Idle
    }

    fun runLiveWebSearch(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _isWebSearching.value = true
            _webSearchResults.value = runCatching { webSearchService.search(query.trim()) }.getOrDefault(emptyList())
            _isWebSearching.value = false
            runToolPrompt(
                prompt = query.trim(),
                mode = SmartModeType.WEB_SEARCH,
                useWebSearch = true
            )
        }
    }

    fun addMemory(category: String, content: String) {
        viewModelScope.launch { chatRepository.addMemory(category, content) }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch { chatRepository.deleteMemory(id) }
    }

    fun clearAllMemories() {
        viewModelScope.launch { chatRepository.clearAllMemories() }
    }

    fun clearAllChats() {
        viewModelScope.launch {
            chatRepository.clearAllChats()
            _activeSessionId.value = null
        }
    }

    fun saveStudyTopic(subject: String, topic: String, notes: String) {
        if (topic.isBlank()) return
        viewModelScope.launch {
            chatRepository.saveStudyTopic(subject, topic, 25, notes)
            NotificationAndLocationHelper.postAiNotification(
                getApplication(),
                "Study Goal Saved",
                "$subject: $topic added to your INFINITY AI study tracker."
            )
        }
    }

    fun boostStudyMastery(topic: StudyTopicEntity, delta: Int = 15) {
        viewModelScope.launch { chatRepository.updateStudyMastery(topic, delta) }
    }

    fun deleteStudyTopic(id: Long) {
        viewModelScope.launch { chatRepository.deleteStudyTopic(id) }
    }

    fun updateOwnerConfig(transform: (OwnerConfig) -> OwnerConfig) {
        viewModelScope.launch { settingsStore.updateConfig(transform) }
    }

    fun testOpenAiKey(keyOverride: String? = null) {
        viewModelScope.launch {
            _apiTestStatus.value = "Testing OpenAI API connection..."
            val keyToTest = keyOverride?.trim()?.takeIf { it.isNotBlank() }
                ?: aiRepository.resolveEffectiveOpenAiKey(ownerConfig.value)
            val result = aiRepository.testOpenAiKey(keyToTest)
            _apiTestStatus.value = result.fold(
                onSuccess = { it },
                onFailure = { it.localizedMessage ?: "Connection test failed." }
            )
        }
    }

    fun clearApiTestStatus() {
        _apiTestStatus.value = null
    }

    fun unlockOwnerMode(pinAttempt: String): Boolean {
        val ok = pinAttempt == ownerConfig.value.ownerPin
        if (ok) _ownerUnlocked.value = true
        return ok
    }

    fun lockOwnerMode() {
        _ownerUnlocked.value = false
    }

    fun startVoiceInput(onTranscript: (String) -> Unit) {
        voiceManager.startListening(ownerConfig.value.voiceLanguage, onTranscript)
    }

    fun stopVoiceInput() {
        voiceManager.stopListening()
    }

    fun speakText(text: String) {
        val config = ownerConfig.value
        if (!config.voiceEnabled || text.isBlank()) return

        val cleanText = VoiceManager.prepareNaturalSpeechText(text)
        if (cleanText.isBlank()) return

        val targetLocale = VoiceManager.resolveTargetLocale(text, config.voiceLanguage)
        val isHindi = targetLocale.language == "hi"
        val hasOpenAi = aiRepository.resolveEffectiveOpenAiKey(config).isNotBlank()

        if (config.preferNeuralVoice && hasOpenAi) {
            viewModelScope.launch {
                val audioResult = aiRepository.synthesizeNeuralSpeech(
                    text = cleanText,
                    config = config,
                    hindiIndianAccent = isHindi
                )
                audioResult.onSuccess { bytes ->
                    val langLabel = if (isHindi) "Hindi (Indian Accent)" else "English (${targetLocale.country.ifBlank { "Natural" }})"
                    voiceManager.playNeuralAudioBytes(
                        audioBytes = bytes,
                        volume = config.voiceVolume,
                        voiceLabel = "Neural HD (${config.neuralVoicePreset.displayName})",
                        languageLabel = langLabel,
                        onPlaybackError = {
                            voiceManager.speakWithSystemTts(text, config)
                        }
                    )
                }.onFailure {
                    voiceManager.speakWithSystemTts(text, config)
                }
            }
        } else {
            voiceManager.speakWithSystemTts(text, config)
        }
    }

    fun previewEnglishVoice() {
        val sample = "Hello! I am INFINITY AI. My voice is tuned to sound smooth, clear, confident, and natural."
        speakText(sample)
    }

    fun previewHindiVoice() {
        val sample = "नमस्ते! मैं INFINITY AI हूँ। मेरी आवाज़ स्पष्ट, स्वाभाविक और भारतीय उच्चारण के साथ आपके लिए तैयार है।"
        speakText(sample)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun clearVoiceError() {
        voiceManager.clearError()
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.release()
    }
}
