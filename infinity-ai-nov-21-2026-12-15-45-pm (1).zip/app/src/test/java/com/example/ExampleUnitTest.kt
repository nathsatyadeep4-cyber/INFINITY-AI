package com.example

import com.example.data.local.MemoryItemEntity
import com.example.data.model.AiEngine
import com.example.data.model.OwnerConfig
import com.example.data.model.SmartModeType
import com.example.data.model.VoiceLanguage
import com.example.data.remote.OpenAiApiService
import com.example.data.remote.WebSearchService
import com.example.data.repository.InfinityAiRepository
import com.example.util.VoiceManager
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    private val repository = InfinityAiRepository(
        openAiApi = OpenAiApiService(),
        webSearchService = WebSearchService()
    )

    @Test
    fun geminiSampleMode_returnsLabeledSampleNotice() = runTest {
        val result = repository.generateResponse(
            prompt = "Build a Compose screen",
            mode = SmartModeType.CODING,
            config = OwnerConfig(activeEngine = AiEngine.GEMINI),
            memories = listOf(MemoryItemEntity(category = "Preference", content = "Use Kotlin"))
        )
        assertTrue(result.isSuccess)
        val payload = result.getOrThrow()
        assertTrue(payload.isSampleNotice)
        assertTrue(payload.text.contains("Sample Gemini Response"))
    }

    @Test
    fun openAiSelectedWithoutKey_returnsClearError() = runTest {
        val result = repository.generateResponse(
            prompt = "Hello",
            mode = SmartModeType.CHAT,
            config = OwnerConfig(activeEngine = AiEngine.OPENAI, openAiApiKey = "")
        )
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("OpenAI API key") == true)
    }

    @Test
    fun imageGenDisabledInOwnerMode_returnsClearError() = runTest {
        val result = repository.generateImage(
            prompt = "Cosmic infinity",
            aspectRatio = "1:1",
            stylePreset = "Minimalist 3D",
            config = OwnerConfig(imageGenEnabled = false)
        )
        assertTrue(result.isFailure)
        assertFalse(result.isSuccess)
    }

    @Test
    fun voiceDetection_recognizesHindiAndEnglishAccurately() {
        assertTrue(VoiceManager.containsHindi("नमस्ते, आप कैसे हैं?"))
        assertTrue(VoiceManager.containsHindi("Namaste bhai, kya haal hai"))
        assertFalse(VoiceManager.containsHindi("Hello, how can I help you today?"))

        val hiLocale = VoiceManager.resolveTargetLocale("नमस्ते दुनिया", VoiceLanguage.AUTO_DETECT)
        assertEquals("hi", hiLocale.language)
        assertEquals("IN", hiLocale.country)

        val enInLocale = VoiceManager.resolveTargetLocale("Good morning", VoiceLanguage.ENGLISH_IN)
        assertEquals("en", enInLocale.language)
        assertEquals("IN", enInLocale.country)
    }

    @Test
    fun naturalSpeechFormatter_cleansMarkdownAndPreservesPauses() {
        val raw = "### Overview\n**INFINITY AI** helps you — quickly!\n```kotlin\nval x = 1\n```\nCheck https://example.com"
        val cleaned = VoiceManager.prepareNaturalSpeechText(raw)
        assertFalse(cleaned.contains("###"))
        assertFalse(cleaned.contains("**"))
        assertFalse(cleaned.contains("```"))
        assertFalse(cleaned.contains("https://"))
        assertTrue(cleaned.contains("See the code snippet on your screen."))
        assertTrue(cleaned.contains("link"))
    }
}
